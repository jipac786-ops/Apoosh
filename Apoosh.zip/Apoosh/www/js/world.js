/* Apoosh by Javed — world.js
   The Three.js scene: renderer, sun + soft shadows, sky, mountains, trees, 3D grass, the dirt pitch,
   3D villagers, the gilli and the danda. game.js owns the rules and physics; every frame it calls
   World.render(), which reads the game state and moves the 3D objects to match. */
'use strict';
const World = (() => {
  const T3 = THREE;
  let renderer, scene, camera, sun, hemi, uctx, ucv;
  const V = (x = 0, y = 0, z = 0) => new T3.Vector3(x, y, z);
  const UP = V(0, 1, 0);
  const tmpQ = new T3.Quaternion(), tmpM = new T3.Matrix4(), tmpV = V(), tmpS = V(1, 1, 1);
  let grassMat = null, timeU = { value: 0 };
  /* graphics levels. Low-end phones choke on draw calls (every small body part is one), soft shadows,
     thousands of grass blades and full-resolution rendering, so each level trims those. */
  const GFX = {
    low:    { pr: 1.2,  shadow: 0,    grass: 0.1,  phys: false, face: 256,  detail: false, spec: 0,  ui: 1 },
    medium: { pr: 1.45, shadow: 1024, grass: 0.35, phys: false, face: 512,  detail: true,  spec: 4,  ui: 1.5 },
    high:   { pr: 1.6, shadow: 1536, grass: 1,    phys: true,  face: 1024, detail: true,  spec: 99, ui: 2 },
  };
  /* One-time repair: closing the app while a match was loading used to be mistaken for a crash, and that switched the
     phone permanently into "safe mode" (old WebGL with low-precision maths). Low precision made the ground shimmer like
     water, far objects flicker and the fielders' legs sink into the ground. Give every phone a clean start once. */
  try { if (!localStorage.getItem('gd_safefix1')) { localStorage.setItem('gd_safefix1', '1'); if (localStorage.getItem('gd_safe3d')) { localStorage.removeItem('gd_safe3d'); if (localStorage.getItem('gd_gfx') === 'low') localStorage.setItem('gd_gfx', 'auto'); } } } catch (e) { }
  let qMode = 'auto', qKey = 'medium', Q = GFX.medium;
  try { qMode = localStorage.getItem('gd_gfx') || 'auto'; } catch (e) { }
  // safe mode: after the 3D crashed a device once, start it as light as possible
  const SAFE = (typeof location !== 'undefined' && /[?&]safe=1/.test(location.search)) || (() => { try { return localStorage.getItem('gd_safe3d') === '1'; } catch (e) { return false; } })();
  // never ask the graphics chip for a huge drawing surface (big tablet screens at high density ran out of memory)
  let SOFT = false, gpuName = '', dyn = 1, drawCalls = 0;
  const dynS = { t: 0, n: 0, last: 0 };
  const prFor = () => { const cap = SOFT ? 0.25e6 : SAFE ? 0.6e6 : qKey === 'high' ? 2.4e6 : qKey === 'medium' ? 1.6e6 : 1.1e6; return Math.max(0.4, dyn * Math.min(window.devicePixelRatio || 1, SAFE ? 0.85 : Q.pr, Math.sqrt(cap / Math.max(1, W * H)))); };
  /* automatic sharpness: if the phone stays under ~40 fps, the 3D picture is made a little smaller - at most twice,
     never back and forth (changing it repeatedly made the ground shimmer and flash) */
  function dynRes() {
    const now = performance.now(); if (dynS.last) { const d = now - dynS.last; if (d < 400) { dynS.t += d; dynS.n++; } } dynS.last = now;
    if (dynS.t < 3000 || dynS.steps >= 2) return; const f = 1000 * dynS.n / dynS.t; dynS.t = 0; dynS.n = 0;
    if (f < 40) { dyn = Math.max(0.72, dyn * 0.85); dynS.steps = (dynS.steps || 0) + 1; if (renderer) { renderer.setPixelRatio(prFor()); renderer.setSize(W, H); } }
  }
  const LV_ORDER = ['low', 'medium', 'high'];
  const lowerOf = (a, b) => LV_ORDER[Math.min(LV_ORDER.indexOf(a), LV_ORDER.indexOf(b))];
  /* graphics chips found in budget phones (Mali G31/G51/G52/G57/T-series, PowerVR GE/GM, Adreno 3xx-5xx and 610-613):
     Auto starts these on Low, so the first seconds of a match aren't spent lagging before it steps down */
  const WEAK_GPU = /mali-(t\d|g31|g51|g52|g57|400|450)|powervr|\bge8\d{3}|gm9\d{3}|adreno[^\d]*(3\d\d|4\d\d|50\d|51\d|610|612|613)\b|vivante|videocore/i;
  // Auto remembers when this phone had to step down, and starts there next time
  function rememberedAuto() { try { const k = localStorage.getItem('gd_autoq'); return GFX[k] ? k : null; } catch (e) { return null; } }
  function guessQuality() { const c = navigator.hardwareConcurrency || 4, m = navigator.deviceMemory || 4; return (c <= 4 || m <= 3) ? 'low' : (c >= 8 && m >= 6) ? 'high' : 'medium'; }

  /* ---------------- procedural textures (no image files: works offline) ---------------- */
  function canvasTex(w, h, draw, repeat) {
    const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); draw(x, w, h);
    const t = new T3.CanvasTexture(c); if (T3.SRGBColorSpace) t.colorSpace = T3.SRGBColorSpace; else t.encoding = T3.sRGBEncoding;
    if (repeat) { t.wrapS = t.wrapT = T3.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
    t.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy()); return t;
  }
  const rr = (() => { let s = 1234567; return () => { s = (s * 16807) % 2147483647; return s / 2147483647; }; })();
  function noiseFill(x, w, h, base, cols, n, rmin, rmax) {
    x.fillStyle = base; x.fillRect(0, 0, w, h);
    for (let i = 0; i < n; i++) { x.fillStyle = cols[Math.floor(rr() * cols.length)]; const r = rmin + rr() * (rmax - rmin); x.beginPath(); x.arc(rr() * w, rr() * h, r, 0, 6.283); x.fill(); }
  }
  let TEX = {};
  function makeTextures() {
    TEX.dirtAlpha = canvasTex(512, 128, (x, w, h) => { // ragged edges of the worn strip
      x.fillStyle = '#000'; x.fillRect(0, 0, w, h);
      const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#000'); g.addColorStop(0.18, '#fff'); g.addColorStop(0.82, '#fff'); g.addColorStop(1, '#000');
      x.fillStyle = g; x.fillRect(0, 0, w, h);
      x.fillStyle = '#000'; for (let i = 0; i < 160; i++) { const top = rr() < 0.5; x.beginPath(); x.ellipse(rr() * w, top ? rr() * 22 : h - rr() * 22, 6 + rr() * 16, 4 + rr() * 9, 0, 0, 6.283); x.fill(); }
    }, [6, 1]);
    if (T3.NoColorSpace) TEX.dirtAlpha.colorSpace = T3.NoColorSpace; else TEX.dirtAlpha.encoding = T3.LinearEncoding; TEX.dirtAlpha.wrapT = T3.ClampToEdgeWrapping;
    TEX.wood = canvasTex(128, 32, (x, w, h) => {
      x.fillStyle = '#a8693a'; x.fillRect(0, 0, w, h);
      for (let i = 0; i < 26; i++) { x.strokeStyle = rr() < 0.5 ? 'rgba(90,45,15,0.45)' : 'rgba(220,170,110,0.35)'; x.lineWidth = 0.6 + rr(); x.beginPath(); const y = rr() * h; x.moveTo(0, y); x.bezierCurveTo(w * 0.3, y + (rr() - 0.5) * 6, w * 0.7, y + (rr() - 0.5) * 6, w, y + (rr() - 0.5) * 4); x.stroke(); }
    }, [1, 1]);
    TEX.gilliWood = canvasTex(128, 32, (x, w, h) => {
      x.fillStyle = '#d9a061'; x.fillRect(0, 0, w, h);
      for (let i = 0; i < 18; i++) { x.strokeStyle = 'rgba(120,70,25,0.4)'; x.lineWidth = 0.8; x.beginPath(); const y = rr() * h; x.moveTo(0, y); x.lineTo(w, y + (rr() - 0.5) * 5); x.stroke(); }
    }, [1, 1]);
    TEX.cloth = canvasTex(64, 64, (x, w, h) => { // woven cotton: subtle threads, multiplied with each colour
      x.fillStyle = '#fff'; x.fillRect(0, 0, w, h);
      for (let i = 0; i < w; i += 2) { x.fillStyle = `rgba(0,0,0,${0.03 + rr() * 0.04})`; x.fillRect(i, 0, 1, h); x.fillRect(0, i, w, 1); }
    }, [6, 6]);
    TEX.soft = canvasTex(64, 64, (x, w, h) => { const g = x.createRadialGradient(32, 32, 0, 32, 32, 32); g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.4, 'rgba(255,255,255,0.55)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, w, h); });
    TEX.cloud = canvasTex(256, 128, (x, w, h) => {
      for (let i = 0; i < 14; i++) { const cx = 40 + rr() * 176, cy = 60 + (rr() - 0.5) * 30, r = 22 + rr() * 30; const g = x.createRadialGradient(cx, cy, 0, cx, cy, r); g.addColorStop(0, 'rgba(255,255,255,0.95)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.beginPath(); x.arc(cx, cy, r, 0, 6.283); x.fill(); }
    });
  }

  /* ---------------- sceneries ----------------
     Each scenery sets the sky, sun, haze, ground, grass, hills, trees, houses and props. Pick one in the menu. */
  const SCENES = {
    village: { sky: ['#3f7fc6', '#8fc0e6', '#dfeceb'], glow: [0.45, 0.42, -0.79], sunCol: '#fff1d8', sunI: 2.4, sunOff: [14, 26, 18], hemi: ['#cfe3ff', '#6b5a3a', 0.85], fog: ['#d3e4ea', 70, 900], exp: 1.05,
      grass: ['#7d9446', ['#6f8a3c', '#8aa152', '#748f40', '#93a95a', '#667f36'], 'rgba(60,80,25,0.35)'], dirt: ['#c3a274', ['#b8956a', '#cdae80', '#a98a60', '#d6ba8d', '#b39064']],
      blades: { n: 5000, hue: [0.2, 0.06], sat: [0.45, 0.2], lit: [0.28, 0.14], h: 1 },
      hills: [{ z: [260, 760], h: 230, seed: 1.3, low: '#5d6f4c', rock: '#7f8c9c', rk: 0.32, snow: 0.62 }, { z: [120, 300], h: 70, seed: 4.1, low: '#4f6d3b', rock: '#6f7f5e', rk: 0.7, snow: 2 }],
      trees: { poplar: 0.4, round: 0.35, pine: 0.25, gap: [7, 16], autumn: 0.2 }, houses: 'mud', clouds: [7, '#ffffff', 0.9], props: ['charpai', 'mosque'] },
    soq: { sky: ['#2563b5', '#78ade0', '#e3edf2'], glow: [0.35, 0.62, -0.7], sunCol: '#fff4e2', sunI: 2.7, sunOff: [10, 28, 14], hemi: ['#d6e6ff', '#5f5446', 0.8], fog: ['#dbe6ee', 120, 1600], exp: 1.05,
      grass: ['#7f8a48', ['#74803f', '#8c9652', '#6f7a3c', '#98a05c', '#6a7438'], 'rgba(70,80,35,0.35)'], dirt: ['#a8957c', ['#9c8a72', '#b4a288', '#93816a', '#bfae94']],
      blades: { n: 3500, hue: [0.15, 0.06], sat: [0.35, 0.2], lit: [0.28, 0.12], h: 0.8 },
      hills: [{ z: [700, 1300], h: 900, seed: 2.9, low: '#6b6253', rock: '#7d7468', rk: 0.18, snow: 0.38, jag: 1 },
              { z: [150, 520], h: 520, seed: 2.2, low: '#5f6a48', rock: '#7a6f62', rk: 0.3, snow: 0.62, jag: 1 },
              { z: [48, 170], h: 150, seed: 5.3, low: '#55663f', rock: '#776a58', rk: 0.55, snow: 1.3, jag: 1 }],
      trees: { poplar: 0.6, round: 0.4, gap: [7, 15], autumn: 0.45, autumnHue: 0.1, zMax: 30 }, houses: 'chalet', clouds: [4, '#ffffff', 0.85], props: ['charpai'] },
    punjab: { sky: ['#33467f', '#e3967a', '#ffd29a'], glow: [0.2, 0.06, -0.98], sunCol: '#ffb36e', sunI: 2.3, sunOff: [30, 10, 6], hemi: ['#ffc8a0', '#5a4a30', 0.75], fog: ['#f0bf96', 60, 650], exp: 1.12,
      grass: ['#6f8f3c', ['#64843a', '#7c9a46', '#6a8a36', '#86a352'], 'rgba(60,80,25,0.35)'], dirt: ['#bf9a6a', ['#b08b5e', '#c9a77a', '#a88459', '#d3b48a']],
      blades: { n: 6000, hue: [0.14, 0.08], sat: [0.5, 0.2], lit: [0.3, 0.16], h: 1.25 },
      hills: [{ z: [150, 230], h: 13, seed: 7.1, low: '#3e4c2c', rock: '#46552f', rk: 3, snow: 4, freq: 5, smooth: 1 }],
      trees: { round: 0.7, poplar: 0.1, palm: 0.2, gap: [12, 26], autumn: 0 }, houses: 'brick', clouds: [5, '#ffc0a0', 0.8], props: ['charpai', 'haystacks', 'crops'] },
    thar: { sky: ['#4b86c4', '#a9c6dc', '#f1dcc0'], glow: [0.5, 0.3, -0.8], sunCol: '#ffd9a8', sunI: 2.7, sunOff: [22, 18, 12], hemi: ['#ffe6c8', '#a07850', 0.85], fog: ['#ecd9bd', 60, 750], exp: 1.0,
      grass: ['#d8b98a', ['#cfae7c', '#e0c294', '#c9a672', '#e6cda4'], 'rgba(150,110,60,0.18)'], dirt: ['#c99f6a', ['#bf9461', '#d4ad79', '#b88d5a']],
      blades: { n: 900, hue: [0.11, 0.04], sat: [0.35, 0.2], lit: [0.45, 0.15], h: 0.7 },
      hills: [{ z: [200, 700], h: 45, seed: 3.3, low: '#d9b27c', rock: '#cfa46c', rk: 3, snow: 4, smooth: 1 }, { z: [60, 200], h: 16, seed: 6.6, low: '#e0bc88', rock: '#d6ae78', rk: 3, snow: 4, smooth: 1 }, { z: [24, 70], h: 5, seed: 8.8, low: '#e3c08d', rock: '#d9b27c', rk: 3, snow: 4, smooth: 1, freq: 2 }],
      trees: { acacia: 0.85, round: 0.15, gap: [18, 40], autumn: 0 }, houses: 'huts', clouds: [3, '#ffffff', 0.7], props: ['charpai'] },
    city: { sky: ['#5f8fc2', '#b2c7d6', '#e6e0d3'], glow: [0.4, 0.45, -0.8], sunCol: '#fff0d0', sunI: 2.3, sunOff: [12, 24, 16], hemi: ['#e0e6ef', '#77706a', 0.95], fog: ['#d6d2c8', 45, 420], exp: 1.05,
      grass: ['#9a958c', ['#8f8a82', '#a39e95', '#88837b', '#aca79e'], 'rgba(60,60,60,0.25)'], dirt: ['#b7a68b', ['#ab9a80', '#c2b297', '#a29179']],
      blades: { n: 0 }, hills: [], trees: { round: 1, gap: [26, 50], autumn: 0, street: 1 }, houses: 'none', clouds: [4, '#ffffff', 0.7], props: ['buildings', 'poles'] },
  };
  let SCN = SCENES.village, SCN_KEY = '', envGroup = null, skyMat = null, envTex = [], tracking = false;
  const track = (t) => { if (tracking) envTex.push(t); return t; };

  function envTextures() {
    const [gb, gc, gs] = SCN.grass;
    TEX.grass = track(canvasTex(256, 256, (x, w, h) => {
      noiseFill(x, w, h, gb, gc, 2600, 0.6, 2.4);
      x.strokeStyle = gs; x.lineWidth = 1;
      for (let i = 0; i < 700; i++) { const px = rr() * w, py = rr() * h; x.beginPath(); x.moveTo(px, py); x.lineTo(px + (rr() - 0.5) * 3, py - 3 - rr() * 5); x.stroke(); }
      if (SCN === SCENES.city) { x.strokeStyle = 'rgba(40,40,40,0.35)'; x.lineWidth = 1; for (let i = 0; i < 6; i++) { let px = rr() * w, py = rr() * h; x.beginPath(); x.moveTo(px, py); for (let k = 0; k < 6; k++) { px += (rr() - 0.5) * 30; py += (rr() - 0.5) * 30; x.lineTo(px, py); } x.stroke(); } }
    }, [140, 140]));
    TEX.dirt = track(canvasTex(256, 256, (x, w, h) => {
      noiseFill(x, w, h, SCN.dirt[0], SCN.dirt[1], 3000, 0.5, 2.2);
      for (let i = 0; i < 70; i++) { x.fillStyle = rr() < 0.5 ? 'rgba(110,85,55,0.55)' : 'rgba(225,210,185,0.6)'; x.beginPath(); x.ellipse(rr() * w, rr() * h, 1 + rr() * 2.5, 0.8 + rr() * 1.6, rr() * 3, 0, 6.283); x.fill(); }
      x.strokeStyle = 'rgba(90,65,40,0.12)'; x.lineWidth = 6; for (let i = 0; i < 4; i++) { x.beginPath(); x.moveTo(0, rr() * h); x.bezierCurveTo(w * 0.3, rr() * h, w * 0.6, rr() * h, w, rr() * h); x.stroke(); }
    }, [70, 2]));
  }

  /* ---------------- environment ---------------- */
  function skyDome() {
    const geo = new T3.SphereGeometry(1800, 32, 16);
    skyMat = new T3.ShaderMaterial({
      side: T3.BackSide, depthWrite: false, fog: false,
      uniforms: { top: { value: new T3.Color() }, mid: { value: new T3.Color() }, hor: { value: new T3.Color() }, sunDir: { value: V(0.45, 0.42, -0.79).normalize() }, sunCol: { value: new T3.Color('#fff0c0') } },
      vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'uniform vec3 top; uniform vec3 mid; uniform vec3 hor; uniform vec3 sunDir; uniform vec3 sunCol; varying vec3 vP;' +
        'void main(){ float h = clamp(vP.y,0.0,1.0); vec3 c = mix(hor, mid, smoothstep(0.0,0.18,h)); c = mix(c, top, smoothstep(0.18,0.75,h));' +
        ' float s = max(dot(vP, sunDir),0.0); c += sunCol*(pow(s,600.0)*1.6 + pow(s,12.0)*0.22); gl_FragColor = vec4(c,1.0); }'
    });
    const m = new T3.Mesh(geo, skyMat); m.renderOrder = -10; return m;
  }
  function ridge(u, s) { return 0.5 * Math.sin(u * 1.3 + s) + 0.28 * Math.sin(u * 2.9 + s * 2.1) + 0.14 * Math.sin(u * 6.1 + s * 3.7) + 0.06 * Math.sin(u * 13.3 + s * 1.7); }
  function mountains() {
    const grp = new T3.Group();
    for (const L of SCN.hills) {
      const zNear = L.z[0], zFar = L.z[1], f = L.freq || 1;
      const geo = new T3.PlaneGeometry(2600, zFar - zNear, L.freq ? 360 : 180, 36); geo.rotateX(-Math.PI / 2);
      const pos = geo.attributes.position, col = new Float32Array(pos.count * 3), c = new T3.Color(), cl = new T3.Color(L.low), cr = new T3.Color(L.rock), cs = new T3.Color('#c9d2dc');
      for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i) + 400, zl = pos.getZ(i), t = (zl + (zFar - zNear) / 2) / (zFar - zNear);
        const ramp = Math.pow(1 - t, 0.8);
        let h = (0.5 + 0.5 * ridge(x * f / 180, L.seed)) * 0.75 + 0.25 * (0.5 + 0.5 * ridge(x * f / 47 + zl / 60, L.seed * 1.7));
        if (L.jag) h += 0.18 * Math.abs(Math.sin(x / 9 + zl / 13) * Math.sin(x / 23 - zl / 7));
        h = Math.max(0, h * L.h * ramp - 2);
        pos.setY(i, h);
        const k = h / L.h;
        if (k > L.snow) c.set('#f1f4f8'); else if (k > L.rk) c.copy(cr).lerp(cs, (k - L.rk) / (L.snow - L.rk) * 0.6); else c.copy(cl).lerp(cr, k / L.rk);
        col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
      }
      geo.setAttribute('color', new T3.BufferAttribute(col, 3)); geo.computeVertexNormals();
      const m = new T3.Mesh(geo, new T3.MeshStandardMaterial({ vertexColors: true, flatShading: false, roughness: 1, metalness: 0 }));
      m.position.set(400, -1, -(zNear + zFar) / 2); grp.add(m);
    }
    return grp;
  }
  function ground() {
    const grp = new T3.Group();
    const grass = new T3.Mesh(new T3.PlaneGeometry(1600, 1600), new T3.MeshStandardMaterial({ map: TEX.grass, roughness: 0.96, metalness: 0 }));
    grass.rotation.x = -Math.PI / 2; grass.position.set(300, 0, -400); grass.receiveShadow = true; grp.add(grass);
    const strip = new T3.Mesh(new T3.PlaneGeometry(300, 3.4), new T3.MeshStandardMaterial({ map: TEX.dirt, alphaMap: TEX.dirtAlpha, transparent: true, roughness: 1, metalness: 0, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }));
    strip.rotation.x = -Math.PI / 2; strip.position.set(90, 0.004, 0.2); strip.receiveShadow = true; grp.add(strip);
    const patch = new T3.Mesh(new T3.CircleGeometry(0.55, 24), new T3.MeshStandardMaterial({ color: SCN.dirt[0], transparent: true, opacity: 0.55, roughness: 1, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3 }));
    patch.rotation.x = -Math.PI / 2; patch.scale.set(1, 0.6, 1); patch.position.set(-0.02, 0.006, 0); patch.receiveShadow = true; grp.add(patch);
    // the hole is a gilli-shaped slot: long and narrow with pointed ends, lying along the line of play (the gilli rests in it)
    const spindle = (L, W, n = 28) => { const s = new T3.Shape(); for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2, x = Math.cos(a) * L / 2, z = Math.sin(a) * W / 2 * Math.pow(Math.abs(Math.sin(a)), 0.15) * Math.pow(1 - Math.pow(Math.cos(a), 2), 0.35); i ? s.lineTo(x, z) : s.moveTo(x, z); } return new T3.ShapeGeometry(s); };
    const lip = new T3.Mesh(spindle(0.24, 0.085), new T3.MeshStandardMaterial({ color: new T3.Color(SCN.dirt[0]).multiplyScalar(0.72), roughness: 1, polygonOffset: true, polygonOffsetFactor: -4 }));
    lip.rotation.x = -Math.PI / 2; lip.position.set(-0.01, 0.007, 0); grp.add(lip);
    const hole = new T3.Mesh(spindle(0.2, 0.06), new T3.MeshStandardMaterial({ color: '#2a1a0e', roughness: 1, polygonOffset: true, polygonOffsetFactor: -5 }));
    hole.rotation.x = -Math.PI / 2; hole.position.set(-0.01, 0.008, 0); grp.add(hole);
    const deep = new T3.Mesh(spindle(0.13, 0.032), new T3.MeshBasicMaterial({ color: '#120a04', polygonOffset: true, polygonOffsetFactor: -6 }));
    deep.rotation.x = -Math.PI / 2; deep.position.set(0.0, 0.009, 0); grp.add(deep);
    for (let m = 20; m <= 100; m += 20) {
      const st = new T3.Mesh(new T3.DodecahedronGeometry(0.12, 0), new T3.MeshStandardMaterial({ color: '#e9e3d4', roughness: 0.9 }));
      st.scale.set(1, 0.55, 0.8); st.position.set(m, 0.05, 1.75); st.castShadow = st.receiveShadow = true; grp.add(st);
      const sp = new T3.Sprite(new T3.SpriteMaterial({ map: track(canvasTex(128, 64, (x) => { x.font = "800 40px 'Baloo 2',sans-serif"; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = 'rgba(70,52,30,0.85)'; x.fillText(m + 'm', 64, 34); })), transparent: true, depthWrite: false }));
      sp.scale.set(0.9, 0.45, 1); sp.position.set(m, 0.35, 1.85); grp.add(sp);
    }
    const peb = new T3.InstancedMesh(new T3.DodecahedronGeometry(0.03, 0), new T3.MeshStandardMaterial({ color: '#9b8f7f', roughness: 1 }), 120);
    for (let i = 0; i < 120; i++) { tmpM.compose(V(-8 + rr() * 140, 0.01, -1.2 + rr() * 2.8), tmpQ.setFromAxisAngle(UP, rr() * 6), V(0.5 + rr(), 0.4 + rr() * 0.4, 0.5 + rr())); peb.setMatrixAt(i, tmpM); }
    peb.receiveShadow = true; grp.add(peb);
    return grp;
  }
  function grassBlades() {
    const B = SCN.blades; if (!B.n) return new T3.Group();
    const geo = new T3.PlaneGeometry(0.05, 0.24, 1, 3); geo.translate(0, 0.12, 0);
    const mat = new T3.MeshStandardMaterial({ color: '#ffffff', side: T3.DoubleSide, roughness: 0.9 });
    mat.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = timeU;
      sh.vertexShader = 'uniform float uTime;\n' + sh.vertexShader.replace('#include <begin_vertex>',
        '#include <begin_vertex>\n float sway = sin(uTime*1.7 + instanceMatrix[3][0]*0.35 + instanceMatrix[3][2]*0.5)*0.06 + sin(uTime*3.1 + instanceMatrix[3][0])*0.02;\n transformed.x += sway * uv.y * uv.y;');
    };
    grassMat = mat;
    const N = Math.max(1, Math.round(B.n * Q.grass)), im = new T3.InstancedMesh(geo, mat, N), c = new T3.Color();
    let k = 0;
    while (k < N) {
      const x = -18 + rr() * 120, z = -14 + rr() * 26;
      if (z > -1.35 && z < 1.75 && rr() < 0.92) continue;
      tmpM.compose(V(x, 0, z), tmpQ.setFromAxisAngle(UP, rr() * 6.28), V(0.7 + rr() * 0.9, (0.6 + rr() * 1.1) * B.h, 1));
      im.setMatrixAt(k, tmpM); c.setHSL(B.hue[0] + rr() * B.hue[1], B.sat[0] + rr() * B.sat[1], B.lit[0] + rr() * B.lit[1]); im.setColorAt(k, c); k++;
    }
    im.receiveShadow = true; return im;
  }
  function pick(w) { let r = rr() * Object.keys(w).reduce((a, k) => a + w[k], 0); for (const k in w) { r -= w[k]; if (r <= 0) return k; } return Object.keys(w)[0]; }
  function trees() {
    const grp = new T3.Group(), list = [], TS = SCN.trees, kinds = {};
    for (const k of ['poplar', 'round', 'pine', 'acacia', 'palm']) if (TS[k]) kinds[k] = TS[k];
    let x = -90; while (x < 280) {
      const type = pick(kinds), z = TS.street ? -7.4 - rr() * 0.6 : -17 - rr() * (TS.zMax || 26);
      list.push({ x, z, type, s: 0.8 + rr() * 0.5, autumn: rr() < TS.autumn }); x += TS.gap[0] + rr() * (TS.gap[1] - TS.gap[0]);
    }
    const trunkM = new T3.MeshStandardMaterial({ color: '#5a4532', roughness: 1 }), leafM = new T3.MeshStandardMaterial({ color: '#ffffff', roughness: 0.95 });
    const trunkG = new T3.CylinderGeometry(0.12, 0.2, 1, 7); trunkG.translate(0, 0.5, 0);
    const blobG = new T3.IcosahedronGeometry(1, 2), popG = new T3.SphereGeometry(1, 10, 8), pineG = new T3.ConeGeometry(1, 1, 8);
    const leaves = [], trunks = [], c = new T3.Color();
    const leaf = (g, pos, q, sc, col) => leaves.push({ g, m: new T3.Matrix4().compose(pos, q.clone(), sc), col: col.clone() });
    const autumnC = () => c.setHSL((TS.autumnHue || 0.1) + rr() * 0.04, 0.6 + rr() * 0.2, 0.45 + rr() * 0.1);
    list.forEach((t) => {
      const s = t.s, th = { poplar: 2.2, round: 2.8, pine: 1.4, acacia: 2.4, palm: 7 }[t.type], tw = t.type === 'palm' ? 0.6 : 1;
      trunks.push(new T3.Matrix4().compose(V(t.x, 0, t.z), tmpQ.setFromAxisAngle(UP, rr() * 6), V(s * tw, th * s, s * tw)));
      if (t.type === 'poplar') leaf(popG, V(t.x, (th + 4.2) * s, t.z), tmpQ.identity(), V(1.1 * s, 4.8 * s, 1.1 * s), t.autumn ? autumnC() : c.setHSL(0.27 + rr() * 0.04, 0.42, 0.27 + rr() * 0.08));
      else if (t.type === 'round') { for (const [ox, oy, oz, r] of [[-1.1, 4.0, 0.3, 1.7], [1.1, 4.2, -0.2, 1.8], [0, 5.2, 0, 2.1], [0.2, 3.6, 1.0, 1.4]]) leaf(blobG, V(t.x + ox * s, oy * s, t.z + oz * s), tmpQ.setFromAxisAngle(UP, rr() * 6), V(r * s, r * 0.9 * s, r * s), t.autumn ? autumnC() : c.setHSL(0.25 + rr() * 0.05, 0.4, 0.3 + rr() * 0.08)); }
      else if (t.type === 'pine') { for (let k = 0; k < 3; k++) { const w = (1.9 - k * 0.45) * s; leaf(pineG, V(t.x, (1.4 + k * 1.5 + 1.2) * s, t.z), tmpQ.identity(), V(w, 2.6 * s, w), c.setHSL(0.36 + rr() * 0.03, 0.38, 0.2 + rr() * 0.05)); } }
      else if (t.type === 'acacia') { for (const [ox, oz, r] of [[-1.2, 0.2, 1.9], [1.0, -0.3, 2.1], [0.1, 0.9, 1.6]]) leaf(blobG, V(t.x + ox * s, (th + 0.7) * s, t.z + oz * s), tmpQ.setFromAxisAngle(UP, rr() * 6), V(r * s, 0.5 * s, r * s), c.setHSL(0.2 + rr() * 0.05, 0.35, 0.28 + rr() * 0.06)); }
      else if (t.type === 'palm') { for (let k = 0; k < 7; k++) { const a = k / 7 * 6.283 + rr() * 0.4, q = new T3.Quaternion().setFromEuler(new T3.Euler(0, -a, -0.45)); leaf(blobG, V(t.x + Math.cos(a) * 1.3 * s, th * s, t.z + Math.sin(a) * 1.3 * s), q, V(1.6 * s, 0.12 * s, 0.4 * s), c.setHSL(0.24 + rr() * 0.04, 0.45, 0.25 + rr() * 0.06)); } }
    });
    const tm = new T3.InstancedMesh(trunkG, trunkM, trunks.length); trunks.forEach((m, i) => tm.setMatrixAt(i, m)); tm.castShadow = tm.receiveShadow = true; grp.add(tm);
    for (const geo of [blobG, popG, pineG]) {
      const L = leaves.filter(l => l.g === geo); if (!L.length) continue;
      const im = new T3.InstancedMesh(geo, leafM, L.length); L.forEach((l, i) => { im.setMatrixAt(i, l.m); im.setColorAt(i, l.col); }); im.castShadow = im.receiveShadow = true; grp.add(im);
    }
    houses(grp);
    return grp;
  }
  const M = (c, o) => new T3.MeshStandardMaterial(Object.assign({ color: c, roughness: 1 }, o || {}));
  const mesh = (geo, mat, x, y, z, parent) => { const m = new T3.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = m.receiveShadow = true; if (parent) parent.add(m); return m; };
  function gable(h, w, dp, ht, mat, over) { // two sloping roof panels (ridge along x)
    const a = 0.55, L = (dp / 2 + over) / Math.cos(a);
    for (const sd of [-1, 1]) { const p = mesh(new T3.BoxGeometry(w + over * 2, 0.08, L), mat, 0, ht + Math.sin(a) * L / 2 - 0.05, sd * Math.cos(a) * L / 2, h); p.rotation.x = sd * a; }
    const tri = new T3.Shape(); tri.moveTo(-dp / 2, 0); tri.lineTo(dp / 2, 0); tri.lineTo(0, Math.tan(a) * dp / 2); tri.closePath();
    for (const sx of [-1, 1]) { const e = mesh(new T3.ShapeGeometry(tri), M('#7a5434', { side: T3.DoubleSide }), sx * w / 2, ht, 0, h); e.rotation.y = Math.PI / 2; }
  }
  function houses(grp) {
    const H = SCN.houses; if (H === 'none') return;
    const door = M('#4a3020', { roughness: 0.9 }), win = M('#2b2420', { roughness: 0.6 });
    if (H === 'mud') { // flat-roofed mud houses with a courtyard wall and a stack of firewood on the roof
      const wall = M('#b48c63'), roof = M('#8c6a48');
      for (const hx of [-24, 40, 115]) {
        const h = new T3.Group(), w = 5 + rr() * 2, dp = 4 + rr();
        mesh(new T3.BoxGeometry(w, 2.8, dp), wall, 0, 1.4, 0, h); mesh(new T3.BoxGeometry(w + 0.4, 0.3, dp + 0.4), roof, 0, 2.95, 0, h);
        mesh(new T3.BoxGeometry(0.9, 1.9, 0.05), door, -w * 0.15, 0.95, dp / 2 + 0.03, h);
        mesh(new T3.BoxGeometry(w * 1.3, 1.2, 0.3), wall, w * 0.15, 0.6, dp / 2 + 2.5, h);  // courtyard wall
        for (let k = 0; k < 6; k++) { const lg = mesh(new T3.CylinderGeometry(0.06, 0.06, 1.6, 6), M('#6b4a2e'), w * 0.2, 3.2 + (k % 3) * 0.12, -0.6 + k * 0.22, h); lg.rotation.z = Math.PI / 2; }
        h.position.set(hx, 0, -14 - rr() * 8); h.rotation.y = (rr() - 0.5) * 0.3; grp.add(h);
      }
    } else if (H === 'chalet') { // Soq: stone ground floor, timber upper floor with a balcony, steep tin roofs in bright colours, stepping up the slope
      const stone = M('#8a8277', { flatShading: true }), timber = M('#7a5434', { roughness: 0.85 }), roofs = ['#3e6f8f', '#2f7a55', '#8a2f2f', '#5a5f66'];
      [[-22, -18, 0], [36, -24, 1.2], [104, -20, 0.5]].forEach(([hx, hz, hy]) => {
        const h = new T3.Group(), w = 5.5 + rr() * 2, dp = 4.2 + rr();
        mesh(new T3.BoxGeometry(w, 2.4, dp), stone, 0, 1.2, 0, h); mesh(new T3.BoxGeometry(w, 2.0, dp), timber, 0, 3.4, 0, h);
        mesh(new T3.BoxGeometry(w * 0.85, 0.12, 0.9), timber, 0, 2.45, dp / 2 + 0.45, h);                     // balcony
        for (let k = 0; k < 6; k++) mesh(new T3.BoxGeometry(0.06, 0.8, 0.06), timber, -w * 0.4 + k * w * 0.16, 2.85, dp / 2 + 0.88, h);
        mesh(new T3.BoxGeometry(0.9, 1.8, 0.05), door, -w * 0.2, 0.9, dp / 2 + 0.03, h);
        for (const wx of [-0.22, 0.22]) mesh(new T3.BoxGeometry(0.7, 0.8, 0.05), win, wx * w, 3.5, dp / 2 + 0.03, h);
        gable(h, w, dp, 4.4, M(roofs[Math.floor(rr() * roofs.length)], { roughness: 0.45, metalness: 0.4 }), 0.4);
        if (hy > 0) mesh(new T3.BoxGeometry(w + 3, hy, dp + 3), stone, 0, hy / 2 - 0.01, 0, h).position.y = -hy / 2;  // stone platform on the slope
        h.position.set(hx, hy, hz); h.rotation.y = (rr() - 0.5) * 0.25; grp.add(h);
      });
    } else if (H === 'brick') { // Punjab: red-brick houses with white trim, boundary walls, a tubewell room and a water channel
      const brick = M('#a2573d'), trim = M('#efe8dc'), wallM = M('#94503a');
      for (const hx of [-26, 92]) {
        const h = new T3.Group(), w = 7 + rr() * 2, dp = 5;
        mesh(new T3.BoxGeometry(w, 3.2, dp), brick, 0, 1.6, 0, h); mesh(new T3.BoxGeometry(w + 0.3, 0.25, dp + 0.3), trim, 0, 3.3, 0, h);
        mesh(new T3.BoxGeometry(w + 0.3, 0.5, 0.15), trim, 0, 3.6, dp / 2 + 0.1, h);
        mesh(new T3.BoxGeometry(1, 2, 0.06), M('#3d6b8a'), -w * 0.2, 1, dp / 2 + 0.03, h); mesh(new T3.BoxGeometry(0.9, 0.8, 0.06), M('#3d6b8a'), w * 0.25, 1.8, dp / 2 + 0.03, h);
        for (const [x1, z1, l, rot] of [[0, dp / 2 + 4, w + 8, 0], [-(w + 8) / 2, dp / 2 + 1.5, 5, 1], [(w + 8) / 2, dp / 2 + 1.5, 5, 1]]) { const b = mesh(new T3.BoxGeometry(l, 1.4, 0.25), wallM, x1, 0.7, z1, h); if (rot) b.rotation.y = Math.PI / 2; }
        h.position.set(hx, 0, -19 - rr() * 5); grp.add(h);
      }
      const tw = new T3.Group(); mesh(new T3.BoxGeometry(2.5, 2.2, 2.5), brick, 0, 1.1, 0, tw); mesh(new T3.CylinderGeometry(0.12, 0.12, 1.2, 8), M('#555', { metalness: 0.6, roughness: 0.4 }), 1.5, 0.9, 0.6, tw).rotation.z = Math.PI / 2;
      mesh(new T3.BoxGeometry(2, 0.5, 1.6), brick, 2.6, 0.25, 0.6, tw); tw.position.set(62, 0, -16.5); grp.add(tw);
      const water = new T3.Mesh(new T3.PlaneGeometry(260, 0.9), new T3.MeshStandardMaterial({ color: '#5f8aa0', roughness: 0.15, metalness: 0.2 })); water.rotation.x = -Math.PI / 2; water.position.set(90, 0.03, -7.6); grp.add(water);
    } else if (H === 'huts') { // Thar: round painted huts (chaunra) inside thorn fences, a well with a pulley
      const thatch = M('#b8975a', { flatShading: true });
      const paint = track(canvasTex(256, 64, (x, w, h) => { x.fillStyle = '#d9b27c'; x.fillRect(0, 0, w, h); x.fillStyle = '#b8402f'; x.fillRect(0, 34, w, 10); x.fillStyle = '#f2ead8'; for (let i = 0; i < w; i += 16) { x.beginPath(); x.moveTo(i, 34); x.lineTo(i + 8, 22); x.lineTo(i + 16, 34); x.fill(); } x.fillStyle = '#2f5f7a'; x.fillRect(0, 46, w, 4); }, [3, 1]));
      const hutM = M('#ffffff', { map: paint });
      for (const [cx, cz] of [[-24, -18], [90, -22]]) {
        const h = new T3.Group();
        for (const [ox, oz] of [[0, 0], [5.5, -2], [2, -5.5]]) {
          mesh(new T3.CylinderGeometry(2, 2.1, 2.3, 18), hutM, ox, 1.15, oz, h); mesh(new T3.ConeGeometry(2.6, 2.4, 16), thatch, ox, 3.4, oz, h);
          mesh(new T3.BoxGeometry(0.8, 1.6, 0.1), door, ox, 0.8, oz + 2.02, h);
        }
        const fence = mesh(new T3.TorusGeometry(7, 0.35, 5, 36), M('#7a6040', { flatShading: true }), 2.5, 0.3, -2.5, h); fence.rotation.x = Math.PI / 2; fence.scale.set(1, 1, 1.6);
        h.position.set(cx, 0, cz); grp.add(h);
      }
      const well = new T3.Group(), st = M('#cdb38a', { flatShading: true }), wd = M('#6b4a2e');
      mesh(new T3.CylinderGeometry(1.2, 1.3, 0.9, 16, 1, true), st, 0, 0.45, 0, well); mesh(new T3.TorusGeometry(1.2, 0.15, 6, 18), st, 0, 0.9, 0, well).rotation.x = Math.PI / 2;
      for (const sx of [-1, 1]) mesh(new T3.BoxGeometry(0.15, 2.4, 0.15), wd, sx * 1.1, 1.2, 0, well);
      mesh(new T3.CylinderGeometry(0.08, 0.08, 2.5, 6), wd, 0, 2.3, 0, well).rotation.z = Math.PI / 2; mesh(new T3.TorusGeometry(0.25, 0.06, 6, 12), wd, 0, 2.3, 0, well);
      well.position.set(52, 0, -11); grp.add(well);
    }
  }
  function mosque() { // the village mosque: white walls, a green dome and a minaret
    const g = new T3.Group(), wh = M('#f1ede4'), gr = M('#2f7a55', { roughness: 0.5 });
    mesh(new T3.BoxGeometry(9, 4, 7), wh, 0, 2, 0, g); mesh(new T3.SphereGeometry(2.6, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), gr, 0, 4, 0, g);
    mesh(new T3.ConeGeometry(0.15, 1, 8), M('#d9b84a', { metalness: 0.6, roughness: 0.3 }), 0, 7, 0, g);
    mesh(new T3.CylinderGeometry(0.55, 0.65, 11, 12), wh, 5.5, 5.5, 2.5, g); mesh(new T3.CylinderGeometry(0.85, 0.85, 0.3, 12), wh, 5.5, 9.2, 2.5, g); mesh(new T3.ConeGeometry(0.6, 1.4, 12), gr, 5.5, 11.7, 2.5, g);
    for (const ax of [-2.5, 0, 2.5]) mesh(new T3.CylinderGeometry(0.75, 0.75, 0.06, 16, 1, false, 0, Math.PI), M('#2b2420'), ax, 2.2, 3.52, g).rotation.x = Math.PI / 2;
    g.position.set(62, 0, -27); return g;
  }
  function cattle() { // a few buffaloes grazing near the houses
    const grp = new T3.Group(), m = M('#2b2622', { roughness: 0.8 });
    for (let i = 0; i < 4; i++) {
      const b = new T3.Group();
      mesh(new T3.CapsuleGeometry(0.45, 1.2, 4, 10), m, 0, 0.95, 0, b).rotation.z = Math.PI / 2;
      mesh(new T3.BoxGeometry(0.45, 0.45, 0.4), m, 1.0, 1.05, 0, b).rotation.z = -0.5;
      for (const [lx, lz] of [[-0.55, -0.2], [-0.55, 0.2], [0.5, -0.2], [0.5, 0.2]]) mesh(new T3.CylinderGeometry(0.08, 0.07, 0.75, 6), m, lx, 0.38, lz, b);
      for (const sz of [-1, 1]) { const h = mesh(new T3.TorusGeometry(0.16, 0.035, 5, 10, Math.PI), M('#4a4038'), 1.05, 1.32, sz * 0.15, b); h.rotation.y = Math.PI / 2; }
      b.position.set(6 + i * 10 + rr() * 4, 0, -6.4 - rr() * 1.4); b.rotation.y = rr() * 6; grp.add(b);
    }
    return grp;
  }
  function terraces() { // Soq: stepped fields climbing toward the mountains
    const grp = new T3.Group(), cols = ['#6e8c3a', '#9aa24a', '#c8a64a', '#7f9a44'], st = M('#7f776b', { flatShading: true });
    for (let k = 0; k < 6; k++) {
      const z = -34 - k * 3.2, y = 0.9 + k * 1.1;
      for (let x = -60; x < 240; x += 26 + rr() * 10) {
        const w = 18 + rr() * 8; mesh(new T3.BoxGeometry(w, y, 3.4), st, x, y / 2, z, grp);
        mesh(new T3.BoxGeometry(w, 0.06, 3.3), M(cols[Math.floor(rr() * cols.length)]), x, y + 0.03, z, grp);
      }
    }
    return grp;
  }
  function boulders() {
    const grp = new T3.Group(), m = M('#8d877d', { flatShading: true });
    for (let i = 0; i < 40; i++) { const r = 0.25 + rr() * 1.1, b = mesh(new T3.DodecahedronGeometry(r, 0), m, -15 + rr() * 150, r * 0.4, -4 - rr() * 11, grp); b.rotation.set(rr() * 3, rr() * 3, rr() * 3); b.scale.set(1, 0.7, 1); }
    return grp;
  }
  function crops() { // Punjab: blocks of yellow mustard and tall green sugarcane behind the pitch
    const grp = new T3.Group();
    const mustard = track(canvasTex(128, 128, (x, w, h) => { noiseFill(x, w, h, '#a8b23a', ['#e8d42a', '#f2df3a', '#d9c51e', '#8fa233'], 1800, 1, 2.6); }, [8, 2]));
    const cane = track(canvasTex(64, 128, (x, w, h) => { x.fillStyle = '#4d7a2e'; x.fillRect(0, 0, w, h); for (let i = 0; i < 60; i++) { x.strokeStyle = rr() < 0.5 ? '#6b9a3a' : '#3c6224'; x.lineWidth = 2; x.beginPath(); const px = rr() * w; x.moveTo(px, h); x.quadraticCurveTo(px + (rr() - 0.5) * 20, h * 0.5, px + (rr() - 0.5) * 30, 0); x.stroke(); } }, [10, 1]));
    for (let x = -40; x < 240; x += 70 + rr() * 30) {
      const isCane = rr() < 0.4, w = 22 + rr() * 6, ht = isCane ? 2.6 : 0.9;
      mesh(new T3.BoxGeometry(w, ht, 5), M('#ffffff', { map: isCane ? cane : mustard }), x, ht / 2, -11, grp);
    }
    return grp;
  }
  function clouds() {
    const grp = new T3.Group(), [n, col, op] = SCN.clouds;
    for (let i = 0; i < n; i++) { const sp = new T3.Sprite(new T3.SpriteMaterial({ map: TEX.cloud, color: col, transparent: true, depthWrite: false, fog: false, opacity: op * (0.85 + rr() * 0.15) })); const s = 70 + rr() * 90; sp.scale.set(s, s / 2, 1); sp.position.set(-300 + rr() * 900, 90 + rr() * 80, -500 - rr() * 300); grp.add(sp); }
    return grp;
  }
  function charpai(x, z) { // rope bed the old men sit near
    const g = new T3.Group(), wood = new T3.MeshStandardMaterial({ map: TEX.wood, roughness: 0.8 }), rope = new T3.MeshStandardMaterial({ color: '#d9c49a', roughness: 1 });
    const top = new T3.Mesh(new T3.BoxGeometry(1.9, 0.04, 0.9), rope); top.position.y = 0.45; top.castShadow = top.receiveShadow = true; g.add(top);
    for (const [lx, lz] of [[-0.9, -0.4], [0.9, -0.4], [-0.9, 0.4], [0.9, 0.4]]) { const l = new T3.Mesh(new T3.CylinderGeometry(0.035, 0.03, 0.45, 6), wood); l.position.set(lx, 0.225, lz); l.castShadow = true; g.add(l); }
    for (const [lz] of [[-0.43], [0.43]]) { const r = new T3.Mesh(new T3.BoxGeometry(1.95, 0.06, 0.06), wood); r.position.set(0, 0.45, lz); r.castShadow = true; g.add(r); }
    g.position.set(x, 0, z); g.rotation.y = 0.2; return g;
  }
  function haystacks() {
    const grp = new T3.Group(), m = new T3.MeshStandardMaterial({ color: '#d4b05a', roughness: 1, flatShading: true });
    for (let i = 0; i < 4; i++) { const s = 0.8 + rr() * 0.6, h = new T3.Mesh(new T3.ConeGeometry(1.6 * s, 3 * s, 10), m); h.position.set(-10 + rr() * 160, 1.5 * s, -15.5 - rr() * 12); h.castShadow = h.receiveShadow = true; grp.add(h); }
    return grp;
  }
  function stoneWalls() {
    const grp = new T3.Group(), m = new T3.MeshStandardMaterial({ color: '#8a8378', roughness: 1, flatShading: true });
    for (let x = -40; x < 200; x += 14 + rr() * 8) { const w = new T3.Mesh(new T3.BoxGeometry(10 + rr() * 6, 0.8, 0.6, 6, 2, 1), m); const p = w.geometry.attributes.position; for (let i = 0; i < p.count; i++) p.setY(i, p.getY(i) + (rr() - 0.5) * 0.12); w.geometry.computeVertexNormals(); w.position.set(x, 0.4, -9.5 - rr() * 2); w.castShadow = w.receiveShadow = true; grp.add(w); }
    return grp;
  }
  function buildings() { // a Karachi street: rows of plastered houses with windows, balconies and roof tanks
    const grp = new T3.Group(), pal = ['#d9c9a8', '#c7b9a0', '#e0d5c0', '#b8c4c9', '#d8b9a0', '#a9b8a6', '#e2c49a', '#cfc0d4'];
    const winTex = track(canvasTex(128, 128, (x, w, h) => {
      x.fillStyle = '#fff'; x.fillRect(0, 0, w, h);
      for (let r = 0; r < 2; r++) for (let c = 0; c < 2; c++) { const px = 14 + c * 64, py = 18 + r * 64; x.fillStyle = 'rgba(0,0,0,0.12)'; x.fillRect(px - 4, py - 4, 44, 40); x.fillStyle = rr() < 0.5 ? '#3e5560' : rr() < 0.5 ? '#2f6b4f' : '#5a7da0'; x.fillRect(px, py, 36, 32); x.fillStyle = 'rgba(255,255,255,0.25)'; x.fillRect(px + 17, py, 2, 32); x.fillStyle = 'rgba(0,0,0,0.18)'; x.fillRect(px - 6, py + 34, 48, 4); }
    }));
    const tankM = new T3.MeshStandardMaterial({ color: '#1e1e22', roughness: 0.6 }), shutterM = new T3.MeshStandardMaterial({ color: '#6b6f73', roughness: 0.5, metalness: 0.3 });
    const row = (z0, hMin, hMax, depth) => {
      let x = -60; while (x < 260) {
        const w = 6 + rr() * 7, ht = hMin + rr() * (hMax - hMin), t = winTex.clone(); t.needsUpdate = true; t.wrapS = t.wrapT = T3.RepeatWrapping; t.repeat.set(Math.round(w / 3), Math.round(ht / 3)); envTex.push(t);
        const b = new T3.Mesh(new T3.BoxGeometry(w, ht, depth), new T3.MeshStandardMaterial({ color: pal[Math.floor(rr() * pal.length)], map: t, roughness: 0.95 }));
        b.position.set(x + w / 2, ht / 2, z0 - depth / 2); b.castShadow = b.receiveShadow = true; grp.add(b);
        if (depth > 6) {
          const sh = new T3.Mesh(new T3.BoxGeometry(w * 0.6, 2.4, 0.1), shutterM); sh.position.set(x + w / 2, 1.2, z0 + 0.05); grp.add(sh); // shop shutter
          const bal = new T3.Mesh(new T3.BoxGeometry(w * 0.7, 0.12, 1), new T3.MeshStandardMaterial({ color: '#e8e4dc', roughness: 0.9 })); bal.position.set(x + w / 2, 3.4, z0 + 0.5); bal.castShadow = true; grp.add(bal);
          for (let k = 0; k < 1 + (rr() < 0.5); k++) { const tk = new T3.Mesh(new T3.CylinderGeometry(0.55, 0.55, 1.1, 12), tankM); tk.position.set(x + 1 + rr() * (w - 2), ht + 0.55, z0 - 1 - rr() * 3); tk.castShadow = true; grp.add(tk); }
        }
        x += w + (rr() < 0.25 ? 1.5 : 0.05);
      }
    };
    row(-9, 6, 12, 8); row(-90, 20, 40, 20);
    return grp;
  }
  function poles() { // electric poles along the street with sagging wires
    const grp = new T3.Group(), m = new T3.MeshStandardMaterial({ color: '#8a8a86', roughness: 0.8 }), tops = [];
    for (let x = -30; x < 250; x += 45) { const p = new T3.Mesh(new T3.CylinderGeometry(0.1, 0.14, 8, 8), m); p.position.set(x, 4, -7.3); p.castShadow = true; grp.add(p); const arm = new T3.Mesh(new T3.BoxGeometry(0.1, 0.1, 1.4), m); arm.position.set(x, 7.6, -7.3); grp.add(arm); tops.push(x); }
    for (const dz of [-0.6, 0, 0.6]) { const pts = []; for (let i = 0; i < tops.length - 1; i++) for (let k = 0; k <= 10; k++) { const t = k / 10; pts.push(V(lerp(tops[i], tops[i + 1], t), 7.65 - Math.sin(t * Math.PI) * 0.7, -7.3 + dz)); } const geo = new T3.BufferGeometry().setFromPoints(pts); grp.add(new T3.Line(geo, new T3.LineBasicMaterial({ color: '#2a2a2a' }))); }
    return grp;
  }
  /* The scenery never moves, so pieces that share the same look (every wall of one colour, every window, every balcony
     rail, every buffalo leg...) are joined into one shape when the scene is built. The phone then draws a village in a
     few jobs instead of hundreds. Every piece keeps its exact place, size, colour, texture and shadow. */
  function mergeStill(root) {
    root.updateMatrixWorld(true);
    const inv = new T3.Matrix4().copy(root.matrixWorld).invert(), rel = new T3.Matrix4(), by = new Map();
    root.traverse(o => {
      if (!o.isMesh || o.isInstancedMesh || o.isSkinnedMesh || !o.visible || o.children.length || o.renderOrder) return;
      const m = o.material, g = o.geometry;
      if (!m || Array.isArray(m) || m.transparent || !g || !g.attributes.position || Object.keys(g.morphAttributes || {}).length) return;
      if (m.onBeforeCompile && m.onBeforeCompile.toString() !== T3.Material.prototype.onBeforeCompile.toString()) return;
      rel.multiplyMatrices(inv, o.matrixWorld); if (rel.determinant() <= 0) return;   // mirrored pieces stay as they are
      const attrs = Object.keys(g.attributes).sort().map(k => k + g.attributes[k].itemSize).join(',');
      const key = [matSig(m), m.color ? m.color.getHexString() : '', m.vertexColors ? 1 : 0, m.fog ? 1 : 0, m.polygonOffset ? m.polygonOffsetFactor + '/' + m.polygonOffsetUnits : '', m.depthWrite ? 1 : 0, m.depthTest ? 1 : 0,
        m.alphaMap ? m.alphaMap.uuid : '', m.normalMap ? m.normalMap.uuid : '', o.castShadow ? 1 : 0, o.receiveShadow ? 1 : 0, attrs].join('#');
      let a = by.get(key); if (!a) by.set(key, a = []); a.push(o);
    });
    const gone = [];
    for (const list of by.values()) {
      if (list.length < 2) continue;
      const parts = list.map(o => { rel.multiplyMatrices(inv, o.matrixWorld); const g = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone(); g.applyMatrix4(rel); return g; });
      const names = Object.keys(parts[0].attributes), geo = new T3.BufferGeometry();
      for (const n of names) {
        const size = parts[0].attributes[n].itemSize, total = parts.reduce((s, g) => s + g.attributes[n].count, 0), arr = new Float32Array(total * size); let off = 0;
        for (const g of parts) { const at = g.attributes[n]; for (let i = 0; i < at.count; i++) for (let c = 0; c < size; c++) arr[off++] = at.getComponent ? at.getComponent(i, c) : at.array[i * size + c]; }
        geo.setAttribute(n, new T3.BufferAttribute(arr, size, parts[0].attributes[n].normalized));
      }
      parts.forEach(g => g.dispose()); geo.computeBoundingSphere(); geo.computeBoundingBox();
      const src = list[0], one = new T3.Mesh(geo, src.material);
      one.castShadow = src.castShadow; one.receiveShadow = src.receiveShadow; one.matrixAutoUpdate = false; one.updateMatrix();
      root.add(one); one.updateMatrixWorld(true);
      for (const o of list) { if (o.parent) o.parent.remove(o); gone.push(o); }
    }
    // free what the joined pieces no longer use
    const geos = new Set(), mats = new Set(); root.traverse(o => { if (o.geometry) geos.add(o.geometry); if (o.material) mats.add(o.material); });
    for (const o of gone) { if (!geos.has(o.geometry)) { o.geometry.dispose(); geos.add(o.geometry); } if (!mats.has(o.material)) { o.material.dispose(); mats.add(o.material); } }
  }
  function disposeEnv() {
    if (!envGroup) return;
    scene.remove(envGroup);
    envGroup.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => m.dispose()); });
    envTex.forEach(t => t.dispose()); envTex = []; envGroup = null;
  }
  function setScene(key) {
    if (key === 'hunza') key = 'soq';
    if (!SCENES[key]) key = 'village';
    if (key === SCN_KEY && envGroup) return;
    SCN_KEY = key; SCN = SCENES[key]; disposeEnv();
    tracking = true; envTextures();
    envGroup = new T3.Group();
    envGroup.add(mountains(), ground(), grassBlades(), trees(), clouds());
    const P = SCN.props;
    if (P.includes('charpai')) envGroup.add(charpai(-6.8, -3.6));
    if (P.includes('haystacks')) envGroup.add(haystacks());
    if (P.includes('walls')) envGroup.add(stoneWalls());
    if (P.includes('mosque')) envGroup.add(mosque());
    if (P.includes('cattle')) envGroup.add(cattle());
    if (P.includes('terraces')) envGroup.add(terraces());
    if (P.includes('boulders')) envGroup.add(boulders());
    if (P.includes('crops')) envGroup.add(crops());
    if (P.includes('buildings')) envGroup.add(buildings());
    if (P.includes('poles')) envGroup.add(poles());
    tracking = false; scene.add(envGroup);
    envGroup.traverse(o => { o.updateMatrix(); o.matrixAutoUpdate = false; });   // scenery never moves: skip its matrix maths every frame
    try { mergeStill(envGroup); } catch (e) { }
    skyMat.uniforms.top.value.set(SCN.sky[0]); skyMat.uniforms.mid.value.set(SCN.sky[1]); skyMat.uniforms.hor.value.set(SCN.sky[2]);
    skyMat.uniforms.sunDir.value.set(...SCN.glow).normalize(); skyMat.uniforms.sunCol.value.set(SCN.sunCol);
    hemi.color.set(SCN.hemi[0]); hemi.groundColor.set(SCN.hemi[1]); hemi.intensity = SCN.hemi[2];
    sun.color.set(SCN.sunCol); sun.intensity = SCN.sunI;
    scene.fog.color.set(SCN.fog[0]); scene.fog.near = SCN.fog[1]; scene.fog.far = SCN.fog[2]; renderer.toneMappingExposure = SCN.exp;
  }

  /* ---------------- 3D villagers ---------------- */
  /* Body parts are smooth lathe/tapered shapes sized like a real 1.7 m man; clothes are a long kameez over a baggy shalwar. */
  function lathe(pts, seg) { return new T3.LatheGeometry(pts.map(p => new T3.Vector2(p[0], p[1])), seg || 20); }
  function taper(rt, rb, seg) { return new T3.CylinderGeometry(rt, rb, 1, seg || 14); }
  /* a limb from a radius profile, with an oval cross-section (flat) that gets flatter toward the bottom by `flatEnd` */
  function limb(profile, flat, flatEnd) {
    const geo = new T3.LatheGeometry([new T3.Vector2(0.0005, profile[0][1])].concat(profile.map(p => new T3.Vector2(p[0], p[1]))).concat([new T3.Vector2(0.0005, profile[profile.length - 1][1])]), 16);
    const p = geo.attributes.position;
    for (let i = 0; i < p.count; i++) { const y = p.getY(i), f = flat * (1 - flatEnd * Math.max(0, -y) * 2 * 0.5); p.setZ(i, p.getZ(i) * f); }
    geo.computeVertexNormals(); return geo;
  }
  /* soft cloth folds: ripple a tube's radius around and along it (more toward the bottom when grow > 0) */
  function folds(geo, n, amp, grow) {
    const p = geo.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i), a = Math.atan2(x, z), lo = 0.5 - y;
      const k = 1 + amp * (1 + grow * lo) * (0.6 * Math.sin(a * n + y * 5) + 0.4 * Math.sin(a * (n + 3) - y * 9));
      p.setX(i, x * k); p.setZ(i, z * k);
    }
    geo.computeVertexNormals(); return geo;
  }
  /* one kameez panel (front or back): a closed ring at the waist that opens into side slits lower down,
     widening a little toward the hem, with folds that deepen near the hem */
  function kameezPanel() {
    const rows = 12, pts = [];
    for (let i = 0; i <= rows; i++) { const t = i / rows; pts.push(new T3.Vector2(0.168 + 0.075 * Math.pow(t, 0.9), 0.5 - t)); }
    const geo = new T3.LatheGeometry(pts, 22, -1.2, 2.4), p = geo.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i), t = 0.5 - y, r = Math.hypot(x, z);
      let a = Math.atan2(x, z); a *= 1 + 0.33 * Math.max(0, 1 - t / 0.38);
      const r2 = r * (1 + 0.055 * t * Math.sin(a * 9 + t * 3) + 0.02 * Math.sin(a * 4));
      p.setXYZ(i, Math.sin(a) * r2, y - (t > 0.9 ? 0.03 * (Math.cos(a) - 0.6) : 0), Math.cos(a) * r2);
    }
    geo.computeVertexNormals(); return geo;
  }
  const G = {
    // sleeves and shalwar legs (y: 0 bottom .. 1 top after orientSeg)
    // arms shaped like arms: y = -0.5 is the lower joint, +0.5 the upper one
    upper: limb([[0.033, -0.5], [0.036, -0.4], [0.041, -0.2], [0.046, 0.0], [0.047, 0.12], [0.049, 0.3], [0.052, 0.42], [0.046, 0.5]], 0.86, 0),
    fore: limb([[0.021, -0.5], [0.023, -0.38], [0.03, -0.15], [0.038, 0.1], [0.041, 0.25], [0.039, 0.4], [0.034, 0.5]], 0.8, 0.35),
    sleeve: folds(lathe([[0.06, 0.5], [0.06, 0.25], [0.058, 0.0], [0.056, -0.12]], 18), 5, 0.04, 1.2), cuff: new T3.TorusGeometry(0.047, 0.008, 6, 16),
    thigh: folds(new T3.CylinderGeometry(0.092, 0.078, 1, 18, 5), 4, 0.018, 0.3),
    shin: folds(new T3.CylinderGeometry(0.074, 0.064, 1, 18, 5), 4, 0.016, 0.8),
    shirtHem: folds(lathe([[0.164, 0.5], [0.17, 0], [0.176, -0.5]], 22), 7, 0.03, 0.6), belt: new T3.TorusGeometry(0.152, 0.013, 6, 26).rotateX(Math.PI / 2), hips: new T3.SphereGeometry(1, 16, 10),
    shoe: new T3.CapsuleGeometry(0.045, 0.16, 4, 12), shoeSole: new T3.BoxGeometry(0.1, 0.028, 0.28),
    capDome: new T3.SphereGeometry(0.108, 24, 12, 0, Math.PI * 2, 0, Math.PI * 0.5), capBrim: new T3.CylinderGeometry(0.075, 0.075, 0.012, 20, 1, false, -Math.PI / 2, Math.PI),
    ankle: new T3.TorusGeometry(0.058, 0.013, 6, 16),
    neck: taper(0.048, 0.055),
    torso: lathe([[0.001, -0.5], [0.15, -0.5], [0.148, -0.32], [0.142, -0.12], [0.152, 0.1], [0.17, 0.3], [0.178, 0.4], [0.16, 0.46], [0.11, 0.495], [0.05, 0.5], [0.001, 0.5]], 22),
    panel: kameezPanel(), collar: new T3.TorusGeometry(0.058, 0.013, 8, 22),
    vest: lathe([[0.174, -0.5], [0.165, -0.1], [0.18, 0.3], [0.185, 0.4], [0.165, 0.47]], 22),
    placket: new T3.BoxGeometry(0.03, 0.22, 0.01), button: new T3.SphereGeometry(0.006, 6, 4),
    cranium: null, // sculpted in headGeo() jaw: new T3.SphereGeometry(0.07, 18, 12), cheek: new T3.SphereGeometry(0.03, 10, 8),
    hair: new T3.SphereGeometry(0.106, 22, 12, 0, Math.PI * 2, 0, Math.PI * 0.55), sideHair: new T3.SphereGeometry(0.104, 18, 10, Math.PI * 0.6, Math.PI * 0.8, Math.PI * 0.35, Math.PI * 0.3),
    sclera: new T3.SphereGeometry(0.0135, 10, 8), iris: new T3.SphereGeometry(0.0078, 10, 8), lid: new T3.SphereGeometry(0.0145, 10, 6, 0, Math.PI * 2, 0, Math.PI * 0.42),
    brow: new T3.BoxGeometry(0.036, 0.008, 0.012), noseB: new T3.BoxGeometry(0.016, 0.045, 0.02), noseT: new T3.SphereGeometry(0.014, 10, 8), nostril: new T3.SphereGeometry(0.009, 8, 6),
    lip: new T3.SphereGeometry(0.022, 12, 6), ear: new T3.SphereGeometry(0.022, 10, 8),
    beard: new T3.SphereGeometry(0.076, 18, 12, 0, Math.PI * 2, Math.PI * 0.32, Math.PI * 0.68), stache: new T3.CapsuleGeometry(0.008, 0.045, 4, 8),
    palm: new T3.SphereGeometry(1, 12, 10), thumb: new T3.CapsuleGeometry(0.011, 0.03, 4, 8), fingers: new T3.CapsuleGeometry(0.02, 0.035, 4, 10),
    foot: new T3.CapsuleGeometry(0.035, 0.15, 4, 10), sole: new T3.BoxGeometry(0.095, 0.014, 0.27), strap: new T3.TorusGeometry(0.04, 0.008, 6, 14, Math.PI),
    topi: new T3.SphereGeometry(0.106, 22, 8, 0, Math.PI * 2, 0, Math.PI * 0.33), pakol: new T3.CylinderGeometry(0.112, 0.106, 0.07, 22), pakolRoll: new T3.TorusGeometry(0.108, 0.026, 10, 24),
    turban: new T3.TorusGeometry(0.094, 0.044, 12, 24), joint: new T3.SphereGeometry(1, 14, 10),
  };

  /* One sculpted head shape (brow ridge, eye sockets, nose, cheekbones, narrower jaw, chin) shared by everyone;
     each man gets his own painted face texture (eyes, brows, lips, moustache/beard, hairline). */
  const ANG = (d) => [Math.atan2(d.x, d.z), Math.asin(clamp(d.y, -1, 1))];
  function bump(ax, ay, cx, cy, sx, sy, a) { const dx = (ax - cx) / sx, dy = (ay - cy) / sy; return a * Math.exp(-(dx * dx + dy * dy)); }
  function headGeo() {
    const geo = new T3.SphereGeometry(0.1, 64, 48), pos = geo.attributes.position, d = V();
    for (let i = 0; i < pos.count; i++) {
      d.set(pos.getX(i), pos.getY(i), pos.getZ(i)).normalize();
      const [ax, ay] = ANG(d), front = clamp(d.z * 1.6, 0, 1);
      let h = 0;
      h += front * (bump(ax, ay, 0, -0.02, 0.07, 0.12, 0.009) + bump(ax, ay, 0, -0.17, 0.085, 0.11, 0.024) + bump(ax, ay, 0, -0.25, 0.11, 0.06, 0.008)); // bridge, nose, tip
      for (const sx of [-1, 1]) {
        h += front * (bump(ax, ay, sx * 0.34, 0.06, 0.13, 0.08, -0.008)    // eye sockets
          + bump(ax, ay, sx * 0.3, 0.2, 0.2, 0.06, 0.006)                  // brow ridge
          + bump(ax, ay, sx * 0.56, -0.12, 0.15, 0.12, 0.005)              // cheekbones
          + bump(ax, ay, sx * 0.16, -0.24, 0.05, 0.05, 0.003));            // nostrils
      }
      h += front * (bump(ax, ay, 0, -0.43, 0.3, 0.11, 0.007) + bump(ax, ay, 0, -0.74, 0.22, 0.13, 0.011)); // mouth, chin
      const r = 0.1 + h;
      let x = d.x * r, y = d.y * r, z = d.z * r;
      const low = Math.pow(clamp((-d.y - 0.15) / 0.75, 0, 1), 1.3); x *= 1 - 0.24 * low - 0.08 * low * front; // jaw narrows to the chin
      if (d.z < 0) z *= 1.06;                                                       // fuller back of the skull
      if (d.y < -0.55 && d.z < 0.3) { y *= 0.92; z *= 0.9; }                         // under the jaw / neck
      pos.setXYZ(i, x, y, z);
    }
    geo.computeVertexNormals(); return geo;
  }
  function faceTexture(look, seed) {
    let sd = seed * 9301 + 49297; const rn = () => { sd = (sd * 9301 + 49297) % 233280; return sd / 233280; };
    const Wc = 1024, Hc = 512, PX = Wc / (2 * Math.PI);
    const P = (ax, ay) => [(0.25 + ax / (2 * Math.PI)) * Wc, (Math.PI / 2 - ay) / Math.PI * Hc];
    const sk = new T3.Color(look.skin), shade = (k, a) => { const c = sk.clone().multiplyScalar(k); return `rgba(${c.r * 255 | 0},${c.g * 255 | 0},${c.b * 255 | 0},${a})`; };
    const hairC = new T3.Color(look.hair), hairS = (a) => `rgba(${hairC.r * 255 | 0},${hairC.g * 255 | 0},${hairC.b * 255 | 0},${a})`;
    const t = canvasTex(Wc, Hc, (x) => {
      x.fillStyle = '#' + sk.getHexString(); x.fillRect(0, 0, Wc, Hc);
      const blob = (ax, ay, rx, ry, col) => { const [cx, cy] = P(ax, ay), g = x.createRadialGradient(cx, cy, 0, cx, cy, rx * PX); g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)'); x.save(); x.translate(cx, cy); x.scale(1, ry / rx); x.translate(-cx, -cy); x.fillStyle = g; x.beginPath(); x.arc(cx, cy, rx * PX, 0, 6.283); x.fill(); x.restore(); };
      // skin: pores/variation, warm cheeks, shadow under the jaw and around the eyes
      for (let i = 0; i < 2500; i++) { x.fillStyle = rn() < 0.5 ? shade(0.9, 0.08) : shade(1.08, 0.07); x.fillRect(rn() * Wc, rn() * Hc, 2, 2); }
      for (const s of [-1, 1]) { blob(s * 0.55, -0.2, 0.2, 0.14, 'rgba(190,80,60,0.08)'); blob(s * 0.36, 0.07, 0.2, 0.07, shade(0.86, 0.22)); blob(s * 1.05, -0.45, 0.35, 0.5, shade(0.72, 0.3)); }
      blob(0, -0.95, 1.2, 0.35, shade(0.7, 0.5));
      blob(0, -0.2, 0.06, 0.16, shade(1.12, 0.35));  // light down the nose
      for (const s of [-1, 1]) blob(s * 0.12, -0.15, 0.05, 0.13, shade(0.84, 0.22)); // nose sides
      // eyes
      const eW = 0.14 + rn() * 0.02, eH = 0.05 + rn() * 0.012, iris = ['#2a1a10', '#3b2414', '#4a3018', '#2e2a1c'][Math.floor(rn() * 4)];
      for (const s of [-1, 1]) {
        const [cx, cy] = P(s * 0.36, 0.06), w = eW * PX, h = eH * PX;
        x.save(); x.beginPath(); x.moveTo(cx - w, cy); x.quadraticCurveTo(cx, cy - h * 1.5, cx + w, cy); x.quadraticCurveTo(cx, cy + h * 1.1, cx - w, cy); x.closePath();
        x.fillStyle = '#ece6dc'; x.fill(); x.clip();
        x.fillStyle = iris; x.beginPath(); x.arc(cx + s * w * 0.05, cy - h * 0.1, h * 0.95, 0, 6.283); x.fill();
        x.fillStyle = '#0a0604'; x.beginPath(); x.arc(cx + s * w * 0.05, cy - h * 0.1, h * 0.42, 0, 6.283); x.fill();
        x.fillStyle = 'rgba(255,255,255,0.85)'; x.beginPath(); x.arc(cx + s * w * 0.05 - h * 0.3, cy - h * 0.45, h * 0.22, 0, 6.283); x.fill();
        x.fillStyle = 'rgba(0,0,0,0.25)'; x.fillRect(cx - w, cy - h * 2, w * 2, h * 1.35); // lid shadow on the eye
        x.restore();
        x.strokeStyle = 'rgba(25,14,8,0.9)'; x.lineWidth = 3.5; x.lineCap = 'round'; x.beginPath(); x.moveTo(cx - w * 1.05, cy + 1); x.quadraticCurveTo(cx, cy - h * 1.6, cx + w * 1.05, cy + 1); x.stroke(); // upper lash line
        x.strokeStyle = shade(0.72, 0.6); x.lineWidth = 2; x.beginPath(); x.moveTo(cx - w * 0.9, cy - h * 2.1); x.quadraticCurveTo(cx, cy - h * 3.0, cx + w * 0.95, cy - h * 2.0); x.stroke(); // eyelid crease
        x.strokeStyle = shade(0.8, 0.5); x.lineWidth = 1.5; x.beginPath(); x.moveTo(cx - w * 0.85, cy + h * 0.5); x.quadraticCurveTo(cx, cy + h * 1.4, cx + w * 0.85, cy + h * 0.4); x.stroke();
        // eyebrow: many short hairs along an arch
        const bt = 0.022 + rn() * 0.018;
        for (let k = 0; k < 130; k++) { const u = k / 129, ax = s * (0.17 + u * 0.4), ay = 0.215 + Math.sin(u * Math.PI * 0.85) * 0.035 - u * 0.02 + (rn() - 0.5) * bt, [px, py] = P(ax, ay);
          x.strokeStyle = hairS(0.8); x.lineWidth = 2.6; x.beginPath(); x.moveTo(px, py); x.lineTo(px + s * 6, py - 2 - rn() * 2); x.stroke(); }
      }
      // nostrils
      for (const s of [-1, 1]) { const [cx, cy] = P(s * 0.07, -0.265); x.fillStyle = shade(0.45, 0.85); x.beginPath(); x.ellipse(cx, cy, 6, 3.5, s * 0.3, 0, 6.283); x.fill(); }
      // mouth
      const mw = (0.19 + rn() * 0.03) * PX, [mx, my] = P(0, -0.44), lip = sk.clone().multiplyScalar(0.7).lerp(new T3.Color('#9a5a50'), 0.28);
      x.fillStyle = '#' + lip.getHexString(); x.beginPath(); x.moveTo(mx - mw, my); x.quadraticCurveTo(mx - mw * 0.4, my - 9, mx, my - 5); x.quadraticCurveTo(mx + mw * 0.4, my - 9, mx + mw, my); x.quadraticCurveTo(mx, my + 3, mx - mw, my); x.fill();
      x.fillStyle = '#' + lip.clone().multiplyScalar(1.12).getHexString(); x.beginPath(); x.moveTo(mx - mw * 0.9, my + 1); x.quadraticCurveTo(mx, my + 14, mx + mw * 0.9, my + 1); x.quadraticCurveTo(mx, my + 3, mx - mw * 0.9, my + 1); x.fill();
      x.strokeStyle = 'rgba(40,15,10,0.8)'; x.lineWidth = 2.2; x.beginPath(); x.moveTo(mx - mw, my); x.quadraticCurveTo(mx, my + 3, mx + mw, my); x.stroke();
      blob(0, -0.56, 0.12, 0.04, shade(0.75, 0.4)); // shadow under the lower lip
      // facial hair
      if (look.beard === 'stubble' || look.beard === 'full') {
        const full = look.beard === 'full';
        for (let i = 0; i < (full ? 9000 : 5000); i++) {
          const ax = (rn() - 0.5) * 2.6, ay = -0.3 - rn() * 1.0;
          const onCheek = Math.abs(ax) > 0.25 || ay < -0.52; const nearMouth = Math.abs(ax) < 0.2 && ay > -0.53 && ay < -0.37;
          if (nearMouth) continue; if (!onCheek && ay > -0.36) continue; if (Math.abs(ax) > 0.75 + (ay + 1.3) * 0.2 && ay > -0.5) continue;
          const [px, py] = P(ax, ay); x.strokeStyle = hairS(full ? 0.55 : 0.28); x.lineWidth = full ? 2 : 1.2;
          x.beginPath(); x.moveTo(px, py); x.lineTo(px + (rn() - 0.5) * 3, py + (full ? 4 : 2)); x.stroke();
        }
      }
      if (look.beard) { // moustache
        for (let k = 0; k < 160; k++) { const u = rn() * 2 - 1, ax = u * 0.17, ay = -0.36 - Math.abs(u) * 0.05 + (rn() - 0.5) * 0.03, [px, py] = P(ax, ay);
          x.strokeStyle = hairS(0.85); x.lineWidth = 2.2; x.beginPath(); x.moveTo(px, py); x.lineTo(px + u * 4, py + 4); x.stroke(); }
      }
      // hairline: scalp hair over the top/back, with a soft, uneven edge at the forehead and temples
      const edgeAt = (ax) => 0.5 + 0.08 * Math.cos(ax * 2) - (Math.abs(ax) > 1.3 ? 0.35 : 0) - (Math.abs(ax) > 2.2 ? 0.25 : 0);
      x.fillStyle = hairS(1); x.beginPath(); x.moveTo(0, 0);
      for (let k = 0; k <= 200; k++) { const ax = -Math.PI + k / 200 * 2 * Math.PI, [px, py] = P(ax, edgeAt(ax) + 0.04); x.lineTo(px, py); }
      x.lineTo(Wc, 0); x.closePath(); x.fill();
      for (let i = 0; i < 14000; i++) {
        const ax = (rn() - 0.5) * 2 * Math.PI, edge = 0.5 + 0.08 * Math.cos(ax * 2) - (Math.abs(ax) > 1.3 ? 0.35 : 0) - (Math.abs(ax) > 2.2 ? 0.25 : 0);
        const ay = edge + rn() * (Math.PI / 2 - edge), [px, py] = P(ax, ay);
        x.strokeStyle = rn() < 0.3 ? 'rgba(255,255,255,0.08)' : hairS(0.7); x.lineWidth = 1.6; x.beginPath(); x.moveTo(px, py); x.lineTo(px + (rn() - 0.5) * 4, py + 6); x.stroke();
      }
    });
    if (Q.face < Wc) { const c2 = document.createElement('canvas'); c2.width = Q.face; c2.height = Q.face / 2; c2.getContext('2d').drawImage(t.image, 0, 0, c2.width, c2.height); t.image = c2; t.needsUpdate = true; }
    return t;
  }
  let HEAD_GEO = null;
  const UNITY = V(0, 1, 0);
  function orientSeg(mesh, a, b) { // a cylinder whose top sits at b and bottom at a
    tmpV.subVectors(b, a); const len = tmpV.length() || 1e-4; mesh.position.addVectors(a, b).multiplyScalar(0.5);
    mesh.quaternion.setFromUnitVectors(UNITY, tmpV.multiplyScalar(1 / len)); mesh.scale.set(1, len, 1);
  }
  function basisQuat(q, up, fwd) { const x = V().crossVectors(up, fwd).normalize(), f = V().crossVectors(x, up).normalize(); tmpM.makeBasis(x, up.clone().normalize(), f); q.setFromRotationMatrix(tmpM); }
  const cloth = (col, extra) => Q.phys ? new T3.MeshPhysicalMaterial(Object.assign({ color: col, map: TEX.cloth, roughness: 0.88, metalness: 0, sheen: 0.8, sheenRoughness: 0.6, sheenColor: new T3.Color(col).lerp(new T3.Color('#ffffff'), 0.5) }, extra || {}))
    : new T3.MeshStandardMaterial(Object.assign({ color: col, map: TEX.cloth, roughness: 0.9, metalness: 0 }, extra || {}));
  const skinMat = (opts) => Q.phys ? new T3.MeshPhysicalMaterial(Object.assign({ roughness: 0.52, metalness: 0, sheen: 0.35, sheenRoughness: 0.5, sheenColor: new T3.Color('#ffb59a'), clearcoat: 0.08, clearcoatRoughness: 0.6 }, opts)) : new T3.MeshStandardMaterial(Object.assign({ roughness: 0.6, metalness: 0 }, opts));
  /* ---------- drawing the people faster ----------
     Every villager is ~40 separate pieces, and the phone draws each piece on its own (10 people = 400 draws a frame).
     Pieces that are the same shape with the same kind of material (every upper arm, every palm, every shalwar leg...)
     are drawn together in one go, each copy placed exactly where the real piece is this frame and with its own colour.
     The real pieces still exist and are animated as before; they are only kept out of the picture (layer 31).
     Nothing about the poses, sizes, colours or shading changes. If anything goes wrong, it switches itself off. */
  const BATCH = { on: typeof T3.InstancedMesh === 'function' && !/[?&]nobatch=1/.test((typeof location !== 'undefined' && location.search) || ''), people: new Set(), dirty: true, groups: [], solo: [] };
  const HIDE_LAYER = 31, bCol = new T3.Color();
  function matSig(m) {
    const c = x => x && x.getHexString ? x.getHexString() : '';
    return [m.type, m.side, m.map ? m.map.uuid : '', m.roughness, m.metalness, m.transparent ? 1 : 0, m.opacity, m.sheen || 0, c(m.sheenColor), m.sheenRoughness || 0,
      m.clearcoat || 0, m.clearcoatRoughness || 0, c(m.emissive), m.emissiveIntensity, m.flatShading ? 1 : 0, m.wireframe ? 1 : 0].join('|');
  }
  function unbatch() {
    for (const b of BATCH.groups) { scene.remove(b.im); try { b.im.dispose(); } catch (e) { } try { b.mat.dispose(); } catch (e) { } for (const m of b.list) m.layers.set(0); }
    BATCH.groups = [];
  }
  function rebuildBatches() {
    unbatch(); BATCH.dirty = false;
    const by = new Map();
    for (const P of BATCH.people) P.g.traverse(o => {
      if (!o.isMesh || !o.material || Array.isArray(o.material) || o.material.transparent || o.children.length) return;
      const k = o.geometry.uuid + '#' + matSig(o.material) + '#' + (o.castShadow ? 1 : 0) + (o.receiveShadow ? 1 : 0);
      let a = by.get(k); if (!a) by.set(k, a = []); a.push(o);
    });
    for (const list of by.values()) {
      if (list.length < 2) continue;   // a one-off piece (each face has its own painted texture) stays as it is
      const src = list[0], mat = src.material.clone(); mat.color.set('#ffffff');
      const im = new T3.InstancedMesh(src.geometry, mat, list.length);
      im.castShadow = src.castShadow; im.receiveShadow = src.receiveShadow; im.frustumCulled = false;
      for (let i = 0; i < list.length; i++) { im.setMatrixAt(i, list[i].matrixWorld); im.setColorAt(i, list[i].material.color); }
      for (const m of list) m.layers.set(HIDE_LAYER);
      scene.add(im); BATCH.groups.push({ im, mat, list });
    }
  }
  function shown(o) { for (let p = o; p; p = p.parent) { if (!p.visible) return false; if (p === scene) return true; } return false; }
  function syncBatches() {
    if (!BATCH.on) return;
    try {
      if (BATCH.dirty) rebuildBatches();
      scene.updateMatrixWorld();
      for (const b of BATCH.groups) {
        let n = 0;
        for (const m of b.list) { if (!shown(m)) continue; b.im.setMatrixAt(n, m.matrixWorld); b.im.setColorAt(n, bCol.copy(m.material.color)); n++; }
        b.im.count = n; b.im.instanceMatrix.needsUpdate = true; if (b.im.instanceColor) b.im.instanceColor.needsUpdate = true;
      }
    } catch (e) { BATCH.on = false; try { unbatch(); } catch (e2) { } }
  }
  class Person {
    constructor(look, kam, shal) {
      this.g = new T3.Group(); scene.add(this.g); BATCH.people.add(this); BATCH.dirty = true;
      const sk = new T3.Color(look.skin);
      const skin = skinMat({ color: sk });
      const lipM = new T3.MeshStandardMaterial({ color: sk.clone().multiplyScalar(0.72).lerp(new T3.Color('#8a3f3a'), 0.3), roughness: 0.45 });
      const kamM = cloth(kam, { side: T3.DoubleSide }), shalM = cloth(shal, { roughness: 0.95 }), style = look.shirt || 'tee';
      const hairM = new T3.MeshStandardMaterial({ color: look.hair, roughness: 0.7, metalness: 0.05 });
      const white = new T3.MeshStandardMaterial({ color: '#f1ece4', roughness: 0.25 }), iris = new T3.MeshStandardMaterial({ color: '#2b1a10', roughness: 0.15 });
      const shoeM = new T3.MeshStandardMaterial({ color: look.shoe || '#e9e6df', roughness: 0.7 }), shoeSoleM = new T3.MeshStandardMaterial({ color: '#f4f2ee', roughness: 0.8 });
      const BIG = [G.torso, G.thigh, G.shin, G.upper, G.fore, G.sleeve, G.vest];
      const add = (geom, mat, parent = this.g) => { const m = new T3.Mesh(geom, mat); m.castShadow = Q.shadow > 0 && (Q.phys || BIG.includes(geom) || geom === HEAD_GEO); m.receiveShadow = Q.shadow > 0; parent.add(m); return m; };
      const opt = (geom, mat, parent) => Q.detail ? add(geom, mat, parent) : null;
      this.p = {};
      for (const s of ['A', 'B']) {
        this.p['up' + s] = add(G.upper, skin); this.p['sl' + s] = add(G.sleeve, kamM); this.p['fo' + s] = add(G.fore, skin); this.p['cuff' + s] = null;   // short sleeve over a real-shaped arm
        this.p['th' + s] = add(G.thigh, shalM); this.p['sh' + s] = add(G.shin, shalM); this.p['ank' + s] = null;
        this.p['jS' + s] = add(G.joint, kamM); this.p['jE' + s] = add(G.joint, skin); this.p['jK' + s] = add(G.joint, shalM); this.p['jH' + s] = opt(G.joint, shalM);
        this.p['jS' + s].scale.setScalar(0.064); if (this.p['jE' + s]) this.p['jE' + s].scale.setScalar(0.034); this.p['jK' + s].scale.setScalar(0.079); if (this.p['jH' + s]) this.p['jH' + s].scale.setScalar(0.092);
        // hand: palm + finger block + thumb, oriented along the forearm
        const h = this.p['hand' + s] = new T3.Group(); this.g.add(h);
        const palm = add(G.palm, skin, h); palm.scale.set(0.042, 0.048, 0.02); palm.position.y = 0.02;
        const fing = add(G.fingers, skin, h); fing.scale.set(1, 1, 0.55); fing.position.set(0, 0.075, 0.004); fing.rotation.x = 0.35;
        const th = opt(G.thumb, skin, h); if (th) { th.position.set(s === 'A' ? 0.035 : -0.035, 0.035, 0.012); th.rotation.set(0.4, 0, s === 'A' ? -0.7 : 0.7); }
        // chappal with the bare foot on it
        const f = this.p['foot' + s] = new T3.Group(); this.g.add(f);
        add(G.shoeSole, shoeSoleM, f).position.y = 0.014; const ft = add(G.shoe, shoeM, f); ft.rotation.x = Math.PI / 2; ft.scale.set(1.0, 1, 0.82); ft.position.set(0, 0.05, 0.015);

      }
      this.p.torso = add(G.torso, kamM); this.p.hips = add(G.hips, shalM); this.p.neck = add(G.neck, skin);
      this.tucked = !!look.tucked; this.p.hem = this.tucked ? null : add(G.shirtHem, kamM); this.p.belt = this.tucked ? add(G.belt, new T3.MeshStandardMaterial({ color: '#2a1d14', roughness: 0.5 })) : null;
      this.p.collar = style !== 'tee' ? opt(G.collar, kamM) : null; this.p.placket = style === 'shirt' && Q.detail ? add(G.placket, cloth(new T3.Color(kam).multiplyScalar(0.85))) : null;
      if (false) this.p.vest = add(G.vest, cloth(look.vest, { side: T3.DoubleSide, roughness: 0.8 }));
      // head (local +Z = face, +Y = up)
      const hd = this.head = new T3.Group(); this.g.add(hd);
      if (!HEAD_GEO) HEAD_GEO = headGeo();
      const faceM = skinMat({ map: faceTexture(look, look.seed !== undefined ? look.seed : (look.skin + look.hair).split('').reduce((n, ch) => n + ch.charCodeAt(0), 7)) });
      const headM = add(HEAD_GEO, faceM, hd); headM.scale.set(0.84, 1.12, 0.98);
      this.lids = [];
      if (Q.detail) for (const sx of [-1, 1]) { const l = new T3.Mesh(G.lid, skin); l.position.set(sx * 0.0295, 0.007, 0.0795); l.scale.set(1.45, 0.9, 0.9); l.rotation.x = Math.PI / 2 - 0.1; l.visible = false; hd.add(l); this.lids.push(l); }
      this.blinkAt = T + 1 + Math.random() * 4;
      for (const sx of [-1, 1]) { const ear = add(G.ear, skin, hd); ear.scale.set(0.42, 1.25, 0.85); ear.position.set(sx * 0.082, 0.004, -0.008); }
      if (look.hairStyle !== 'bald') { const hair = add(G.hair, hairM, hd); hair.position.set(0, 0.012, -0.016); hair.rotation.x = -0.42; hair.scale.set(0.88, 1.08, 1.0); if (look.capT) { hair.scale.set(0.85, 0.95, 0.97); hair.position.y = 0.004; } }
      if (look.hairStyle === 'long') { const h2 = add(G.joint, hairM, hd); h2.scale.set(0.085, 0.07, 0.045); h2.position.set(0, -0.055, -0.07); }
      if (look.beard === 'full') { // a little volume on the jaw under the painted beard
        const bm = new T3.MeshStandardMaterial({ color: look.hair, roughness: 1, transparent: true, opacity: 0.85 });
        const b = add(G.beard, bm, hd); b.position.set(0, -0.042, 0.008); b.scale.set(1.0, 0.95, 1.12);
      }
      if (look.capT) {
        const cm = cloth(look.capC);
        if (look.capT === 'cap') { const d = add(G.capDome, cm, hd); d.position.set(0, 0.034, -0.004); d.scale.set(0.84, 0.98, 0.99); d.rotation.x = -0.06; const b = add(G.capBrim, cm, hd); b.position.set(0, 0.04, 0.098); b.rotation.x = 0.1; b.scale.set(0.95, 1, 1.05); }
        else if (look.capT === 'topi') { const c = add(G.capDome, cm, hd); c.position.set(0, 0.05, -0.006); c.scale.set(0.8, 0.74, 0.95); }
        else if (look.capT === 'pakol') { const c = add(G.pakol, cm, hd); c.position.y = 0.1; const r = add(G.pakolRoll, cm, hd); r.rotation.x = Math.PI / 2; r.position.y = 0.068; }
        else { const r1 = add(G.turban, cm, hd); r1.rotation.x = Math.PI / 2; r1.position.y = 0.06; r1.rotation.y = 0.15; const r2 = add(G.turban, cm, hd); r2.rotation.x = Math.PI / 2 - 0.15; r2.position.y = 0.1; r2.scale.setScalar(0.86); const t = add(G.joint, cm, hd); t.scale.set(0.085, 0.05, 0.085); t.position.y = 0.125; }
      }
      this.danda = null;
      // small face and clothing details: hidden when the person is far away (they would be a pixel or two, but each one
      // costs the phone a separate draw, and with several players that was the main source of lag on cheap phones)
      const DET = new Set([G.sclera, G.iris, G.lid, G.brow, G.noseB, G.noseT, G.nostril, G.lip, G.ear, G.stache, G.button, G.placket, G.cheek].filter(Boolean));   // face details only: nothing on the body, arms or legs is ever hidden
      this.small = []; this.g.traverse(o => { if (o.isMesh && DET.has(o.geometry)) this.small.push(o); }); this.near = true;
    }
    setLod(near) {
      if (this.near === near) return; this.near = near;
      for (const m of this.small) m.visible = near && !(this.lids.includes(m));
    }
    addDanda() {
      const g = new T3.CylinderGeometry(0.016, 0.019, 1, 12); const pos = g.attributes.position; // a slightly crooked, hand-cut stick
      for (let i = 0; i < pos.count; i++) { const y = pos.getY(i); pos.setX(i, pos.getX(i) + Math.sin(y * 7) * 0.003); }
      g.computeVertexNormals();
      this.danda = new T3.Mesh(g, new T3.MeshStandardMaterial({ map: TEX.wood, color: '#ffe8c8', roughness: 0.5, emissive: '#3a2008', emissiveIntensity: 0.5 }));
      this.danda.castShadow = true; outline(this.danda, 1.45, 1.0, 1.45); scene.add(this.danda);
    }
    /* J: 3D joints. A/B = the two sides. */
    pose(J) {
      const p = this.p;
      for (const s of ['A', 'B']) {
        orientSeg(p['up' + s], J['el' + s], J['sh' + s]); orientSeg(p['sl' + s], J['el' + s], J['sh' + s]); orientSeg(p['fo' + s], J['wr' + s], J['el' + s]);
        orientSeg(p['th' + s], J['kn' + s], J['hip' + s]); orientSeg(p['sh' + s], J['an' + s], J['kn' + s]);
        p['jS' + s].position.copy(J['sh' + s]); p['jE' + s].position.copy(J['el' + s]); p['jK' + s].position.copy(J['kn' + s]); if (p['jH' + s]) p['jH' + s].position.copy(J['hip' + s]);
        tmpV.subVectors(J['wr' + s], J['el' + s]).normalize();
        if (p['cuff' + s]) { p['cuff' + s].position.copy(J['wr' + s]).addScaledVector(tmpV, -0.01); p['cuff' + s].quaternion.setFromUnitVectors(V(0, 0, 1), tmpV); }
        const h = p['hand' + s]; h.position.copy(J['wr' + s]); h.quaternion.setFromUnitVectors(UNITY, tmpV);
        if (p['ank' + s]) { tmpV.subVectors(J['kn' + s], J['an' + s]).normalize(); p['ank' + s].position.copy(J['an' + s]).addScaledVector(tmpV, 0.02); p['ank' + s].quaternion.setFromUnitVectors(V(0, 0, 1), tmpV); }
        const f = p['foot' + s], fd = J.footF || J.bodyF; f.position.set(J['an' + s].x + fd.x * 0.05, Math.max(0, J['an' + s].y - 0.075), J['an' + s].z + fd.z * 0.05); f.rotation.set(0, Math.atan2(fd.x, fd.z), 0);
      }
      // torso from pelvis to chest, facing bodyF
      const spine = V().subVectors(J.chest, J.pelvis), len = spine.length(); spine.normalize();
      p.torso.position.addVectors(J.pelvis, J.chest).multiplyScalar(0.5).addScaledVector(spine, 0.03); basisQuat(p.torso.quaternion, spine, J.bodyF); p.torso.scale.set(1.0, len * 1.12, 0.7);
      const fwd = V().crossVectors(V().crossVectors(spine, J.bodyF).normalize(), spine).normalize();
      if (p.placket) p.placket.position.copy(J.chest).addScaledVector(spine, -0.06).addScaledVector(fwd, 0.118); if (p.placket) p.placket.quaternion.copy(p.torso.quaternion);
      if (p.collar) { p.collar.position.copy(J.chest).addScaledVector(spine, 0.05); p.collar.quaternion.setFromUnitVectors(V(0, 0, 1), spine); }
      if (p.vest) { p.vest.position.copy(p.torso.position).addScaledVector(spine, len * 0.04); p.vest.quaternion.copy(p.torso.quaternion); p.vest.scale.set(1.04, len * 0.92, 0.74); }
      // kameez hangs from the hips to below the knees (gravity + lean + sway), widening over the legs
      // trousers meet at the hips; the shirt either hangs over the belt line (untucked) or is tucked in with a belt
      p.hips.position.copy(J.pelvis).addScaledVector(spine, 0.02); basisQuat(p.hips.quaternion, spine, J.bodyF); p.hips.scale.set(0.165, 0.12, 0.115);
      const waist = J.pelvis.clone().addScaledVector(spine, 0.1);
      if (p.hem) { const hang = spine.clone().negate().lerp(V(0, -1, 0).add(J.sway || V()), 0.35).normalize(), L = 0.2;
        p.hem.position.copy(waist).addScaledVector(hang, L / 2); basisQuat(p.hem.quaternion, hang.clone().negate(), J.bodyF); p.hem.scale.set(1.0, L, 0.74); }
      if (p.belt) { p.belt.position.copy(J.pelvis).addScaledVector(spine, 0.07); basisQuat(p.belt.quaternion, spine, J.bodyF); p.belt.scale.set(1, 1, 0.72); }
      orientSeg(p.neck, J.chest.clone().addScaledVector(spine, -0.02), J.headC.clone().addScaledVector(J.headU, -0.06));
      if (this.lids.length && this.near) { if (T > this.blinkAt + 0.13) this.blinkAt = T + 2 + Math.random() * 4; const b = T > this.blinkAt; this.lids[0].visible = this.lids[1].visible = b; }
      this.head.position.copy(J.headC); basisQuat(this.head.quaternion, J.headU, J.headF); this.head.scale.setScalar(J.scale || 1);
    }
    setDanda(grip, dir, len) { if (!this.danda) return; if (!grip) { this.danda.visible = false; return; } this.danda.visible = true; const a = grip.clone().addScaledVector(dir, -0.06), b = grip.clone().addScaledVector(dir, len); orientSeg(this.danda, a, b); }
    handWorld() { return null; }
    dispose() { scene.remove(this.g); if (this.danda) scene.remove(this.danda); if (BATCH.people.delete(this)) { BATCH.dirty = true; this.g.traverse(o => { if (o.isMesh) o.layers.set(0); }); } }
  }

  function createPerson(look, kam, shal) { return new Person(look, kam, shal); }

  /* 2D side-view pose (game.js fielderPose/specPose) -> 3D joints. u = forward along `face`, v = up; lateral spread on z */
  function sagittalJoints(P, ox, oz, face, sc, build) {
    const at = torsoAt(P), ln = P.lean;
    const SF = at(0.03, 0.47), SB = at(-0.05, 0.48), hipF = at(0.05, 0.03), hipB = at(-0.05, 0.03), ank = f => [f[0], f[1] + 0.075];
    const [kB, aB] = ik(hipB, ank(P.feet[0]), 0.45, 0.44, j => -j[0]), [kF, aF] = ik(hipF, ank(P.feet[1]), 0.45, 0.44, j => -j[0]);
    const elb = j => j[1] + 0.6 * j[0], [eB, wB] = ik(SB, P.hands[0], 0.29, 0.27, elb), [eF, wF] = ik(SF, P.hands[1], 0.29, 0.27, elb);
    const M = (q, lat) => V(ox + face * q[0] * sc * build, q[1] * sc, oz + lat * sc);
    const ha = -ln * 0.45 + (P.tilt || 0), C = at(0.035, 0.7);
    return {
      pelvis: M(at(0, 0.02), 0), chest: M(at(0, 0.46), 0), headC: M(C, 0),
      headF: V(face * Math.cos(ha), Math.sin(ha), 0).normalize(), headU: V(-face * Math.sin(ha), Math.cos(ha), 0).normalize(),
      shA: M(SB, -0.17), elA: M(eB, -0.2), wrA: M(wB, -0.19), shB: M(SF, 0.17), elB: M(eF, 0.2), wrB: M(wF, 0.19),
      hipA: M(hipB, -0.09), knA: M(kB, -0.1), anA: M(aB, -0.1), hipB: M(hipF, 0.09), knB: M(kF, 0.1), anB: M(aF, 0.1),
      bodyF: V(face, 0, 0), footF: V(face, 0, 0), kneeSpread: 0, scale: sc, hand: M(wF, 0.19)
    };
  }
  /* 3D batsman: deep hip hinge over the gilli (stance), upright one-handed swing, laying the danda down, standing aside */
  function ik3(a, b, l1, l2, pole) {
    const d = V().subVectors(b, a), L = clamp(d.length(), Math.abs(l1 - l2) + 1e-3, l1 + l2 - 1e-3), dir = d.normalize();
    const x = (l1 * l1 - l2 * l2 + L * L) / (2 * L), h = Math.sqrt(Math.max(0, l1 * l1 - x * x));
    const pp = pole.clone().addScaledVector(dir, -pole.dot(dir)); if (pp.lengthSq() < 1e-6) pp.set(0, 0, 1); pp.normalize();
    const j = a.clone().addScaledVector(dir, x).addScaledVector(pp, h), e = j.clone().addScaledVector(V().subVectors(b, j).normalize(), l2);
    return [j, e];
  }
  /* footwork while bouncing: one foot at a time lifts, travels and lands, following the gilli when it drifts,
     plus small rhythm steps in place (staying light on the feet) */
  const FEET = { A: null, B: null, next: 'B', beat: 0.5, shift: 0 };
  const hyp = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
  function updateFeet(dt) {
    if (jugFocus < 0.01 || bat.mode !== 'play') { FEET.A = FEET.B = null; FEET.shift = 0; return; }
    const bx = BX + bat.off, bz = BZ, follow = clamp((g.x - JX) * 1.3, -0.14, 0.14);
    const want = { A: V(bx - 0.28 + follow, 0.075, bz + 0.03), B: V(bx + 0.26 + follow, 0.075, bz + 0.08) };
    for (const k of ['A', 'B']) if (!FEET[k]) FEET[k] = { pos: want[k].clone(), from: want[k].clone(), to: want[k].clone(), t: 1, dur: 0.22, h: 0.06 };
    FEET.beat -= dt;
    const busy = FEET.A.t < 1 || FEET.B.t < 1;
    if (!busy && S === 'juggle' && !sub.ended) {
      const dA = hyp(FEET.A.pos, want.A), dB = hyp(FEET.B.pos, want.B);
      const k = Math.max(dA, dB) > 0.045 ? (dA > dB ? 'A' : 'B') : FEET.next, drift = Math.max(dA, dB) > 0.045;
      if (drift || FEET.beat <= 0) {
        const f = FEET[k], to = want[k].clone();
        if (!drift) { to.x += (Math.random() - 0.5) * 0.05; to.z += (Math.random() - 0.5) * 0.04; }
        f.from.copy(f.pos); f.to.copy(to); f.t = 0; f.dur = drift ? 0.2 : 0.26; f.h = drift ? 0.085 : 0.05;
        FEET.next = k === 'A' ? 'B' : 'A'; FEET.beat = 0.55 + Math.random() * 0.45; FEET.moving = k;
      }
    }
    FEET.shift = 0;
    for (const k of ['A', 'B']) {
      const f = FEET[k]; if (f.t >= 1) continue;
      f.t = Math.min(1, f.t + dt / f.dur); const e = f.t * f.t * (3 - 2 * f.t);
      f.pos.copy(f.from).lerp(f.to, e); f.pos.y = 0.075 + Math.sin(Math.PI * f.t) * f.h;
      FEET.shift = (k === 'A' ? 0.025 : -0.025) * Math.sin(Math.PI * f.t);     // weight moves onto the standing foot
      if (f.t >= 1) { f.pos.y = 0.075; spawnDust(f.pos.x, 0.01, f.pos.z, 3, '#c9a06a', 0.35); if (typeof SFX0 !== 'undefined' && SFX0.step) SFX0.step(); }
    }
  }
  /* the strike: a one-handed forehand swing in 3D. u = 0 backlift (hand high by the right shoulder), 0.25 loaded
     (danda laid back behind him, shoulders turned away), 0.5 contact (danda meets the gilli in the ring in front of him),
     0.75 swing-through, 1 finish (danda wrapped over the left shoulder). Hand positions are relative to his feet. */
  const SWK = [
    { u: 0,    h: [-0.34, 1.90, 0.30],  d: [-0.50, 0.86, 0.00],  yaw: 0,    sh: 0,     fr: [0.35, -0.10, 0.30] },   // backlift
    { u: 0.25, h: [-0.49, 1.48, -0.22], d: [-0.55, 0.42, -0.72], yaw: -0.6, sh: -0.05, fr: [0.40, -0.05, 0.35] },   // loaded: turned away
    { u: 0.4,  h: [-0.34, 1.15, 0.02],  d: [-0.78, 0.12, -0.62], yaw: -0.2, sh: -0.01, fr: [0.35, -0.15, 0.30] },   // the stick trails the hand...
    { u: 0.5,  h: [-0.085, 1.03, 0.195], d: [0.97, 0.05, 0.22],  yaw: 0.35, sh: 0.03,  fr: [0.25, -0.30, 0.20] },   // ...then whips through the gilli
    { u: 0.75, h: [0.30, 1.40, 0.28],   d: [0.30, 0.85, -0.43],  yaw: 0.9,  sh: 0.06,  fr: [0.05, -0.40, 0.12] },   // swing-through
    { u: 1,    h: [0.24, 1.66, 0.06],   d: [-0.30, 0.70, -0.65], yaw: 1.2,  sh: 0.07,  fr: [0.00, -0.42, 0.05] }];  // finish: chest to the field
  const sm3 = t => t * t * (3 - 2 * t);
  function swingPose(u, miss) {
    u = clamp(u, 0, 1); let i = 0; while (i < SWK.length - 2 && u > SWK[i + 1].u) i++;
    const A = SWK[i], B = SWK[i + 1], t = sm3(clamp((u - A.u) / (B.u - A.u), 0, 1)), L3 = (p, q) => V(lerp(p[0], q[0], t), lerp(p[1], q[1], t), lerp(p[2], q[2], t));
    // the stick turns around him (heading + elevation), sweeping round the front, rather than blending straight across
    const hd = v => Math.atan2(v[0], v[2]), el = v => Math.asin(clamp(v[1] / Math.hypot(v[0], v[1], v[2]), -1, 1));
    let ya = hd(A.d), dy = hd(B.d) - ya; dy = Math.atan2(Math.sin(dy), Math.cos(dy));
    if (Math.abs(dy) > 2.5 && Math.cos(ya + dy / 2) < 0) dy -= Math.sign(dy) * Math.PI * 2;
    const yy = ya + dy * t, ee = lerp(el(A.d), el(B.d), t), dirI = V(Math.sin(yy) * Math.cos(ee), Math.sin(ee), Math.cos(yy) * Math.cos(ee));
    const P = { h: L3(A.h, B.h), d: dirI, yaw: lerp(A.yaw, B.yaw, t), sh: lerp(A.sh, B.sh, t), fr: L3(A.fr, B.fr) };
    if (miss && u > 0.5) { const k = (u - 0.5) * 2; P.yaw += 0.25 * k; P.sh += 0.04 * k; P.h.y -= 0.08 * Math.sin(k * Math.PI); }   // a whiff: he over-rotates and drops a little
    return P;
  }
  let swW = 0, swU = 0;
  function batsmanJoints() {
    const P2 = batPose(), c = P2.bend, m = bat.mode, a = bat.a, bx = BX + bat.off + (bat.run || 0), bz = BZ;
    const th = lerp(0.06, 1.25, c), hy = lerp(0.95, 0.74, c);
    const pelvis = V(bx + P2.hx, hy, bz - 0.12 * c), spine = V(0, Math.cos(th), Math.sin(th)), chest = pelvis.clone().addScaledVector(spine, 0.5);
    const shR = chest.clone().add(V(-0.18, -0.02, 0.02 * c)), shL = chest.clone().add(V(0.18, -0.02, 0.02 * c));
    const hipR = pelvis.clone().add(V(-0.09, 0, 0)), hipL = pelvis.clone().add(V(0.09, 0, 0));
    const anR = V(bx + P2.fL[0], 0.075, bz), anL = V(bx + P2.fR[0], 0.075, bz);
    /* swinging: the whole body turns with the danda. Shoulders coil away, then hips and shoulders rotate through the
       gilli (hips less than shoulders), weight moves onto the front foot and the back foot pivots up onto its toes. */
    let SWP = null, J_bodyF = V(0, 0, 1);
    if (swW > 0.001 && m === 'play') {
      SWP = swingPose(swU, bat.swMiss);
      const w = swW, yaw = SWP.yaw * w, sh = SWP.sh * w, piv = pelvis.clone();
      const turn = (v, k) => { const d = V().subVectors(v, piv); d.applyAxisAngle(UP, k); v.copy(piv).add(d); };
      for (const v of [shR, shL, chest]) turn(v, yaw);
      turn(hipR, yaw * 0.6); turn(hipL, yaw * 0.6);
      for (const v of [pelvis, hipR, hipL]) v.x += sh;
      for (const v of [chest, shR, shL]) v.x += sh * 1.4;
      const pv = clamp((swU - 0.45) * 2.2, 0, 1) * w; anR.y += 0.05 * pv; anR.x += 0.06 * pv; anR.z += 0.03 * pv;
      J_bodyF = V(0, 0, 1).applyAxisAngle(UP, yaw * 0.85);
    }
    const look = (S === 'pop' || S === 'juggle' || S === 'jugready') ? V(g.x, g.y, g.z || 0) : V(0.05, 0.05, 0);
    const headC = chest.clone().addScaledVector(V(0, Math.cos(th * 0.75), Math.sin(th * 0.75)), 0.2);
    /* bouncing the gilli: a low, balanced, completely focused stance. Knees bent, weight forward over the danda,
       hips and shoulders shifting to stay under the gilli, a slow controlled sway, a small knee-give on every flick.
       The danda hand stays exactly where the game's bounce physics expects it. */
    const jf = m === 'play' ? jugFocus : 0;
    if (jf > 0.001) {
      const t = T, bal = clamp((g.x - JX) * 0.8, -0.07, 0.07) * (S === 'juggle' ? 1 : 0);
      const dip = Math.max(0, a) * 0.09, sway = Math.sin(t * 1.3) * 0.012, breathe = Math.sin(t * 2.1) * 0.006, lean = 0.34;
      const pel = V(bx + 0.03 + bal * 0.6 + sway + FEET.shift, 0.83 - dip + breathe - Math.abs(FEET.shift) * 0.4, bz - 0.03);
      const sp = V(bal * 0.5, Math.cos(lean), Math.sin(lean)).normalize(), ch = pel.clone().addScaledVector(sp, 0.48);
      pelvis.lerp(pel, jf); chest.lerp(ch, jf);
      shR.lerp(ch.clone().add(V(-0.18, -0.03, 0.03)), jf); shL.lerp(ch.clone().add(V(0.18, -0.03, 0.03)), jf);
      hipR.lerp(pel.clone().add(V(-0.1, 0, 0)), jf); hipL.lerp(pel.clone().add(V(0.1, 0, 0)), jf);
      anR.lerp(FEET.A ? FEET.A.pos : V(bx - 0.28, 0.075, bz + 0.03), jf); anL.lerp(FEET.B ? FEET.B.pos : V(bx + 0.26, 0.075, bz + 0.08), jf);
      headC.lerp(ch.clone().addScaledVector(V(0, Math.cos(lean * 0.7), Math.sin(lean * 0.7)), 0.2), jf);
    }
    if (bat.runV) { const ph = T * 12, dir = Math.sign(bat.runV) || 1, k = Math.min(1, Math.abs(bat.runV) * 1.6);
      anR.x += Math.sin(ph) * 0.24 * k * dir; anR.y += Math.max(0, Math.cos(ph)) * 0.2 * k;
      anL.x -= Math.sin(ph) * 0.24 * k * dir; anL.y += Math.max(0, -Math.cos(ph)) * 0.2 * k;
      pelvis.y += Math.abs(Math.sin(ph)) * 0.03 * k; pelvis.x += dir * 0.05 * k; chest.x += dir * 0.1 * k; }
    const [knR] = ik3(hipR, anR, 0.45, 0.44, V(-0.25, 0, 1)), [knL] = ik3(hipL, anL, 0.45, 0.44, V(0.25, 0, 1));
    const hf = V().subVectors(look, headC).normalize().lerp(V(0.2, -0.1, 1).normalize(), (m === 'aside') ? 0.7 : 0.15).normalize();
    const hu = V(0, 1, 0).addScaledVector(hf, -hf.y).normalize();
    let wrR, wrL, grip = null, dir = null;
    if (m === 'play') {
      // stance: arm hangs, fist low near the knee, danda pointing forward and down at the raised end (as in the photo)
      const TIP = V(TIP0[0], TIP0[1], 0); let dSt = V(0.667, -0.509, 0.545).normalize();
      // waiting to play: like a real player he taps the danda on the ground in front of the gilli, then behind it, over and over
      idleK += ((S === 'ready' && m === 'play' ? 1 : 0) - idleK) * Math.min(1, lastRdt * 8);
      if (idleK > 0.002) { const p = idleTap(T); TIP.lerp(V(p[0], p[1], 0), idleK); }
      const lift = Math.max(0, a - A0); if (lift > 0) { const ax = V().crossVectors(dSt, UP).normalize(); dSt.applyAxisAngle(ax, lift); }
      const gSt = TIP.clone().addScaledVector(V(0.667, -0.509, 0.545).normalize(), -LD).add(V(0, lift * 0.08, 0));
      // swing: same arc as the game's swing geometry, in a plane in front of the body
      const an = a >= 0 ? -0.75 + a * 1.25 : -0.75 + a * 0.35;
      const gSw = V(bx + P2.SL[0] + 0.5 * Math.cos(an), P2.SL[1] + 0.5 * Math.sin(an), SWZ), dSw = V(Math.cos(a), Math.sin(a), 0);
      grip = gSw.clone().lerp(gSt, c); dir = dSw.clone().lerp(dSt, c).normalize(); wrR = grip;
      const kneeRest = knL.clone().add(V(0.03, 0.06, 0.07));
      const wind = clamp(a / 2.1, 0, 1), fol = clamp(-a, 0, 1);
      const free = V(shL.x + lerp(0.1, 0.42, wind) - 0.05 * fol, shL.y + lerp(-0.45, 0.12, wind) - 0.2 * fol, bz + 0.25);
      wrL = free.lerp(kneeRest, c);
      if (jf > 0.001) { const bal = clamp((g.x - JX) * 0.8, -0.07, 0.07); wrL.lerp(shL.clone().add(V(0.3 + 0.03 * Math.sin(T * 1.7), -0.42 + 0.02 * Math.sin(T * 2.3) - bal * 0.8, 0.22)), jf); }
      // before the first bounce he steadies the gilli on the danda: its middle rests on the stick and his left
      // hand pinches the far end; the hand lets go the moment the bouncing starts
      if (jugHold > 0.01) { let ax = V(Math.cos(gYaw), 0, -Math.sin(gYaw)); const c0 = V(g.x, g.y + 0.016 * GILLI_LOOK, g.z || 0); if (c0.clone().add(ax).distanceTo(shL) > c0.clone().sub(ax).distanceTo(shL)) ax.negate(); const end = c0.addScaledVector(ax, GL * 0.5 * GILLI_LOOK), back = V().subVectors(shL, end).normalize(); wrL.lerp(end.addScaledVector(back, 0.065), jugHold); }
      if (SWP) {
        const w = swW, O = V(bx, 0, bz), yaw = SWP.yaw * w;
        grip = grip.clone().lerp(O.clone().add(SWP.h), w); dir = dir.clone().lerp(SWP.d, w).normalize(); wrR = grip;
        wrL = wrL.clone().lerp(shL.clone().add(SWP.fr.clone().applyAxisAngle(UP, yaw)), w);
      }
    } else {
      const hipSideR = V(pelvis.x - 0.21, pelvis.y + 0.05, pelvis.z + 0.04), hipSideL = V(pelvis.x + 0.21, pelvis.y + 0.05, pelvis.z + 0.04);
      if (m === 'place' && bat.pt < 0.5) { const ground = V(-0.04, 0.1, -0.05); wrR = hipSideR.clone().lerp(ground, c); grip = wrR; dir = V(0.25, -0.97, 0.1).normalize(); wrL = hipSideL.clone().lerp(knL.clone().add(V(0.03, 0.06, 0.07)), c); }
      else { wrR = hipSideR.clone().lerp(V(-0.04, 0.1, -0.05), c); wrL = hipSideL.clone().lerp(knL.clone().add(V(0.03, 0.06, 0.07)), c); }
    }
    const [elR, wR] = ik3(shR, wrR, 0.3, 0.29, m === 'aside' ? V(-1, 0, -0.4) : swW > 0.3 ? J_bodyF.clone().multiplyScalar(0.8).add(V(0, -0.6, 0)).add(V(-0.3 * (1 - clamp((swU - 0.5) * 3, 0, 1)), 0, 0)) : V(-0.6, -0.4, -0.7)), [elL, wL] = ik3(shL, wrL, 0.3, 0.29, m === 'aside' ? V(1, 0, -0.4) : V(0.6, -0.4, -0.7));
    return { J: { pelvis, chest, headC, headF: hf, headU: hu, shA: shR, elA: elR, wrA: wR, shB: shL, elB: elL, wrB: wL, hipA: hipR, knA: knR, anA: anR, hipB: hipL, knB: knL, anB: anL, bodyF: J_bodyF, footF: V(0.15, 0, 1).normalize(), kneeSpread: 0.05 * c }, grip: grip ? wR.clone() : null, dir };
  }


  /* reactions on top of any pose: joy (both arms up, jumping), win (same + confetti), fist (one arm pumping),
     sad (hands on head, head down), hips (hands on hips, head shaking) */
  function reactK(r) { if (!r) return 0; const t = r.dur - r.left; return clamp(t / 0.25, 0, 1) * clamp(r.left / 0.35, 0, 1); }
  const HAPPY = /^(joy|celeb|dance|clap|beat|point|salute)/;
  function applyReact(J, r) {
    const k = reactK(r); if (k <= 0) return;
    const t = r.dur - r.left, up = V(0, 1, 0); let type = r.type;
    if (type.startsWith('celeb:')) { if (t >= 1.4) type = type.slice(6); else type = 'celeb'; }   // aeroplane run, then the chosen celebration
    if (type === 'slam' && t > 1.4) type = 'hips';
    const F = V(J.bodyF.x, 0, J.bodyF.z).normalize(), lat = V().crossVectors(F, up).normalize();
    const legLift = (s, th, shinTh) => {   // swing a leg forward from the hip, keeping the bone lengths
      const hip = J['hip' + s], kn = J['kn' + s], an = J['an' + s]; if (!hip || !kn || !an) return;
      const th2 = V().subVectors(kn, hip).applyAxisAngle(lat, th), sh2 = V().subVectors(an, kn).applyAxisAngle(lat, th - shinTh);
      kn.copy(hip).add(th2); an.copy(kn).add(sh2);
    };
    const out = (s) => { const o = V().subVectors(J['sh' + s], J.chest); o.y = 0; return o.lengthSq() > 1e-6 ? o.normalize() : V(s === 'A' ? -1 : 1, 0, 0); };
    const L = (v, target) => v.lerp(target, k);
    let jump = 0;
    if (type === 'joy' || type === 'win') {
      jump = Math.abs(Math.sin(t * 8)) * (type === 'win' && bat.runV ? 0.05 : 0.17) * k;
      for (const s of ['A', 'B']) { const o = out(s), sh = J['sh' + s]; L(J['el' + s], sh.clone().addScaledVector(o, 0.2).addScaledVector(up, 0.26)); L(J['wr' + s], sh.clone().addScaledVector(o, 0.16 + 0.06 * Math.sin(t * 10)).addScaledVector(up, 0.56)); }
    } else if (type === 'celeb') {
      if (t < 1.4) {   // aeroplane run: arms out wide, banking side to side
        const bank = Math.sin(t * 4.5) * 0.18;
        for (const s of ['A', 'B']) { const o = out(s), b = (s === 'A' ? 1 : -1) * bank; L(J['el' + s], J['sh' + s].clone().addScaledVector(o, 0.28).addScaledVector(up, 0.02 + b)); L(J['wr' + s], J['sh' + s].clone().addScaledVector(o, 0.55).addScaledVector(up, 0.05 + 2 * b)); }
        J.headF = J.headF.clone().lerp(V(J.headF.x, 0.25, J.headF.z), k * 0.5).normalize();
      } else {         // big leaps with alternating fist pumps, shouting at the sky
        const u = t - 1.4; jump = Math.abs(Math.sin(u * 6)) * 0.3 * k;
        for (const s of ['A', 'B']) { const o = out(s), ph = Math.sin(u * 12 + (s === 'A' ? 0 : Math.PI)) * 0.08; L(J['el' + s], J['sh' + s].clone().addScaledVector(o, 0.18).addScaledVector(up, 0.25)); L(J['wr' + s], J['sh' + s].clone().addScaledVector(o, 0.1).addScaledVector(up, 0.5 + ph)); }
        J.headF = J.headF.clone().lerp(V(J.headF.x * 0.4, 0.8, J.headF.z), k * 0.6).normalize();
      }
    } else if (type === 'dance') {   // bhangra: arms up, hands bouncing, knees lifting in turn
      for (const s of ['A', 'B']) { const o = out(s), b = Math.sin(t * 9 + (s === 'A' ? 0 : Math.PI)) * 0.08; L(J['el' + s], J['sh' + s].clone().addScaledVector(o, 0.24).addScaledVector(up, 0.18)); L(J['wr' + s], J['sh' + s].clone().addScaledVector(o, 0.3).addScaledVector(up, 0.46 + b)); }
      const q = Math.sin(t * 4.5); legLift(q > 0 ? 'A' : 'B', Math.abs(q) * 0.75 * k, Math.abs(q) * 1.1 * k); jump = Math.abs(Math.sin(t * 9)) * 0.04 * k;
      J.headF = J.headF.clone().lerp(V(J.headF.x, 0.3, J.headF.z), k * 0.4).normalize();
    } else if (type === 'clap') {
      const c = J.chest.clone().addScaledVector(F, 0.3).addScaledVector(up, 0.08), gap = 0.02 + 0.11 * Math.abs(Math.sin(t * 7));
      for (const s of ['A', 'B']) { const o = out(s); L(J['el' + s], J['sh' + s].clone().addScaledVector(o, 0.16).addScaledVector(F, 0.14).addScaledVector(up, -0.16)); L(J['wr' + s], c.clone().addScaledVector(o, gap)); }
      jump = Math.abs(Math.sin(t * 7)) * 0.05 * k;
    } else if (type === 'beat') {     // thumping the chest with both fists in turn, head thrown back
      for (const s of ['A', 'B']) { const o = out(s), ph = (Math.sin(t * 8 + (s === 'A' ? 0 : Math.PI)) + 1) / 2;
        L(J['el' + s], J['sh' + s].clone().addScaledVector(o, 0.2).addScaledVector(F, 0.12).addScaledVector(up, -0.15));
        L(J['wr' + s], J.chest.clone().addScaledVector(o, 0.07 + 0.08 * (1 - ph)).addScaledVector(F, 0.1 + 0.2 * (1 - ph)).addScaledVector(up, 0.04)); }
      J.headF = J.headF.clone().lerp(V(J.headF.x, 0.7, J.headF.z), k * 0.6).normalize();
    } else if (type === 'point') {    // one finger to the sky, other hand on the heart
      const oA = out('A'), oB = out('B');
      L(J.elA, J.shA.clone().addScaledVector(up, 0.28).addScaledVector(oA, 0.05)); L(J.wrA, J.shA.clone().addScaledVector(up, 0.56).addScaledVector(oA, 0.08).addScaledVector(F, 0.04 * Math.sin(t * 5)));
      L(J.elB, J.shB.clone().addScaledVector(oB, 0.12).addScaledVector(F, 0.12).addScaledVector(up, -0.2)); L(J.wrB, J.chest.clone().addScaledVector(F, 0.13).addScaledVector(oB, 0.02).addScaledVector(up, 0.05));
      J.headF = J.headF.clone().lerp(V(J.headF.x * 0.3, 0.9, J.headF.z * 0.3), k * 0.7).normalize();
    } else if (type === 'salute') {   // hand to the forehead, chest out, little bow at the end
      const o = out('A'); L(J.elA, J.shA.clone().addScaledVector(o, 0.27).addScaledVector(F, 0.06).addScaledVector(up, 0.04)); L(J.wrA, J.headC.clone().addScaledVector(F, 0.1).addScaledVector(o, 0.05).addScaledVector(up, 0.06));
      const bow = clamp((t - 1.3) / 0.3, 0, 1) * clamp((r.left - 0.1) / 0.3, 0, 1) * k; J.chest.addScaledVector(F, 0.1 * bow); J.headC.addScaledVector(F, 0.16 * bow).addScaledVector(up, -0.06 * bow);
    } else if (type === 'facepalm') { // hand over the eyes, head down and shaking slowly
      const o = out('A'); L(J.elA, J.shA.clone().addScaledVector(o, 0.1).addScaledVector(F, 0.2).addScaledVector(up, -0.1)); L(J.wrA, J.headC.clone().addScaledVector(F, 0.11).addScaledVector(up, 0.01));
      const oB = out('B'); L(J.elB, J.shB.clone().addScaledVector(oB, 0.3).addScaledVector(up, -0.2)); L(J.wrB, J.pelvis.clone().addScaledVector(oB, 0.2).addScaledVector(up, 0.1));
      const sh = Math.sin(t * 3) * 0.35 * k, f = J.headF.clone(); J.headF = V(f.x * Math.cos(sh) + f.z * Math.sin(sh), f.y - 0.45 * k, -f.x * Math.sin(sh) + f.z * Math.cos(sh)).normalize();
      J.headC.addScaledVector(F, 0.04 * k);
    } else if (type === 'kick') {     // kicks the dirt in frustration, then hands on hips
      for (const s of ['A', 'B']) { const o = out(s); L(J['el' + s], J['sh' + s].clone().addScaledVector(o, 0.3).addScaledVector(up, -0.2)); L(J['wr' + s], J.pelvis.clone().addScaledVector(o, 0.2).addScaledVector(up, 0.1)); }
      const kk = t > 0.25 && t < 1.25 ? Math.max(0, Math.sin((t - 0.25) * Math.PI * 2)) : 0; legLift('B', kk * 0.7 * k, kk * 0.1 * k);
      J.headF = J.headF.clone().lerp(V(J.headF.x, -0.6, J.headF.z), k * 0.6).normalize();
    } else if (type === 'slam') {     // raises the danda over his head and hurls it into the dirt
      const o = out('A');
      if (t < 0.75) { const u = clamp(t / 0.6, 0, 1); L(J.elA, J.shA.clone().addScaledVector(up, 0.22 * u).addScaledVector(F, -0.12 * u).addScaledVector(o, 0.1)); L(J.wrA, J.shA.clone().addScaledVector(up, 0.5 * u).addScaledVector(F, -0.14 * u).addScaledVector(o, 0.06)); J.chest.addScaledVector(F, -0.04 * u * k); }
      else { const u = clamp((t - 0.75) / 0.2, 0, 1); L(J.elA, J.shA.clone().addScaledVector(up, 0.22 - 0.3 * u).addScaledVector(F, -0.12 + 0.3 * u).addScaledVector(o, 0.1)); L(J.wrA, J.shA.clone().addScaledVector(up, 0.5 - 0.9 * u).addScaledVector(F, -0.14 + 0.5 * u).addScaledVector(o, 0.06)); J.chest.addScaledVector(F, 0.1 * u * k); J.headC.addScaledVector(F, 0.1 * u * k); }
      const oB = out('B'); L(J.elB, J.shB.clone().addScaledVector(oB, 0.22).addScaledVector(up, -0.18)); L(J.wrB, J.shB.clone().addScaledVector(oB, 0.3).addScaledVector(up, -0.45));
      J.headF = J.headF.clone().lerp(V(J.headF.x, -0.5, J.headF.z), k * 0.5).normalize();
    } else if (type === 'fist') {
      const o = out('A'), sh = J.shA, p = 0.48 + 0.1 * Math.sin(t * 13);
      L(J.elA, sh.clone().addScaledVector(o, 0.24).addScaledVector(up, 0.2)); L(J.wrA, sh.clone().addScaledVector(o, 0.1).addScaledVector(up, p));
    } else if (type === 'sad') {
      for (const s of ['A', 'B']) { const o = out(s); L(J['el' + s], J['sh' + s].clone().addScaledVector(o, 0.27).addScaledVector(up, 0.14).addScaledVector(J.bodyF, 0.06)); L(J['wr' + s], J.headC.clone().addScaledVector(o, 0.1).addScaledVector(up, 0.07)); }
      J.headF = J.headF.clone().lerp(V(J.headF.x, -1.1, J.headF.z), k * 0.55).normalize();
      J.chest.addScaledVector(J.bodyF, 0.04 * k); J.headC.addScaledVector(J.bodyF, 0.06 * k).addScaledVector(up, -0.03 * k);
    } else if (type === 'taunt') {
      const d = (r.dir ? V(r.dir[0], r.dir[1], r.dir[2]) : J.bodyF.clone()).normalize(), jab = 0.06 * Math.sin(t * 11);
      L(J.elB, J.shB.clone().addScaledVector(d, 0.26).addScaledVector(up, -0.04)); L(J.wrB, J.shB.clone().addScaledVector(d, 0.52 + jab).addScaledVector(up, 0.04));
      const o = out('A'); L(J.elA, J.shA.clone().addScaledVector(o, 0.3).addScaledVector(up, -0.2)); L(J.wrA, J.pelvis.clone().addScaledVector(o, 0.2).addScaledVector(up, 0.1));
      J.chest.addScaledVector(d, 0.05 * k); J.headC.addScaledVector(d, 0.07 * k);
      J.headF = J.headF.clone().lerp(d.clone().addScaledVector(up, 0.05 * Math.sin(t * 7)), k * 0.85).normalize(); jump = Math.abs(Math.sin(t * 6)) * 0.035 * k;
    } else if (type === 'hips') {
      for (const s of ['A', 'B']) { const o = out(s); L(J['el' + s], J['sh' + s].clone().addScaledVector(o, 0.3).addScaledVector(up, -0.2)); L(J['wr' + s], J.pelvis.clone().addScaledVector(o, 0.2).addScaledVector(up, 0.1)); }
      const sh = Math.sin(t * 9) * 0.5 * k, f = J.headF.clone(); J.headF = V(f.x * Math.cos(sh) + f.z * Math.sin(sh), f.y - 0.3 * k, -f.x * Math.sin(sh) + f.z * Math.cos(sh)).normalize();
    }
    if (jump) for (const key of ['pelvis', 'chest', 'headC', 'shA', 'shB', 'elA', 'elB', 'wrA', 'wrB', 'hipA', 'hipB', 'knA', 'knB', 'anA', 'anB']) if (J[key]) J[key].y += jump;
    J.headU = V(0, 1, 0).addScaledVector(J.headF, -J.headF.y).normalize();
  }

  const OUTLINE = new T3.MeshBasicMaterial({ color: '#160c04', side: T3.BackSide });
  function outline(mesh, sx, sy, sz) { const o = new T3.Mesh(mesh.geometry, OUTLINE); o.scale.set(sx, sy, sz); o.castShadow = false; mesh.add(o); return o; }
  const GILLI_LOOK = 1.3;
  let lastBatJ = null, handDanda = null, idleK = 0; const lastFieldJ = [];
  /* the waiting taps: 1.8 s per cycle - rest in front of the gilli, lift over it, rest behind it, lift back */
  function idleTap(t) {
    const fx = TIP0[0] + 0.1, bx2 = GREST.x - GL / 2 - 0.1, p = ((t / 1.8) % 1 + 1) % 1, y0 = 0.012;
    if (p < 0.2) return [fx, y0 + Math.max(0, Math.sin(p / 0.2 * Math.PI)) * 0.012];
    if (p < 0.5) { const u = (p - 0.2) / 0.3, e = u * u * (3 - 2 * u); return [lerpN(fx, bx2, e), y0 + Math.sin(u * Math.PI) * 0.13]; }
    if (p < 0.7) return [bx2, y0 + Math.max(0, Math.sin((p - 0.5) / 0.2 * Math.PI)) * 0.012];
    const u = (p - 0.7) / 0.3, e = u * u * (3 - 2 * u); return [lerpN(bx2, fx, e), y0 + Math.sin(u * Math.PI) * 0.13];
  }
  const lerpN = (a, b, t) => a + (b - a) * t;
  let gYaw = Math.PI / 2;   // while it sits on the danda and bounces, the gilli lies across the danda, not along it   // the gilli is drawn 30% larger than its physics size so it reads on a phone screen

  /* ---------------- dynamic objects ---------------- */
  let gilli, dandaFloor, ring, ringIn, jugZone, aimRing, aimLine = [], dangerRing, trail, trailPos, dust, dustGeo, aimDots;
  const DUST_N = 400;
  function makeDynamic() {
    const gw = new T3.MeshStandardMaterial({ map: TEX.gilliWood, roughness: 0.55, emissive: '#4a2a08', emissiveIntensity: 0.55 });
    gilli = new T3.Group();
    const body = new T3.Mesh(new T3.CylinderGeometry(0.016, 0.016, GL * 0.6, 10), gw); body.rotation.z = Math.PI / 2; gilli.add(body); outline(body, 1.45, 1.04, 1.45);
    for (const sx of [-1, 1]) { const tip = new T3.Mesh(new T3.ConeGeometry(0.016, GL * 0.2, 10), gw); tip.rotation.z = -sx * Math.PI / 2; tip.position.x = sx * GL * 0.4; gilli.add(tip); const ot = outline(tip, 1.45, 1.25, 1.45); ot.position.y = 0.004; }
    gilli.traverse(o => { if (o.isMesh) { o.castShadow = true; } }); scene.add(gilli);
    dandaFloor = new T3.Mesh(new T3.CylinderGeometry(0.02, 0.022, 0.7, 12), new T3.MeshStandardMaterial({ map: TEX.wood, color: '#ffe2b8', roughness: 0.5, emissive: '#3a2008', emissiveIntensity: 0.6 }));
    dandaFloor.castShadow = true; dandaFloor.receiveShadow = true; outline(dandaFloor, 1.4, 1.02, 1.4); scene.add(dandaFloor);
    const glow = (col, op) => new T3.MeshBasicMaterial({ color: col, transparent: true, opacity: op, depthWrite: false });
    ring = new T3.Mesh(new T3.TorusGeometry(0.17, 0.012, 8, 40), glow('#ffffff', 0.85)); scene.add(ring);
    ringIn = new T3.Mesh(new T3.TorusGeometry(0.065, 0.008, 8, 30), glow('#ffd23f', 0.9)); scene.add(ringIn);
    jugZone = new T3.Mesh(new T3.PlaneGeometry(0.4, 1), glow('#ffffff', 0.15)); scene.add(jugZone);
    aimRing = new T3.Mesh(new T3.TorusGeometry(0.2, 0.025, 8, 36), glow('#ff5a5a', 0.95)); aimRing.rotation.x = -Math.PI / 2; aimRing.scale.set(1, 0.6, 1); scene.add(aimRing);
    dangerRing = new T3.Mesh(new T3.TorusGeometry(0.42, 0.02, 8, 40), glow('#ff4a4a', 0.8)); dangerRing.rotation.x = -Math.PI / 2; scene.add(dangerRing);
    for (let i = 0; i < 3; i++) { const b = new T3.Mesh(new T3.BoxGeometry(1, 0.012, 0.07), glow('#ffffff', 0.7)); scene.add(b); aimLine.push(b); }
    // trail behind the flying gilli
    trailPos = new Float32Array(16 * 3); const tg = new T3.BufferGeometry(); tg.setAttribute('position', new T3.BufferAttribute(trailPos, 3));
    trail = new T3.Line(tg, new T3.LineBasicMaterial({ color: '#fff4d8', transparent: true, opacity: 0.6 })); trail.frustumCulled = false; scene.add(trail);
    // dust particles: soft sprites with per-particle colour + alpha
    dustGeo = new T3.BufferGeometry();
    dustGeo.setAttribute('position', new T3.BufferAttribute(new Float32Array(DUST_N * 3), 3));
    dustGeo.setAttribute('color', new T3.BufferAttribute(new Float32Array(DUST_N * 4), 4));
    dust = new T3.Points(dustGeo, new T3.PointsMaterial({ size: 0.16, map: TEX.soft, vertexColors: true, transparent: true, depthWrite: false, sizeAttenuation: true }));
    dust.frustumCulled = false; scene.add(dust);
    aimDots = new T3.InstancedMesh(new T3.SphereGeometry(0.025, 8, 6), new T3.MeshBasicMaterial({ color: '#ffd23f', transparent: true, opacity: 0.8 }), 14); scene.add(aimDots);
  }

  /* ---------------- people management ---------------- */
  let batP = null, batKey = '', fieldP = [], fieldKey = '', specP = [];
  function syncPeople() {
    const sd = game.sides.length ? curSide() : null, si = sd ? game.turn : 0, pi = sd ? sd.next : 0, L = sd ? sd.looks[pi] : makeLook(5);
    const key = si + ':' + pi + ':' + (sd ? sd.name : '-') + ':' + JSON.stringify(L);
    if (key !== batKey) { if (batP) batP.dispose(); const lc = lookColors(si, pi, L); batP = createPerson(L, lc.kam, lc.shal, pi); batP.addDanda(); batKey = key; }
    const fk = fielders.map(f => f.kam + JSON.stringify(f.look)).join('|');
    if (fk !== fieldKey) { fieldP.forEach(p => p.dispose()); fieldP = fielders.map((f, i) => createPerson(f.look, f.kam, f.shal, i + 1)); fieldKey = fk; }
  }
  function makeSpectators() {
    specs.forEach((p, i) => {
      if (i >= Q.spec) return;
      const look = { skin: p.skin, hair: p.hair || '#17100c', hairStyle: 'short', capT: p.cap ? 'cap' : null, capC: p.cap || '#fff', beard: null, vest: null, shirt: ['tee', 'shirt', 'polo', 'tee'][i % 4], tucked: i % 3 === 1, shoe: ['#e9e6df', '#2b2b30', '#7a5a3c', '#3a4f6b'][i % 4] };
      if (p.beard && p.beard[0] === '#') look.hair = p.old ? '#a8a29a' : look.hair;
      specP.push(createPerson(look, p.kam, p.shal, i + 3));
    });
  }

  /* ---------------- camera ---------------- */
  const FOV = 40, TANH = Math.tan(FOV * Math.PI / 360);
  let focus = V(), tilt = 0.24;
  /* camera views: side (TV view across the pitch), high (from above, like a stadium camera), low (close to the
     ground, dramatic) and behind (over the batsman's shoulder, looking down the pitch toward the fielders) */
  const CAMS = ['high', 'side', 'low', 'behind'];
  let camMode = (() => { try { const v = localStorage.getItem('gd_cam2'); return CAMS.includes(v) ? v : 'high'; } catch (e) { return 'high'; } })();
  const camPos = V(), camLook = V(), tPos = V(), tLook = V(); let camInit = false, camSnap = 0;
  function setCam(m) { camMode = CAMS.includes(m) ? m : 'high'; try { localStorage.setItem('gd_cam2', camMode); } catch (e) { } }
  function placeCamera() {
    const visH = H / Math.max(4, cam.ppm), d = visH / (2 * TANH);
    const tx = cam.x + (0.5 - FX) * visH * (W / H), ty = visH * 0.24;
    const jx = shake ? (Math.random() - 0.5) * shake * 0.0015 * visH : 0, jy = shake ? (Math.random() - 0.5) * shake * 0.0015 * visH : 0;
    const groundDanda = bat.placed && ['settle', 'fetch', 'throw', 'result', 'juggle'].includes(S);   // look down so the danda lying across the pitch shows its length
    let lookX = tx;
    if (camMode === 'behind') {
      const far = 1.5;   // same angle as before, just standing further back
      const back = far * Math.max(2.8, visH * 0.55), up = far * Math.max(1.6, visH * (S === 'aim' ? 0.5 : 0.3));
      tPos.set(cam.x - back, up, 1.1); lookX = cam.x + visH * 0.4; tLook.set(lookX, Math.max(0.45, visH * 0.07), -0.1);
    } else {
      const base = camMode === 'high' ? 0.6 : camMode === 'low' ? 0.07 : 0.24;
      const want = S === 'aim' ? Math.max(0.62, base) : groundDanda ? Math.max(0.48, base) : base;
      tilt += (want - tilt) * 0.08;
      const lowY = camMode === 'low' ? visH * 0.12 : ty;
      tPos.set(tx, lowY + d * tilt, d * Math.sqrt(1 - tilt * tilt * 0.35)); tLook.set(tx, lowY, 0);
    }
    // glide between views instead of jumping (and follow normally once settled)
    const k = !camInit || camSnap > 0 ? 1 : (camMode === 'behind' ? 1 - Math.exp(-7 * lastRdt) : 1);
    if (camSnap > 0) camSnap--;
    if (!camInit) { camPos.copy(tPos); camLook.copy(tLook); camInit = true; }
    else { camPos.lerp(tPos, k); camLook.lerp(tLook, k); }
    camera.position.set(camPos.x + jx, camPos.y + jy, camPos.z);
    camera.lookAt(camLook); focus.set(lookX, 0, 0);
    // keep the sun's shadow box centred on what we see
    const half = Math.max(8, visH * (camMode === 'behind' ? 1.1 : 0.75) * Math.max(1, W / H));
    sun.position.set(lookX + SCN.sunOff[0], SCN.sunOff[1], SCN.sunOff[2]); sun.target.position.set(lookX, 0, 0); sun.target.updateMatrixWorld();
    const sc = sun.shadow.camera; if (Math.abs(sc.right - half) > 0.5) { sc.left = -half; sc.right = half; sc.top = half; sc.bottom = -half; sc.updateProjectionMatrix(); }
  }
  const pv = V();
  /* The gilli and danda are drawn once more as sharp 2D shapes at full screen resolution, exactly over the 3D ones.
     However low the 3D resolution (low graphics, slow phones, far cameras), they stay crisp and never thinner than 3 px. */
  const cpA = V(), cpB = V(), cpU = V();
  function crispSeg(c, a, b, r, gilliShape, light, dark, thin) {
    const A = proj(a.x, a.y, a.z), B = proj(b.x, b.y, b.z); if (!A[2] || !B[2]) return;
    cpU.copy(a).lerp(b, 0.5); const M = proj(cpU.x, cpU.y, cpU.z); cpU.addScaledVector(camera.up, r); const U = proj(cpU.x, cpU.y, cpU.z);
    const wpx = Math.max(thin ? 1.5 : 3, 2 * Math.hypot(U[0] - M[0], U[1] - M[1])), dx = B[0] - A[0], dy = B[1] - A[1], L = Math.hypot(dx, dy);
    if (L < 0.5) return; const nx = -dy / L, ny = dx / L;
    c.save(); c.lineJoin = 'round'; c.lineCap = 'round';
    if (gilliShape) {   // a spindle: thick in the middle, pointed at both ends
      const h = wpx / 2; c.beginPath(); c.moveTo(A[0], A[1]);
      c.quadraticCurveTo(A[0] + dx * 0.2 + nx * h * 1.3, A[1] + dy * 0.2 + ny * h * 1.3, M[0] + nx * h, M[1] + ny * h);
      c.quadraticCurveTo(B[0] - dx * 0.2 + nx * h * 1.3, B[1] - dy * 0.2 + ny * h * 1.3, B[0], B[1]);
      c.quadraticCurveTo(B[0] - dx * 0.2 - nx * h * 1.3, B[1] - dy * 0.2 - ny * h * 1.3, M[0] - nx * h, M[1] - ny * h);
      c.quadraticCurveTo(A[0] + dx * 0.2 - nx * h * 1.3, A[1] + dy * 0.2 - ny * h * 1.3, A[0], A[1]); c.closePath();
      c.fillStyle = light; c.strokeStyle = dark; c.lineWidth = 1.6; c.fill(); c.stroke();
    } else {
      c.strokeStyle = dark; c.lineWidth = wpx + (thin ? 1.2 : 2.2); c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke();
      c.strokeStyle = light; c.lineWidth = wpx; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke();
      c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = Math.max(1, wpx * 0.3); c.beginPath(); c.moveTo(A[0] + nx * wpx * 0.18, A[1] + ny * wpx * 0.18); c.lineTo(B[0] + nx * wpx * 0.18, B[1] + ny * wpx * 0.18); c.stroke();
    }
    c.restore();
  }
  function lodPeople() {
    const list = [batP, ...fieldP, ...specP];
    for (const p of list) { if (!p || !p.head) continue; const d = camera.position.distanceTo(p.head.position), px = 1.75 * H / (2 * TANH * Math.max(0.1, d));
      p.setLod(p.near ? px > 110 : px > 150); }
  }
  function drawCrisp(c) {
    if (!camera || S === 'menu') return;
    if (dandaFloor && dandaFloor.visible) {
      dandaFloor.updateMatrixWorld();
      const da = dandaFloor.localToWorld(cpA.set(0, 0.35, 0)).clone(), db = dandaFloor.localToWorld(cpB.set(0, -0.35, 0)).clone(), r = 0.021 * dandaFloor.scale.x;
      const J = lastBatJ, mid = da.clone().lerp(db, 0.5);
      if (J && J.pelvis && ((typeof bat.rt === 'number' && bat.rt >= 0) || Math.hypot(J.pelvis.x - mid.x, J.pelvis.z - mid.z) < 0.5)) floorDandaBehindBatsman(c, da, db, r, J, mid);
      else crispSeg(c, da, db, r, false, '#d9a464', '#3a2008');
    }
    // the danda in his hand: only the part beyond his fist is redrawn, at its true thickness, so the hand still wraps it
    if (handDanda && batP && batP.g && batP.g.visible !== false && batP.danda && batP.danda.visible) {
      const a = handDanda[0], b = handDanda[1], L = a.distanceTo(b); if (L > 0.3) crispSeg(c, cpU.copy(a).lerp(b, 0.24 / L).clone(), b, 0.016, false, '#d9a464', '#3a2008', true);
    }
    // the sharp outline is painted on top of everything, so skip it while a fielder holds the gilli on the far side of
    // his body (his right hand when he faces away from the camera side): the normal 3D gilli is then hidden by his body as it should be
    if (gilli && gilli.visible) { gilli.updateMatrixWorld(); crispSeg(c, gilli.localToWorld(cpA.set(-GL * 0.5, 0, 0)), gilli.localToWorld(cpB.set(GL * 0.5, 0, 0)), 0.016 * gilli.scale.y * 1.1, true, '#f2c98a', '#4a2a08'); }
  }
  /* the sharp floor danda is painted over the picture, so when the batsman stands over it (his ritual) the parts of
     his body that are nearer the camera than the danda are cut out of it again: his legs and body hide it, in every camera */
  let offC = null, offX = null;
  function floorDandaBehindBatsman(c, da, db, r, J, mid) {
    const cv = c.canvas; if (!cv) { crispSeg(c, da, db, r, false, '#d9a464', '#3a2008'); return; }
    if (!offC) { offC = document.createElement('canvas'); offX = offC.getContext('2d'); }
    if (offC.width !== cv.width || offC.height !== cv.height) { offC.width = cv.width; offC.height = cv.height; }
    offX.setTransform(1, 0, 0, 1, 0, 0); offX.clearRect(0, 0, offC.width, offC.height); offX.setTransform(c.getTransform());
    crispSeg(offX, da, db, r, false, '#d9a464', '#3a2008');
    const camP = camera.position, dD = camP.distanceTo(mid) - 0.02;
    offX.save(); offX.globalCompositeOperation = 'destination-out'; offX.lineCap = 'round'; offX.strokeStyle = '#000'; offX.fillStyle = '#000';
    const limb = (p, q, rad) => {
      if (!p || !q) return; const m = p.clone().lerp(q, 0.5); if (camP.distanceTo(m) > dD) return;   // behind the danda: it doesn't cover it
      const A = proj(p.x, p.y, p.z), B = proj(q.x, q.y, q.z), M = proj(m.x, m.y, m.z), u = m.clone().addScaledVector(camera.up, rad), Uq = proj(u.x, u.y, u.z);
      if (!A[2] || !B[2]) return; offX.lineWidth = Math.max(2, 2 * Math.hypot(Uq[0] - M[0], Uq[1] - M[1])); offX.beginPath(); offX.moveTo(A[0], A[1]); offX.lineTo(B[0], B[1]); offX.stroke();
    };
    for (const s of ['A', 'B']) { limb(J['hip' + s], J['kn' + s], 0.075); limb(J['kn' + s], J['an' + s], 0.065); limb(J['an' + s], J['an' + s].clone().add(J.footF ? J.footF.clone().multiplyScalar(0.16) : V(0, 0, 0.16)), 0.05); limb(J['sh' + s], J['el' + s], 0.05); limb(J['el' + s], J['wr' + s], 0.045); }
    limb(J.pelvis, J.chest, 0.17); limb(J.hipA, J.hipB, 0.09); limb(J.chest, J.headC, 0.12);
    offX.restore();
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.drawImage(offC, 0, 0); c.restore();
  }
  function proj(x, y, z) { pv.set(x, y, z || 0).project(camera); return [(pv.x + 1) / 2 * W, (1 - pv.y) / 2 * H, pv.z < 1]; }

  /* ---------------- per-frame sync ---------------- */
  const dustState = [];
  function spawnDust(x, y, z, n, col, sp) {
    const c = new T3.Color(col || '#c9a06a');
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI, b = Math.random() * Math.PI * 2, s = (0.3 + Math.random() * 0.7) * (sp || 1);
      dustState.push({ x, y: y + 0.03, z, vx: Math.cos(b) * Math.cos(a) * s * 0.6, vy: Math.abs(Math.sin(a)) * s * 0.5 + 0.2, vz: Math.sin(b) * Math.cos(a) * s * 0.6, life: 0.7 + Math.random() * 0.7, max: 1.4, r: c.r, g: c.g, b: c.b });
    }
    while (dustState.length > DUST_N) dustState.shift();
  }
  function stepDust(dt) {
    const pos = dustGeo.attributes.position.array, col = dustGeo.attributes.color.array;
    for (let i = dustState.length - 1; i >= 0; i--) { const p = dustState[i]; p.vy -= 1.2 * dt; p.vx *= 1 - 2.5 * dt; p.vz *= 1 - 2.5 * dt; p.vy *= 1 - 1.5 * dt; p.x += p.vx * dt; p.y = Math.max(0.02, p.y + p.vy * dt); p.z += p.vz * dt; p.life -= dt; if (p.life <= 0) dustState.splice(i, 1); }
    for (let i = 0; i < DUST_N; i++) {
      const p = dustState[i];
      if (p) { pos[i * 3] = p.x; pos[i * 3 + 1] = p.y; pos[i * 3 + 2] = p.z; col[i * 4] = p.r; col[i * 4 + 1] = p.g; col[i * 4 + 2] = p.b; col[i * 4 + 3] = clamp(p.life / p.max, 0, 1) * 0.7; }
      else { col[i * 4 + 3] = 0; pos[i * 3 + 1] = -10; }
    }
    dustGeo.attributes.position.needsUpdate = true; dustGeo.attributes.color.needsUpdate = true; dust.material.size = 0.1 + 0.002 * (H / Math.max(4, cam.ppm));
  }
  /* true only when the gilli in a fielder's hand is really covered by his body from where the camera looks:
     behind his chest, at body height, and not off to the side of it (so at his eye while aiming it still shows) */
  const hbV = new T3.Vector3(), hbD = new T3.Vector3();
  function heldBehindBody() {
    const h = g.held; if (!h || !h.handW3 || !h.chestW3 || !camera) return false;
    hbD.subVectors(h.chestW3, camera.position).normalize(); hbV.subVectors(h.handW3, h.chestW3);
    const depth = hbV.dot(hbD), side = hbV.addScaledVector(hbD, -depth);
    return depth > 0.03 && h.handW3.y < h.chestW3.y + 0.12 && h.handW3.y > h.chestW3.y - 0.6 && Math.hypot(side.x, side.z) < 0.2;
  }
  function syncGilli() {
    let x = g.x, y = g.y, z = g.z || 0, rot = g.rot;
    if (g.held && g.held.handW3) { x = g.held.handW3.x; y = g.held.handW3.y; z = g.held.handW3.z; rot = 0.6; }
    const gs = GILLI_LOOK * clamp(9 / (GL * Math.max(1, cam.ppm)), 1, 2.5); gilli.scale.setScalar(gs);
    gilli.position.set(x, y + 0.016 * gs, z);
    // in a fielder's hand on the far side of his body (as the camera sees it) the gilli is simply not shown;
    // everywhere else it keeps its one look (the sharp outline is drawn over it)
    gilli.visible = !heldBehindBody(); gilli.rotation.set(0, (S === 'jugready' || S === 'juggle') && !g.held ? gYaw : 0, rot);
    // trail
    const n = g.trail.length; for (let i = 0; i < 16; i++) { const t = g.trail[Math.max(0, n - 16 + i)] || [x, y, z]; trailPos[i * 3] = t[0]; trailPos[i * 3 + 1] = t[1] + 0.016; trailPos[i * 3 + 2] = t[2] || 0; }
    trail.geometry.attributes.position.needsUpdate = true; trail.visible = n > 2 && !g.held;
  }
  function syncDandaFloor() {
    dandaFloor.visible = bat.placed;
    if (bat.placed) {
      // thicker when the camera is far away so it never shrinks to a dot (the rules don't change: hits are judged on the real size)
      const k = clamp(50 / Math.max(1, cam.ppm), 1, 2.2);   // normal size at normal zoom; up to ~2x thicker only when zoomed far out
      dandaFloor.scale.set(k, 1, k);
      dandaFloor.position.set(DD.x, 0.02 * k + DD.y, DD.z); dandaFloor.rotation.set(Math.PI / 2, 0, 0); dandaFloor.rotateOnWorldAxis(UP, DD.yaw);
    }
    dangerRing.visible = bat.placed && (S === 'aim' || S === 'fetch' || (S === 'throw' && !sub.judged));
    if (dangerRing.visible) { dangerRing.position.set(DD.x, 0.015, DD.z); dangerRing.material.opacity = 0.5 + 0.3 * Math.sin(T * 8); }
  }
  function syncRings() {
    ring.visible = ringIn.visible = (S === 'pop' && !sub.swung);
    if (ring.visible) {
      const d = Math.hypot((g.x - RING.x) * 0.8, g.y - RING.y), q = clamp(1 - d / 0.4, 0, 1);
      ring.position.set(RING.x, RING.y, SWZ); ringIn.position.copy(ring.position); ring.lookAt(camera.position); ringIn.lookAt(camera.position);
      ring.material.color.set(q >= 0.84 ? '#ffd23f' : q >= 0.58 ? '#7ef29a' : '#ffffff'); ring.material.opacity = 0.65 + 0.3 * Math.sin(T * 8);
    }
    jugZone.visible = S === 'juggle' && !sub.ended && !isCPU();
    if (jugZone.visible) { const win = jugWin(), h = g.y - JY, inz = g.vy < 0 && h >= -0.12 && h <= win; jugZone.position.set(JX, JY + (win - 0.12) / 2, SWZ); jugZone.scale.set(1, win + 0.12, 1); jugZone.lookAt(camera.position); jugZone.material.color.set(inz ? '#7ef29a' : '#ffffff'); jugZone.material.opacity = inz ? 0.35 : 0.13; }
    // throwing: aim ring on the ground and the coloured power line
    const aiming = S === 'aim' && sub.t >= 0 && !throwerCPU();
    aimRing.visible = false; aimLine.forEach(b => b.visible = false);
    if (false) {
      if (sub.step === 0) { const z = aimZ(); aimRing.position.set(0, 0.03, z); aimRing.material.color.set(Math.abs(z) < 0.32 ? '#7ef29a' : '#ff5a5a'); }
      else {
        const xN = aimX(), on = xN <= 0.13 && xN >= -1.0; aimRing.position.set(xN, 0.03, sub.zLock); aimRing.material.color.set(on ? '#7ef29a' : '#ff5a5a');
        const seg = (b, x1, x2, col) => { b.position.set((x1 + x2) / 2, 0.02, sub.zLock); b.scale.set(x2 - x1, 1, 1); b.material.color.set(col); };
        seg(aimLine[0], 0.13, 2.4, '#ff5a5a'); seg(aimLine[1], -1.0, 0.13, '#7ef29a'); seg(aimLine[2], -1.2, -1.0, '#ffaa3c');
      }
    }
    // shot preview dots while choosing a shot
    aimDots.visible = S === 'ready' && myTurn() && !isCPU();
    if (aimDots.visible) {
      const sh = SHOTS[game.shot], v = game.shot === 'loft' ? 6.2 : 6.8; let x = RING.x, y = RING.y, vx = v * Math.cos(sh.ang), vy = v * Math.sin(sh.ang);
      aimDots.material.color.set(game.shot === 'ground' ? '#7ef29a' : game.shot === 'loft' ? '#ff8f6b' : '#ffd23f');
      for (let i = 0; i < 14; i++) { const t = 0.045; vy -= 9.8 * t; x += vx * t; y += vy * t; if (y < 0.02) { y = 0.02; vy = Math.abs(vy) * 0.3; } tmpM.compose(V(x, y, SWZ), tmpQ.identity(), tmpS.setScalar(1 - i / 16)); aimDots.setMatrixAt(i, tmpM); }
      aimDots.instanceMatrix.needsUpdate = true;
    }
  }
  /* life: every body breathes, the eyes follow the gilli, and joints glide between poses instead of snapping
     (keep = joints that must stay exact, like the hand on the danda) */
  const JKEYS = ['pelvis', 'chest', 'headC', 'shA', 'shB', 'elA', 'elB', 'wrA', 'wrB', 'hipA', 'hipB', 'knA', 'knB', 'anA', 'anB'];
  function liven(P, J, rate, phase, keep, watch) {
    const br = Math.sin(T * 1.5 + phase) * 0.005, dt = lastRdt;
    J.chest.y += br; J.shA.y += br * 1.3; J.shB.y += br * 1.3; J.headC.y += br;
    if (watch) {
      const d = V().subVectors(watch, J.headC).normalize();
      if (d.dot(J.bodyF) > -0.25) { d.y = clamp(d.y, -0.6, 0.6); J.headF = J.headF.clone().lerp(d, 0.7).normalize(); }
    }
    const sm = P.sm || (P.sm = {}), k = dt > 0 ? 1 - Math.exp(-rate * dt) : 1;
    for (const key of JKEYS) {
      const v = J[key], o = sm[key];
      if (!o || o.distanceToSquared(v) > 0.6 || (keep && keep.includes(key))) { sm[key] = v.clone(); continue; }
      o.lerp(v, k); v.copy(o);
    }
    // smoothing moves shoulder, elbow and hand separately; re-solve each arm so it keeps its real length (no stretching in fast moves)
    const l1 = J.scale ? 0.29 * J.scale : 0.3, l2 = J.scale ? 0.27 * J.scale : 0.29;
    for (const sd of ['A', 'B']) { const sh = J['sh' + sd], el = J['el' + sd], wr = J['wr' + sd];
      if (sh.distanceTo(wr) > l1 + l2 - 0.002 || Math.abs(sh.distanceTo(el) - l1) > 0.01 || Math.abs(el.distanceTo(wr) - l2) > 0.01) {
        const mid = sh.clone().lerp(wr, 0.5), pole = V().subVectors(el, mid); if (pole.lengthSq() < 1e-6) pole.set(0, -1, 0);
        const [e2, w2] = ik3(sh, wr, l1, l2, pole); el.copy(e2); wr.copy(w2); sm['el' + sd] = e2.clone(); sm['wr' + sd] = w2.clone(); } }
    // same for the legs: thigh and shin never stretch or shrink, whatever the reactions and smoothing did
    const s3 = J.scale || 1, t1 = 0.45 * s3, t2 = 0.44 * s3;
    for (const sd of ['A', 'B']) { const hp = J['hip' + sd], kn = J['kn' + sd], an = J['an' + sd]; if (!hp || !kn || !an) continue;
      if (Math.abs(hp.distanceTo(kn) - t1) > 0.012 || Math.abs(kn.distanceTo(an) - t2) > 0.012) {
        const mid = hp.clone().lerp(an, 0.5), pole = V().subVectors(kn, mid); if (pole.lengthSq() < 1e-6) pole.copy(J.bodyF || V(1, 0, 0));
        const [k2, a2] = ik3(hp, an, t1, t2, pole); kn.copy(k2); an.copy(a2); sm['kn' + sd] = k2.clone(); sm['an' + sd] = a2.clone(); } }
    if (!sm.hf || sm.hf.dot(J.headF) < 0) sm.hf = J.headF.clone(); else { sm.hf.lerp(J.headF, 1 - Math.exp(-10 * dt)).normalize(); J.headF = sm.hf.clone(); }
    J.headU = V(0, 1, 0).addScaledVector(J.headF, -J.headF.y).normalize();
  }
  function watchPoint() { return ['pop', 'flight', 'settle', 'fetch', 'throw', 'juggle', 'jugready', 'aim'].includes(S) ? V(g.held ? g.held.x : g.x, g.held ? 1.2 : g.y, g.z || 0) : V(0, 1.2, BZ); }
  /* overarm throw for a fielder (f.wind: 0..1 winding up, -1..0 release and follow-through). The throwing arm is the
     B side (toward the camera). Shoulders turn side-on to cock the arm behind the head with the other arm pointing at
     the danda, then the body rotates through, the arm whips over the top and finishes across the body. */
  /* fielders throw right-handed: facing +x the right hand is the near side (B), facing -x it is the far side (A) */
  const throwArm = f => (f.face > 0 ? 'B' : 'A');
  /* before a throw he lines it up: the gilli comes up close to his eye, twice, looking along it at the danda */
  function applySight(J, f, sc) {
    const s = f.sight || 0; if (s <= 0.001) return;
    const T_ = throwArm(f), O = T_ === 'B' ? 'A' : 'B', F = V(f.face, 0, 0), U = V(0, 1, 0), Sd = V(0, 0, T_ === 'B' ? 1 : -1);
    const env = clamp(s * 3, 0, 1) * clamp((2 - s) * 3, 0, 1), up = Math.pow(Math.sin(Math.PI * s), 2);   // two raises
    const low = J['sh' + T_].clone().addScaledVector(F, 0.28).addScaledVector(U, -0.24).addScaledVector(Sd, -0.05);
    const eye = J.headC.clone().addScaledVector(F, 0.15).addScaledVector(U, -0.01).addScaledVector(Sd, 0.02);
    const wT = J['wr' + T_].clone().lerp(low.lerp(eye, up), env);
    const wO = J['wr' + O].clone().lerp(J['sh' + O].clone().addScaledVector(F, 0.42).addScaledVector(U, -0.02), env * 0.8);   // other hand points at the danda
    const [eT, wT2] = ik3(J['sh' + T_], wT, 0.29 * sc, 0.27 * sc, V().addScaledVector(U, -1).addScaledVector(Sd, 0.8));
    const [eO, wO2] = ik3(J['sh' + O], wO, 0.29 * sc, 0.27 * sc, V().addScaledVector(U, -1).addScaledVector(Sd, -0.3));
    J['el' + T_] = eT; J['wr' + T_] = wT2; J['el' + O] = eO; J['wr' + O] = wO2;
    J.headC.addScaledVector(F, 0.02 * env).addScaledVector(U, -0.015 * up * env);
    J.headF = J.headF.clone().lerp(F.clone().add(V(0, -0.06, 0)).normalize(), env).normalize();
  }
  function applyThrow(J, f, sc) {
    const w = f.wind || 0; if (Math.abs(w) < 0.01) return;
    const T_ = throwArm(f), O = T_ === 'B' ? 'A' : 'B';
    const F = V(f.face, 0, 0), U = V(0, 1, 0), Sd = V(0, 0, T_ === 'B' ? 1 : -1), piv = J.pelvis.clone();
    const cock = Math.max(0, w), p = Math.max(0, -w);                // p: 1 at release, falling to 0 as he recovers
    const fol = p > 0 ? clamp((1 - p) * 2, 0, 1) : 0, out = p > 0 ? clamp(p * 2, 0, 1) : 0;   // follow-through, and how much of the throw is still showing
    // shoulder turn: the throwing shoulder swings back on the wind-up and through on release. Its direction depends on
    // which side of the body the throwing arm is (near or far), not only on which way he faces.
    const tw = f.face * (T_ === 'B' ? 1 : -1);
    const k = cock || out, yaw = -tw * 0.9 * cock + tw * 0.6 * out * (0.5 + 0.5 * fol);
    const turn = (v) => { const d = V().subVectors(v, piv); d.applyAxisAngle(U, yaw); v.copy(piv).add(d); };
    for (const key of ['chest', 'headC', 'shA', 'shB']) turn(J[key]);
    const lean = -0.07 * cock + (0.12 * fol - 0.02) * out;
    for (const key of ['chest', 'headC', 'shA', 'shB']) J[key].addScaledVector(F, lean * (key === 'chest' ? 1 : 1.3));
    const L = (a, b, t) => a.clone().lerp(b, t);
    let wrB, poleB, wrA;
    if (cock > 0) {
      wrB = J['sh' + T_].clone().addScaledVector(F, -0.3).addScaledVector(U, 0.3).addScaledVector(Sd, 0.08); poleB = V().addScaledVector(U, 1).addScaledVector(F, -0.3).addScaledVector(Sd, 0.6);
      wrA = J['sh' + O].clone().addScaledVector(F, 0.45).addScaledVector(U, 0.06);
    } else {
      const rel = J['sh' + T_].clone().addScaledVector(F, 0.42).addScaledVector(U, 0.22).addScaledVector(Sd, -0.02);
      const acr = J['sh' + T_].clone().addScaledVector(F, 0.3).addScaledVector(U, -0.45).addScaledVector(Sd, -0.34);
      wrB = L(rel, acr, fol); poleB = V().addScaledVector(Sd, 0.6).addScaledVector(U, 0.3 - 0.6 * fol);
      wrA = J['sh' + O].clone().addScaledVector(F, 0.1 + 0.25 * (1 - fol)).addScaledVector(U, -0.35 * fol);
    }
    wrB = L(J['wr' + T_], wrB, k); wrA = L(J['wr' + O], wrA, k);
    const [eB, wB] = ik3(J['sh' + T_], wrB, 0.29 * sc, 0.27 * sc, poleB), [eA, wA] = ik3(J['sh' + O], wrA, 0.29 * sc, 0.27 * sc, V().addScaledVector(U, -1).addScaledVector(Sd, -0.3));
    J['el' + T_] = eB; J['wr' + T_] = wB; J['el' + O] = eA; J['wr' + O] = wA; J.hand = wB.clone();
    J.bodyF = V(f.face, 0, 0).applyAxisAngle(U, yaw * 0.85);
    if (cock > 0.2) J.headF = F.clone().add(V(0, -0.05, 0)).normalize();   // eyes on the target while winding up
  }
  /* the batsman's ritual (bat.rt seconds): walk to the danda, step over it, turn, step back over it, turn and spit
     on the ground beside it, then walk back to his place. Built in his own frame (facing +z), then turned and moved. */
  function ritualKeys(x0, z0) {
    const H = Math.PI / 2, bk = Math.atan2(x0 + 0.45, z0);
    return [[0, x0, z0, 0], [0.25, x0, z0, 0.3], [0.85, -0.45, 0, 0.3], [1.05, -0.45, 0, H], [1.95, 0.45, 0, H], [2.3, 0.45, 0, -H], [3.2, -0.45, 0, -H],
      [3.55, -0.45, 0, H], [5.15, -0.45, 0, H], [5.4, -0.45, 0, bk], [6.0, x0, z0, bk], [6.3, x0, z0, 0]];
  }
  function applyRitual(J) {
    const t = typeof bat.rt === 'number' ? bat.rt : -1; if (t < 0 || bat.mode !== 'aside') return;
    const x0 = BX + bat.off + (bat.run || 0), z0 = BZ, K = ritualKeys(x0, z0);
    let i = 0; while (i < K.length - 2 && t > K[i + 1][0]) i++;
    const a = K[i], b = K[i + 1], u = clamp((t - a[0]) / Math.max(1e-3, b[0] - a[0]), 0, 1), e = u * u * (3 - 2 * u);
    const px = lerp(a[1], b[1], e), pz = lerp(a[2], b[2], e);
    let dy = b[3] - a[3]; while (dy > Math.PI) dy -= 2 * Math.PI; while (dy < -Math.PI) dy += 2 * Math.PI;
    const yaw = a[3] + dy * e, moving = Math.hypot(b[1] - a[1], b[2] - a[2]) > 0.05 ? Math.sin(Math.PI * u) * 0.6 + 0.4 : 0;
    const U = V(0, 1, 0);
    if (moving) {   // walking, with high steps over the danda
      const ph = t * 10, hi = clamp(1 - Math.abs(px) / 0.32, 0, 1), k = moving;
      J.anA.z += Math.sin(ph) * 0.17 * k; J.anA.y += Math.max(0, Math.cos(ph)) * (0.07 + 0.24 * hi) * k;
      J.anB.z -= Math.sin(ph) * 0.17 * k; J.anB.y += Math.max(0, -Math.cos(ph)) * (0.07 + 0.24 * hi) * k;
      const bob = Math.abs(Math.sin(ph)) * 0.02 * k + 0.04 * hi * k; for (const key of ['pelvis', 'hipA', 'hipB', 'chest', 'headC', 'shA', 'shB', 'elA', 'elB', 'wrA', 'wrB']) J[key].y += bob;
      J.wrA.z -= Math.sin(ph) * 0.08 * k; J.wrB.z += Math.sin(ph) * 0.08 * k;
      J.headF = V(0, -0.35, 1).normalize();
    } else J.headF = V(0, -0.2, 1).normalize();
    if (t > 3.55 && t < 5.15) {   // lean over and spit (a head jerk on every spit in Javed's recording)
      const s = Math.min(1, (t - 3.55) / 0.3, (5.15 - t) / 0.3), jerk = RIT_SPITS.some(q => t > q - 0.06 && t < q + 0.1) ? 0.045 : 0;
      for (const key of ['chest', 'shA', 'shB', 'elA', 'elB', 'wrA', 'wrB']) J[key].add(V(0, -0.06 * s, 0.13 * s));
      J.headC.add(V(0, -0.12 * s, 0.22 * s + jerk));
      J.headF = J.headF.clone().lerp(V(0, -0.65, 1).normalize(), s).normalize();
    }
    for (const s of ['A', 'B']) { const [kn] = ik3(J['hip' + s], J['an' + s], 0.45, 0.44, V(s === 'A' ? -0.25 : 0.25, 0, 1)); J['kn' + s] = kn; }
    const base = V(x0, 0, z0), pos = V(px, 0, pz);
    for (const key of ['pelvis', 'chest', 'headC', 'shA', 'elA', 'wrA', 'shB', 'elB', 'wrB', 'hipA', 'knA', 'anA', 'hipB', 'knB', 'anB']) { const v = J[key]; if (!v) continue; v.sub(base).applyAxisAngle(U, yaw).add(pos); }
    J.headF = J.headF.clone().applyAxisAngle(U, yaw); J.headU = V(0, 1, 0).addScaledVector(J.headF, -J.headF.y).normalize();
    J.bodyF = V(0, 0, 1).applyAxisAngle(U, yaw); J.footF = V(0.15, 0, 1).normalize().applyAxisAngle(U, yaw);
  }
  function syncPeoplePoses() {
    syncPeople();
    jugFocus += (((S === 'juggle' || S === 'jugready') && bat.mode === 'play' ? 1 : 0) - jugFocus) * Math.min(1, lastRdt * 4);
    updateFeet(lastRdt);
    const su = typeof bat.swu === 'number' ? bat.swu : -1; if (su >= 0) swU = su;
    swW += ((su >= 0 ? 1 : 0) - swW) * Math.min(1, lastRdt * (su >= 0 ? 30 : 6));
    jugHold += ((S === 'jugready' && bat.mode === 'play' ? 1 : 0) - jugHold) * Math.min(1, lastRdt * (S === 'jugready' ? 6 : 14));
    const B = batsmanJoints(), rb = react.bat; applyRitual(B.J);
    applyReact(B.J, rb && rb.type === 'taunt' ? { ...rb, dir: [1, 0, 0.25] } : rb); liven(batP, B.J, 28, 0, jugHold > 0.5 ? ['wrA', 'wrB'] : ['wrA'], null); batP.pose(B.J); lastBatJ = B.J;
    let grip = B.grip ? B.J.wrA.clone() : null, dir = B.dir;
    if (grip && reactK(rb) > 0.3) dir = V().subVectors(B.J.wrA, B.J.elA).normalize().lerp(V(0, -1, 0), 0.3).normalize();
    batP.setDanda(grip, dir, LD); handDanda = grip && dir ? [grip.clone().addScaledVector(dir, -0.06), grip.clone().addScaledVector(dir, LD)] : null;
    if (dir && (S === 'jugready' || S === 'juggle')) gYaw = Math.atan2(-dir.z, dir.x) + Math.PI / 2;
    const hide = fieldersHidden(), rf = react.field, wp = watchPoint();
    fielders.forEach((f, i) => {
      const P = fielderPose(f), sc = 0.92 * f.look.height, J = sagittalJoints(P, f.x, 0, f.face, sc, f.look.build);
      J.sway = V(-f.face * Math.min(0.5, Math.abs(f.v) * 0.08), 0, 0);
      applyThrow(J, f, sc); applySight(J, f, sc);
      let r = null; if (rf) { if (rf.idx < 0 || rf.idx === i) r = rf; else if (HAPPY.test(rf.type)) r = { ...rf, type: ['fist', 'clap', 'joy', 'point'][i % 4] }; }
      applyReact(J, r); liven(fieldP[i] || {}, J, (f.wind || 0) < 0 ? 28 : 20, i * 1.9 + 1, g.held === f ? ['wr' + throwArm(f), 'el' + throwArm(f)] : null, g.held === f ? V(0, 0.5, 0) : wp); f.handW3 = J['wr' + throwArm(f)].clone(); f.chestW3 = J.chest.clone();
      lastFieldJ[i] = J;
      if (fieldP[i]) { fieldP[i].g.visible = !hide; fieldP[i].pose(J); }
    });
    const cheerAll = cheer > 0 || (rb && rb.type === 'win');
    specs.forEach((p, i) => { const jump = cheerAll && !p.old ? Math.abs(Math.sin(T * 10 + i * 1.7)) * 0.22 : 0; const J = sagittalJoints(specPose(p, i), p.x * 1.15, -2.8 - (i % 2) * 0.6, p.face, p.scale || 1, 1); J.pelvis.y += jump; [J.chest, J.headC, J.shA, J.shB, J.elA, J.elB, J.wrA, J.wrB, J.hipA, J.hipB, J.knA, J.knB].forEach(v => v.y += jump); if (cheerAll && !p.old) applyReact(J, { type: 'joy', left: 1, dur: 2 }); if (specP[i]) { liven(specP[i], J, 14, i * 2.3 + 4, null, wp); specP[i].pose(J); } });
    tags.length = 0;
    if (game.sides.length && S !== 'menu' && S !== 'toss') {
      tags.push({ p: batP.head.position, n: curName(), me: true });
      if (!hide) fielders.forEach((f, i) => { if (fieldP[i]) tags.push({ p: fieldP[i].head.position, n: f.name || '', col: f.kam }); });
    }
    // confetti for the winners
    if (rb && rb.type === 'win' && Math.random() < 0.7) { const cols = ['#ff5a5f', '#ffd23f', '#7ef29a', '#5ab0ff', '#ff8fe0', '#ffffff']; for (let k = 0; k < 3; k++) spawnDust(B.J.pelvis.x + (Math.random() - 0.5) * 3, 2.2 + Math.random(), B.J.pelvis.z + (Math.random() - 0.5) * 2, 1, cols[Math.floor(Math.random() * cols.length)], 1.5); }
  }

  /* soft contact shadows: a dark patch under every player, the gilli and the danda. Nearly free to draw, so they
     stay on at every graphics level; the gilli's patch shrinks and fades as it rises, which shows how high it is. */
  const tags = [];
  const blobs = [];
  function blob(i, x, z, sx, sz, op) {
    let b = blobs[i];
    if (!b) { b = blobs[i] = new T3.Mesh(new T3.PlaneGeometry(1, 1), new T3.MeshBasicMaterial({ map: TEX.soft, color: '#000000', transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -6 })); b.rotation.x = -Math.PI / 2; b.renderOrder = 2; scene.add(b); }
    b.visible = op > 0.01; b.position.set(x, 0.012, z); b.scale.set(sx, sz, 1); b.material.opacity = op;
  }
  function syncBlobs() {
    const base = Q.shadow > 0 ? 0.28 : 0.5; let n = 0;
    if (batP && batP.p.hips) blob(n++, batP.p.hips.position.x, batP.p.hips.position.z, 0.95, 0.7, base);
    const hide = fieldersHidden();
    fielders.forEach((f, i) => { const P = fieldP[i]; if (P) blob(n++, P.p.hips.position.x, P.p.hips.position.z, 0.9, 0.65, hide ? 0 : base); });
    specP.forEach(P => blob(n++, P.p.hips.position.x, P.p.hips.position.z, 0.9, 0.65, base * 0.9));
    const h = Math.max(0, gilli.position.y), k = 1 / (1 + h * 0.9), gs = gilli.scale.x;
    blob(n++, gilli.position.x, gilli.position.z, (0.3 + h * 0.12) * gs, (0.14 + h * 0.08) * gs, 0.6 * k);
    blob(n++, DD.x, DD.z, 0.2 * dandaFloor.scale.x, 0.9, bat.placed ? 0.45 : 0);
    for (let i = n; i < blobs.length; i++) blobs[i].visible = false;
  }

  /* ---------------- public ---------------- */
  function init() {
    if (renderer) return;   // the 3D starts once, when the first match begins (the menus never touch the graphics chip)
    if (T3.ColorManagement) { if ('legacyMode' in T3.ColorManagement) T3.ColorManagement.legacyMode = false; else T3.ColorManagement.enabled = true; }
    W = window.innerWidth; H = window.innerHeight;
    qKey = SAFE ? 'low' : GFX[qMode] ? qMode : guessQuality(); Q = GFX[qKey];
    // some tablets refuse a 'high-performance' or antialiased context: fall back to the plainest one before giving up
    const cvs = document.getElementById('c');
    const opts = SAFE ? [{ antialias: false, precision: 'highp', stencil: false }] : [{ antialias: true, powerPreference: 'high-performance' }, { antialias: true }, { antialias: false }, { antialias: false, depth: true, stencil: false }];   // always full-precision maths: 'mediump' made distant things shimmer and sink
    for (const opt of opts) {
      // safe mode uses the older WebGL 1, which some tablet drivers handle when WebGL 2 freezes them
      const R = SAFE && T3.WebGL1Renderer ? T3.WebGL1Renderer : T3.WebGLRenderer;
      try { renderer = new R(cvs ? { ...opt, canvas: cvs } : opt); break; } catch (e) { renderer = null; }
    }
    if (!renderer) throw new Error('3D graphics (WebGL) could not start on this device');
    try { const gl = renderer.getContext(), ext = gl.getExtension('WEBGL_debug_renderer_info'); gpuName = String(ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER)); } catch (e) { }
    SOFT = /swiftshader|software|llvmpipe|softpipe/i.test(gpuName);
    if (SOFT) { qKey = 'low'; Q = GFX.low; }
    if (qMode === 'auto' && !SOFT && !SAFE) { let k = qKey; if (WEAK_GPU.test(gpuName)) k = 'low'; const r = rememberedAuto(); if (r) k = lowerOf(k, r); qKey = k; Q = GFX[k]; }
    try { renderer.setClearColor(0x1b1630, 1); renderer.clear(); } catch (e) { }   // never show an uninitialised surface
    renderer.domElement.addEventListener('webglcontextlost', e => { e.preventDefault(); }, false);
    renderer.domElement.addEventListener('webglcontextrestored', () => { try { location.reload(); } catch (e) { } }, false);
    renderer.setPixelRatio(prFor()); renderer.setSize(W, H);
    renderer.shadowMap.enabled = Q.shadow > 0; renderer.shadowMap.type = qKey === 'high' ? T3.PCFSoftShadowMap : T3.PCFShadowMap;
    if ('outputColorSpace' in renderer) renderer.outputColorSpace = T3.SRGBColorSpace; else renderer.outputEncoding = T3.sRGBEncoding;
    if (!('useLegacyLights' in renderer)) renderer.physicallyCorrectLights = true; renderer.toneMapping = T3.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
    if (!cvs) { renderer.domElement.id = 'c'; document.body.prepend(renderer.domElement); }
    ucv = document.getElementById('ui'); uctx = ucv.getContext('2d');
    scene = new T3.Scene(); scene.fog = new T3.Fog('#d3e4ea', 70, 900);
    camera = new T3.PerspectiveCamera(FOV, W / H, 0.05, 3000);
    hemi = new T3.HemisphereLight('#cfe3ff', '#6b5a3a', 0.85); scene.add(hemi);
    sun = new T3.DirectionalLight('#fff1d8', 2.4); sun.castShadow = Q.shadow > 0;
    sun.shadow.mapSize.set(Q.shadow || 512, Q.shadow || 512); sun.shadow.camera.near = 1; sun.shadow.camera.far = 90; sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.02; sun.shadow.radius = 4;
    scene.add(sun); scene.add(sun.target);
    makeTextures();
    scene.add(skyDome());
    makeDynamic(); makeSpectators();
    resize(); window.addEventListener('resize', resize);
  }
  function resize() {
    W = window.innerWidth; H = window.innerHeight; groundY = H * 0.76; basePPM = Math.max(30, Math.min(H / 6.2, W / 4.4));
    renderer.setPixelRatio(prFor()); renderer.setSize(W, H); camera.aspect = W / H; camera.updateProjectionMatrix();
    const d = Math.min(2, window.devicePixelRatio || 1); ucv.width = Math.round(W * d); ucv.height = Math.round(H * d); ucv.style.width = W + 'px'; ucv.style.height = H + 'px'; uctx.setTransform(d, 0, 0, d, 0, 0);
  }
  function applyQuality(key) {
    qKey = key; Q = GFX[key]; if (!renderer) return;
    renderer.setPixelRatio(prFor()); renderer.setSize(W, H);
    renderer.shadowMap.enabled = Q.shadow > 0; renderer.shadowMap.type = key === 'high' ? T3.PCFSoftShadowMap : T3.PCFShadowMap; sun.castShadow = Q.shadow > 0;
    if (Q.shadow > 0) { sun.shadow.mapSize.set(Q.shadow, Q.shadow); if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; } }
    scene.traverse(o => { if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => m.needsUpdate = true); });
    const sk = SCN_KEY; SCN_KEY = ''; setScene(sk);                                   // rebuild grass etc.
    batKey = ''; fieldKey = ''; specP.forEach(p => p.dispose()); specP = []; makeSpectators();   // rebuild people
    resize();
  }
  function setQuality(mode) {
    qMode = GFX[mode] ? mode : 'auto'; try { localStorage.setItem('gd_gfx', qMode); localStorage.removeItem('gd_autoq'); } catch (e) { }
    if (!renderer) { qKey = GFX[mode] ? mode : guessQuality(); Q = GFX[qKey]; return; }
    applyQuality(GFX[mode] ? mode : (WEAK_GPU.test(gpuName) || SOFT ? 'low' : guessQuality())); fps.t = 0; fps.n = 0; fps.drops = 0;
  }
  const fps = { t: 0, n: 0, last: 0, drops: 0 };
  function watchFps() { // Auto: if the game runs under ~40 fps for a few seconds, step down one level
    const now = performance.now(); if (fps.last) { const dt = now - fps.last; if (dt < 500) { fps.t += dt; fps.n++; } } fps.last = now;
    if (fps.t > 3000) {
      const avg = 1000 * fps.n / fps.t; fps.t = 0; fps.n = 0;
      if (qMode === 'auto' && avg < 40 && qKey !== 'low' && fps.drops < 2) { fps.drops++; const k = qKey === 'high' ? 'medium' : 'low'; applyQuality(k); try { localStorage.setItem('gd_autoq', k); } catch (e) { } }
    }
  }
  let pendingDust = [], jugFocus = 0, jugHold = 0, lastRdt = 0.016;
  function render(rdt, calm) {
    lastRdt = rdt || 0;
    if (calm) { fps.last = 0; dynS.last = 0; } else { watchFps(); dynRes(); }   // menu frames are throttled on purpose: don't count them
    timeU.value = T;
    placeCamera(); syncPeoplePoses(); syncGilli(); syncDandaFloor(); syncRings(); syncBlobs();
    for (const d of pendingDust) spawnDust(...d); pendingDust = [];
    stepDust(rdt);
    try { lodPeople(); } catch (e) { }
    syncBatches();
    renderer.render(scene, camera); drawCalls = renderer.info && renderer.info.render ? renderer.info.render.calls : 0;
    UI.draw();
    try { drawCrisp(uctx); } catch (e) { }
  }
  return { stats: () => ({ calls: drawCalls, pr: renderer ? renderer.getPixelRatio() : 0, q: qKey + (SAFE ? ' · safe mode' : ''), dyn }), gpu: () => gpuName + (SOFT ? ' (no graphics chip: software)' : ''), ready: () => !!renderer, safe: SAFE, tags, setCam: (m) => { setCam(m); camSnap = 0; }, camMode: () => camMode, cams: CAMS, setQuality, quality: () => ({ mode: qMode, level: qKey }), setScene, scenes: Object.keys(SCENES), __batsmanJoints: () => batsmanJoints(), __react: (J, r) => applyReact(J, r), __batPosed: () => lastBatJ, __fieldPosed: () => lastFieldJ, idleTap, init, render, proj, dust: (x, y, z, n, col, sp) => pendingDust.push([x, y, z, n, col, sp]), get ctx() { return uctx; } };
})();
