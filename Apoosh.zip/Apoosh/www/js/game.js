/* Apoosh by Javed — game.js: rules, physics, match flow, toss, two-phone play, input.
   Drawing lives in world.js (3D) and ui.js (overlay). */

'use strict';
const $=id=>document.getElementById(id);
let cv=null;
let W=window.innerWidth,H=window.innerHeight,DPR=1,groundY=0,basePPM=60;
const FX=0.38;
basePPM=Math.max(30,Math.min(H/6.2,W/4.4));

/* ---------- helpers ---------- */
function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const R=mulberry(14082025);
const rnd=(a,b)=>a+Math.random()*(b-a);
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const lerp=(a,b,t)=>a+(b-a)*t;
const pick=a=>a[Math.floor(Math.random()*a.length)];
function hash(i){const x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x);}
function gauss(){const u=1-Math.random(),v=Math.random();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}
function shade(h,a){let r,gg,b;if(h[0]==='#'){const n=parseInt(h.slice(1),16);r=n>>16;gg=n>>8&255;b=n&255;}else{[r,gg,b]=h.match(/\d+/g).map(Number);}const f=a<0?0:255,p=Math.abs(a);r=Math.round((f-r)*p+r);gg=Math.round((f-gg)*p+gg);b=Math.round((f-b)*p+b);return`rgb(${r},${gg},${b})`;}
const fmt=m=>String(Math.round(m*100)/100);
let vibOn=(()=>{try{return localStorage.getItem('gd_vib')!=='0'}catch(e){return true}})();
function vib(p){if(!vibOn)return;try{navigator.vibrate&&navigator.vibrate(p)}catch(e){}}

/* ---------- world generation: a village field ringed by mountains and trees ---------- */
const R2=mulberry(20251115);
const trees=[];{let x=-90;while(x<1000){const t=R2();trees.push({x,type:t<0.34?'poplar':t<0.66?'round':t<0.9?'pine':'house',s:0.8+R2()*0.5,c:R2(),z:R2()});x+=2.5+R2()*7;}}
trees.sort((a,b)=>a.z-b.z);
const fgs=[];{let x=-14;while(x<800){fgs.push({x,t:Math.floor(R2()*3),s:0.7+R2()*0.6});x+=5+R2()*12;}}
const clouds=[{fx:.12,fy:.1,s:1},{fx:.48,fy:.06,s:1.4},{fx:.78,fy:.15,s:0.85},{fx:1.05,fy:.09,s:1.15}];
const specs=[
  {x:-3.6,kam:'#e9e5dc',shal:'#2c3e5a',skin:'#b07049',face:1,cap:'#ffffff',hair:'#1d130c',fold:true},
  {x:4.0,kam:'#6d8fa6',shal:'#2b2b30',skin:'#a46a42',face:-1,scale:.95},
  {x:-5.6,kam:'#a0766a',shal:'#8a7a5c',skin:'#c58a5e',face:1,scale:.93},
  {x:6.4,kam:'#7d8f69',shal:'#33465f',skin:'#8f5a37',face:-1,scale:.97,fold:true,cap:'#6b5a46'}
];

/* ---------- audio ---------- */
let AC=null,NB=null,muted=(()=>{try{return localStorage.getItem('gd_snd')==='0'}catch(e){return false}})();
function audioInit(){if(AC){if(AC.state==='suspended')AC.resume().catch(()=>{});return;}try{AC=new(window.AudioContext||window.webkitAudioContext)();NB=AC.createBuffer(1,AC.sampleRate*2,AC.sampleRate);const d=NB.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;}catch(e){AC=null;}}
function env(gn,t,a,peak,dec){gn.gain.setValueAtTime(0.0001,t);gn.gain.exponentialRampToValueAtTime(peak,t+a);gn.gain.exponentialRampToValueAtTime(0.0001,t+a+dec);}
function noise(dur,type,freq,q,peak,att=0.002,dec=dur){if(!AC||muted)return null;const t=AC.currentTime;const s=AC.createBufferSource();s.buffer=NB;const f=AC.createBiquadFilter();f.type=type;f.frequency.value=freq;f.Q.value=q;const gn=AC.createGain();env(gn,t,att,peak,dec);s.connect(f);f.connect(gn);gn.connect(AC.destination);s.start(t);s.stop(t+att+dec+0.05);return f;}
function tone(freq,dur,type='sine',peak=0.2,slide=null,att=0.005){if(!AC||muted)return;const t=AC.currentTime;const o=AC.createOscillator();o.type=type;o.frequency.setValueAtTime(freq,t);if(slide)o.frequency.exponentialRampToValueAtTime(slide,t+att+dur);const gn=AC.createGain();env(gn,t,att,peak,dur);o.connect(gn);gn.connect(AC.destination);o.start(t);o.stop(t+att+dur+0.05);}
/* a human effort sound, made from a buzzing voice through vowel formants plus a breath of air at the start
   (no recordings, so it costs nothing to load). f0 = voice pitch, V = vowel formants, dur in seconds */
const VOW={ah:[[760,7,1],[1150,9,0.55],[2450,12,0.18]],uh:[[620,6,1],[1180,9,0.4],[2400,12,0.12]],eh:[[560,7,1],[1750,10,0.45],[2500,12,0.15]]};
function voice(f0,dur,V,peak,breath,fall=0.7){
  if(!AC||muted)return;const t=AC.currentTime,f=f0*(0.94+Math.random()*0.12);
  const o=AC.createOscillator();o.type='sawtooth';o.frequency.setValueAtTime(f*1.18,t);o.frequency.exponentialRampToValueAtTime(f,t+0.045);o.frequency.exponentialRampToValueAtTime(f*fall,t+dur);
  const lfo=AC.createOscillator(),lg=AC.createGain();lfo.frequency.value=5.5+Math.random()*2;lg.gain.value=f*0.025;lfo.connect(lg);lg.connect(o.frequency);
  const out=AC.createGain();out.gain.setValueAtTime(0.0001,t);out.gain.exponentialRampToValueAtTime(peak,t+0.018);out.gain.setValueAtTime(peak,t+dur*0.45);out.gain.exponentialRampToValueAtTime(0.0001,t+dur);
  const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=3200;out.connect(lp);lp.connect(AC.destination);
  for(const[fr,q,a]of V){const bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=fr*(0.96+Math.random()*0.08);bp.Q.value=q;const gg=AC.createGain();gg.gain.value=a*2.2;o.connect(bp);bp.connect(gg);gg.connect(out);}
  o.start(t);lfo.start(t);o.stop(t+dur+0.05);lfo.stop(t+dur+0.05);
  if(breath)noise(0.07+dur*0.2,'bandpass',1600,0.9,breath,0.004,0.06+dur*0.2);   // the "h" before the shout
}
/* counting out loud while bouncing: "aik, do, teen..." in the phone's own Urdu (or Hindi) voice, offline */
let countOn=true;try{countOn=localStorage.getItem('gd_count')!=='0';}catch(e){}
let webVoice;
/* Javed's own voice counting 1-28 (sfx/count/N.mp3, cut from his recording, levelled to sit under the game sounds); above 28 only the bounce tick */
const VOICE_MAX=28,voiceBuf=[];let voiceLoad=null,voiceSrc=null;
function loadVoice(){
  if(voiceLoad||!AC)return voiceLoad;
  voiceLoad=Promise.all(Array.from({length:VOICE_MAX},(_,i)=>fetch('sfx/count/'+(i+1)+'.mp3').then(r=>r.ok?r.arrayBuffer():Promise.reject(r.status))
    .then(b=>new Promise((ok,no)=>AC.decodeAudioData(b,ok,no))).then(buf=>{voiceBuf[i+1]=buf;}).catch(()=>{})));
  return voiceLoad;
}
/* the batsman's Dafoq call: Javed's recording, processed exactly like the counting voice */
let dafoqBuf=null,dafoqLoad=null;
function loadDafoq(){if(dafoqLoad||!AC)return;dafoqLoad=fetch('sfx/dafoq.mp3').then(r=>r.ok?r.arrayBuffer():Promise.reject(r.status)).then(b=>new Promise((ok,no)=>AC.decodeAudioData(b,ok,no))).then(b=>{dafoqBuf=b;}).catch(()=>{});}
function sayDafoq(){if(muted||!countOn||!AC||!dafoqBuf)return;try{if(voiceSrc){try{voiceSrc.stop();}catch(e){}}const s=AC.createBufferSource(),gn=AC.createGain();gn.gain.value=0.7;s.buffer=dafoqBuf;s.connect(gn);gn.connect(AC.destination);s.start();voiceSrc=s;}catch(e){}}
/* the batsman's hitting shout: Javed's recording, processed like the counting voice */
let hitBuf=null,hitLoad=null;
function loadHit(){if(hitLoad||!AC)return;hitLoad=fetch('sfx/hit.mp3').then(r=>r.ok?r.arrayBuffer():Promise.reject(r.status)).then(b=>new Promise((ok,no)=>AC.decodeAudioData(b,ok,no))).then(b=>{hitBuf=b;}).catch(()=>{});}
let throwBuf=null,throwLoad=null;
function loadThrow(){if(throwLoad||!AC)return;throwLoad=fetch('sfx/throw.mp3').then(r=>r.ok?r.arrayBuffer():Promise.reject(r.status)).then(b=>new Promise((ok,no)=>AC.decodeAudioData(b,ok,no))).then(b=>{throwBuf=b;}).catch(()=>{});}
function sayThrow(){if(muted||!AC||!throwBuf)return false;try{const s=AC.createBufferSource(),gn=AC.createGain();gn.gain.value=0.7;s.buffer=throwBuf;s.connect(gn);gn.connect(AC.destination);s.start();}catch(e){}return true;}
let slamBuf=null,slamLoad=null;
function loadSlam(){if(slamLoad||!AC)return;slamLoad=fetch('sfx/slam.mp3').then(r=>r.ok?r.arrayBuffer():Promise.reject(r.status)).then(b=>new Promise((ok,no)=>AC.decodeAudioData(b,ok,no))).then(b=>{slamBuf=b;}).catch(()=>{});}
function saySlam(){if(muted||!AC||!slamBuf)return false;try{const s=AC.createBufferSource(),gn=AC.createGain();gn.gain.value=0.7;s.buffer=slamBuf;s.connect(gn);gn.connect(AC.destination);s.start();}catch(e){}return true;}
function sayHit(){if(muted||!AC||!hitBuf)return false;try{const s=AC.createBufferSource(),gn=AC.createGain();gn.gain.value=0.7;s.buffer=hitBuf;s.connect(gn);gn.connect(AC.destination);s.start();}catch(e){}return true;}
function sayNum(n){
  if(muted||!countOn)return;
  if(AC&&!voiceLoad)loadVoice();
  if(voiceBuf.length){   // his recording is in the game: use it (and nothing else)
    const b=voiceBuf[n];if(!b)return;
    try{if(voiceSrc){try{voiceSrc.stop();}catch(e){}}const s=AC.createBufferSource(),gn=AC.createGain();gn.gain.value=0.7;s.buffer=b;s.connect(gn);gn.connect(AC.destination);s.start();voiceSrc=s;}catch(e){}
    return;
  }
  try{if(window.ApooshTTS&&ApooshTTS.lang()){ApooshTTS.say(String(n));return;}}catch(e){}
  try{const ss=window.speechSynthesis;if(!ss)return;
    if(webVoice===undefined){const vs=ss.getVoices();if(!vs.length)return;webVoice=vs.find(v=>/^ur/i.test(v.lang))||vs.find(v=>/^hi/i.test(v.lang))||null;}
    if(!webVoice)return;const u=new SpeechSynthesisUtterance(String(n));u.voice=webVoice;u.lang=webVoice.lang;u.rate=1.35;ss.cancel();ss.speak(u);}catch(e){}
}
const SFX0={
  count(n){sayNum(n);},
  slamVoice(){saySlam();},
  dafoqCall(){sayDafoq();},
  shoutHit(p){if(!sayHit())voice(p||125,0.2,VOW.uh,0.32,0.12,0.75);},      // "HUH!" as he swings into the gilli
  gruntMiss(p){if(!sayHit())voice((p||125)*0.92,0.26,VOW.uh,0.24,0.08,0.62);},   // a miss uses the same swing shout as a hit // "unh" on a miss
  shoutThrow(p){if(!sayThrow())voice((p||125)*1.05,0.34,VOW.ah,0.3,0.14,0.68);}, // "HAAH!" as the fielder lets it go
  shoutSlam(p){voice((p||125)*1.12,0.42,VOW.eh,0.3,0.1,0.6);},   // angry "HEYY" as the danda goes down
  tick(){tone(1500,0.035,'square',0.05);noise(0.05,'highpass',3500,1,0.18);},
  crack(q){noise(0.16,'bandpass',2000+q*900,0.9,0.55+q*0.4);tone(240,0.13,'triangle',0.4,80);tone(1900,0.05,'square',0.06);if(q>0.84)setTimeout(()=>tone(2600,0.25,'sine',0.06,3400),40);},
  whoosh(){const f=noise(0.3,'bandpass',450,2.5,0.22,0.07,0.23);if(f)f.frequency.exponentialRampToValueAtTime(2400,AC.currentTime+0.28);},
  thud(){tone(150,0.16,'sine',0.4,60);noise(0.09,'lowpass',700,1,0.3);},
  bounce(){tone(420+Math.random()*260,0.05,'triangle',0.09);noise(0.03,'bandpass',1800,2,0.06);},
  cheer(){noise(1.8,'bandpass',1100,0.5,0.22,0.3,1.5);setTimeout(()=>tone(1900,0.3,'sine',0.05,2700),150);setTimeout(()=>tone(2300,0.28,'sine',0.045,3100),420);},
  out(){tone(460,0.75,'sawtooth',0.1,105);noise(0.5,'lowpass',380,1,0.1);},
  coin(){[660,880,1320].forEach((f,i)=>setTimeout(()=>tone(f,0.12,'triangle',0.11),i*70));},
  step(){noise(0.07,'lowpass',380+Math.random()*160,0.8,0.08);tone(90+Math.random()*20,0.05,'sine',0.05,60);},
  aww(){tone(320,0.55,'sine',0.07,190);noise(0.9,'bandpass',480,0.7,0.12,0.12,0.75);}
};

const SFX={};for(const k of Object.keys(SFX0))SFX[k]=(a)=>{SFX0[k](a);fx({s:[k,a]});};
/* ---------- game state ---------- */
const SHOTS={ground:{ang:-0.2,name:'Zameeni'},line:{ang:0.22,name:'Seedha'},loft:{ang:0.55,name:'Hawai'}};
const game={shot:'loft',balls:0,target:25,mode:'cpu',sides:[],turn:0,won:false,longest:0};
let S='menu',sub={},ts=1,tsTarget=1,hitStop=0,shake=0,shx=0,shy=0,flash=0,T=0,cheer=0;
const cam={x:0.5,ppm:basePPM};
const g={x:0.06,y:0.03,vx:0,vy:0,rot:-0.15,vr:0,ground:true,rest:true,landed:false,landX:0,fric:8,held:null,noDrag:false,trail:[]};
const bat={a:-0.85,c:1,q:[],cur:null,mode:'play',pt:0,off:0,placed:false,jolt:0,swu:-1,swing:null,swMiss:false};
// danda lying on the ground: 70 cm, ~0.35 kg; yaw 0 = lying across the line of the throw
const DD={x:0,z:0,y:0,yaw:0,vx:0,vz:0,vy:0,w:0,roll:0,L:0.7,m:0.35};
function resetDanda(){Object.assign(DD,{x:0,z:0,y:0,yaw:0,vx:0,vz:0,vy:0,w:0,roll:0});}
function dandaEnds(){const h=DD.L/2;return[[DD.x-Math.sin(DD.yaw)*h,DD.z-Math.cos(DD.yaw)*h],[DD.x+Math.sin(DD.yaw)*h,DD.z+Math.cos(DD.yaw)*h]];}
function distSeg(px,pz,a,b){const vx=b[0]-a[0],vz=b[1]-a[1],t=clamp(((px-a[0])*vx+(pz-a[1])*vz)/(vx*vx+vz*vz),0,1);return[Math.hypot(px-a[0]-vx*t,pz-a[1]-vz*t),t];}
function stepDanda(dt){
  if(!DD.vx&&!DD.vz&&!DD.w&&!DD.vy&&DD.y<=0)return;
  DD.x+=DD.vx*dt;DD.z+=DD.vz*dt;DD.yaw+=DD.w*dt;DD.roll+=Math.hypot(DD.vx,DD.vz)*dt/0.018*Math.sign(DD.vx||1)*0.3;
  if(DD.y>0||DD.vy>0){DD.vy-=GRAV*dt;DD.y+=DD.vy*dt;if(DD.y<=0){DD.y=0;DD.vy=DD.vy<-0.6?-DD.vy*0.25:0;}}
  if(DD.y<=0){const sp=Math.hypot(DD.vx,DD.vz),d=0.5*GRAV*dt;   // wood sliding on dirt, mu ~ 0.5
    if(sp<=d){DD.vx=DD.vz=0;}else{DD.vx*=(sp-d)/sp;DD.vz*=(sp-d)/sp;}
    DD.w*=Math.max(0,1-6*dt);if(Math.abs(DD.w)<0.05)DD.w=0;}
}
const BZ=-0.45,ZX=-BZ*0.14,ZY=-BZ*0.62; // he stands just behind the hole; the gilli is in front of his feet
const SWZ=-0.15; // the swing plane, just in front of the batsman's body
const BX=0.01; // batsman's feet straddle the hole: the gilli sits in line with the middle of his body
const A0=-1.35,LD=0.7; // danda angle when its tip rests on the raised gilli end; danda length past the grip
const GL=0.15; // a real gilli is about 15 cm
const GREST={x:0.01,y:0.012,rot:0.45}; // gilli sitting in a slanted hole, the end toward the fielders raised
const TIP0=[GREST.x+GL/2*Math.cos(0.45),GREST.y+GL/2*Math.sin(0.45)]; // the raised end
const RING={x:0.39,y:1.05};
let fielders=[],parts=[],floats=[],timers=[];
const KCOL=[{kam:'#b8465a',shal:'#e9dfd0',cap:null,skin:'#b9794e',hair:'#1a120d'},{kam:'#3b6e8f',shal:'#3b6e8f',cap:'#f2efe8',skin:'#a1663f'},{kam:'#c9953a',shal:'#e6ddcf',cap:null,skin:'#c88d60',hair:'#2a1a10'},{kam:'#5e7d4f',shal:'#d8cfc0',cap:null,skin:'#8a5634'}];
function mkFielder(i){return{i,x:60,v:0,home:60,target:60,spd:5,react:0,stun:0,ph:0,run:0,tried:false,tried2:false,face:-1,catchPose:0,wind:0,...KCOL[i]};}
const diff=()=>1;
function later(s,fn){timers.push({t:s,fn});}
/* reactions: the batsman and fielders celebrate or sulk (world.js turns these into poses) */
let react={bat:null,field:null};
const RX={win:['joy','dance','clap','beat','point','salute'],shot:['fist','dance','beat','point','clap','salute'],sad:['sad','hips','facepalm','kick'],annoyed:['hips','facepalm','sad'],
  celeb:['celeb','celeb:dance','celeb:beat','celeb:point','celeb:salute','celeb:clap']};
const rx=k=>pick(RX[k]);
function setReact(who,type,dur,idx){react[who]={type,left:dur,dur,idx:idx===undefined?-1:idx};}
function tickReact(rdt){for(const k of ['bat','field']){const r=react[k];if(r){r.left-=rdt;if(r.left<=0)react[k]=null;}}}

const PAL=[['#8e3b3b','#a35a4c','#7a3434','#b0704a'],['#2f5f7a','#46798f','#28506a','#5a8396']];
const ZONES={1:[[16,26]],2:[[10,17],[22,32]],3:[[8,13],[17,25],[29,40]],4:[[7,11],[14,20],[24,32],[35,45]]};
/* ---------- secret field: the fielding side places its fielders; the batter can't see them until he swings ---------- */
const FMIN=5,FMAX=70;
const fieldSide=()=>1-game.turn;
let fieldSecret=false;
function presetField(kind,n){const out=[];for(let i=0;i<n;i++){const t=n===1?0.5:i/(n-1);out.push(Math.round(kind==='close'?lerp(7,17,t):kind==='deep'?lerp(24,52,t):lerp(10,42,t)));}return out;}
/* how good the computer is: Aasaan (easy), Theek (normal) and Mushkil (hard).
   strike/jug = how far off its timing is, whiff = chance of a total miss, throwK = how wide its throws scatter,
   catch = extra chance to hold a catch, read = how much it places fielders where you usually hit */
const CPU_LV=[
  {strike:0.22,whiff:0.10,jug:0.15,jugGrow:0.1,bias:0.2,throwK:1.3,catch:-0.08,read:0},
  {strike:0.11,whiff:0.035,jug:0.075,jugGrow:0.06,bias:0.08,throwK:0.75,catch:0.06,read:0.6},
  {strike:0.06,whiff:0.012,jug:0.052,jugGrow:0.035,bias:0,throwK:0.45,catch:0.16,read:1}];
const LV=()=>CPU_LV[clamp(cfg.diff|0,0,2)];
function cpuField(n){
  const base=presetField(pick(['close','spread','deep','spread']),n),h=(game.hLand||[]).slice(-8),lv=LV();
  if(h.length>=2&&lv.read>0){   // it has watched where you hit: spread the fielders around your usual distance
    const s=h.slice().sort((a,b)=>a-b),mid=s[s.length>>1];
    return base.map((v,i)=>{const t=n>1?i/(n-1):0.5,want=mid+(t-0.5)*Math.min(30,8+n*6);return Math.round(clamp(lerp(v,want,lv.read)+rnd(-2,2),FMIN,FMAX));});
  }
  return base.map(v=>Math.round(clamp(v+rnd(-3,3),FMIN,FMAX)));
}
function fieldersHidden(){
  if(!fieldSecret||!['field','turn','ready','tap','pop'].includes(S)||!game.sides.length)return false;
  if(NET.role)return myTeam()===game.turn;
  if(S==='field')return false;
  return !batCPU();
}
function revealField(){
  if(!fieldSecret)return;fieldSecret=false;
  for(const f of fielders)World.dust(f.x,0.05,0,14,'#ffffff',2.2);
  SFX.tick();
}
function openField(){
  const fs=game.sides[fieldSide()],mine=NET.role?capOwner(fs)===ME():true;
  if(!game.field||game.field.si!==fieldSide()||game.field.homes.length!==fielders.length)game.field={si:fieldSide(),homes:fielders.map(f=>Math.round(clamp(f.home||20,FMIN,FMAX)))};
  $('field').classList.remove('hide');
  $('fhd').textContent=mine?(teamGame()?`CAPTAIN ${capName(fs)} · SET THE FIELD`:`${fs.name}: SET YOUR FIELD`):'SECRET FIELD';
  $('fsb').textContent=mine?(NET.role?`Drag your fielders. ${curSide().name} won't see them until he swings.`:`${curName()}, look away! ${fs.name==='You'?'You place':fs.name+' places'} the fielders.`):`${fs.name} is placing the fielders secretly…`;
  $('fui').style.display=mine?'':'none';
  if(mine)renderFieldUI();
}
/* field setter: little players you drag along the pitch, the danda and gilli at the batting end */
const fieldUI={dragged:false};
const FIELD_DANDA='<svg class="fbat" viewBox="0 0 44 64" aria-hidden="true"><ellipse cx="22" cy="58" rx="18" ry="3.5" fill="rgba(0,0,0,.3)"/><g transform="rotate(20 22 30)"><rect x="18.5" y="0" width="7" height="50" rx="3.5" fill="#d29b5c" stroke="#5e3a1c" stroke-width="1.6"/><rect x="18.5" y="36" width="7" height="14" rx="3" fill="#8a5a33"/></g><path d="M6 55 Q22 47 38 55 Q22 63 6 55Z" fill="#f0c587" stroke="#5e3a1c" stroke-width="1.6"/><path d="M12 55 L32 55" stroke="#b9874f" stroke-width="1"/></svg>';
function fielderSVG(f){
  const sk=f.skin||'#b07049',sh=f.kam||'#6d8fa6',tr=f.shal||'#2b2b30';
  return `<svg viewBox="0 0 40 58" aria-hidden="true"><ellipse cx="20" cy="55" rx="11" ry="3" fill="rgba(0,0,0,.35)"/>
  <rect x="12.5" y="33" width="6.5" height="20" rx="3" fill="${tr}"/><rect x="21" y="33" width="6.5" height="20" rx="3" fill="${tr}"/>
  <rect x="5" y="17" width="6" height="16" rx="3" fill="${sh}" transform="rotate(14 8 18)"/><rect x="29" y="17" width="6" height="16" rx="3" fill="${sh}" transform="rotate(-14 32 18)"/>
  <rect x="10" y="15" width="20" height="21" rx="6" fill="${sh}" stroke="rgba(0,0,0,.25)" stroke-width="1"/>
  <circle cx="20" cy="9" r="7.5" fill="${sk}"/><path d="M12.5 8 Q13 1 20 1 Q27 1 27.5 8 Q24 5 20 5 Q16 5 12.5 8Z" fill="${f.hair||'#1d130c'}"/></svg>`;
}
function renderFieldUI(){
  const st=$('fstrip');st.innerHTML=FIELD_DANDA;const n=fielders.length;st.classList.toggle('hint',!fieldUI.dragged);
  for(let m=10;m<=FMAX;m+=10){const t=document.createElement('div');t.className='ftick';t.style.left=((m-FMIN)/(FMAX-FMIN)*100)+'%';t.textContent=m+'m';st.appendChild(t);}
  fielders.forEach((f,i)=>{
    const d=document.createElement('div');d.className='fm';d.style.top=(4+(i%2)*40)+'px';
    d.innerHTML=fielderSVG(f)+'<i class="fa l">‹</i><i class="fa r">›</i>';const lab=document.createElement('span');d.appendChild(lab);
    const set=v=>{v=Math.round(clamp(v,FMIN,FMAX));game.field.homes[i]=v;f.home=f.x=f.target=v;d.style.left=((v-FMIN)/(FMAX-FMIN)*100)+'%';lab.textContent=v+'m';};
    st.appendChild(d);set(game.field.homes[i]);
    d.addEventListener('pointerdown',e=>{e.preventDefault();d.setPointerCapture(e.pointerId);d.classList.add('drag');if(!fieldUI.dragged){fieldUI.dragged=true;st.classList.remove('hint');}});
    d.addEventListener('pointermove',e=>{if(!d.classList.contains('drag'))return;const r=st.getBoundingClientRect();set(FMIN+(e.clientX-r.left)/r.width*(FMAX-FMIN));});
    const up=()=>d.classList.remove('drag');d.addEventListener('pointerup',up);d.addEventListener('pointercancel',up);
  });
}
/* the 🧢 Field button: the fielding side can move its fielders before any ball */
function fieldEditOK(side){
  if(!inMatch()||game.won||paused||game.fieldEdit||!['turn','ready'].includes(S)||!game.sides.length)return false;
  const fs=game.sides[fieldSide()];if(!fs||capCPU(fs))return false;
  // who: undefined = this phone, 'any' = any person, a number = that phone (the fielding captain decides)
  return side===undefined?(!NET.role||capOwner(fs)===ME()):side==='any'?true:capOwner(fs)===side;
}
function openFieldEdit(){
  if(!fieldEditOK('any'))return;
  game.fieldEdit={back:S,sub,turnShown:!$('turn').classList.contains('hide')};$('turn').classList.add('hide');shotBar(false);
  if(!game.field||game.field.si!==fieldSide())game.field={si:fieldSide(),homes:fielders.map(f=>Math.round(f.home))};
  S='field';sub={};hud();openField();
}
function fieldDone(){if(S!=='field'||!game.field)return;input('field',game.field.homes.slice());}
function applyField(v){
  if(S!=='field'||!Array.isArray(v)||!game.field)return;
  const n=fielders.length;game.field.homes=Array.from({length:n},(_,i)=>Math.round(clamp(+v[i]||20,FMIN,FMAX)));
  fielders.forEach((f,i)=>{f.home=f.x=f.target=game.field.homes[i];});
  (game.fieldMem=game.fieldMem||{})[game.field.si]=game.field.homes.slice();
  game.fieldHide=true;fieldSecret=true;$('field').classList.add('hide');
  if(game.fieldEdit){const e=game.fieldEdit;game.fieldEdit=null;S=e.back;sub=e.sub||{t:0};if(e.turnShown)$('turn').classList.remove('hide');if(S==='ready')shotBar(!batCPU()&&myTurn());hud();return;}
  S='turn';sub={};fillTurn();$('turn').classList.remove('hide');
}
/* players still taking part: not put out as a Dafoq fielder, and not already a Dafoq winner */
const aliveIdx=s=>s.players.map((_,i)=>i).filter(i=>(!s.alive||s.alive[i])&&!(s.won&&s.won[i]));
const winners=s=>s.won?s.won.filter(Boolean).length:0;
function fieldIdx(side){return game.duel&&game.sides[1-game.duel.si]===side?[game.duel.f]:aliveIdx(side);}
function placeFielders(first){
  const side=game.sides.length?throwSide():null,idx=side?fieldIdx(side):[0,1],n=idx.length,si=side?game.sides.indexOf(side):1;
  if(first||fielders.length!==n){fielders=[];for(let k=0;k<n;k++){const i=idx[k];const f=mkFielder(k);f.pi=i;f.look=side?side.looks[i]:makeLook(31+i*13);const lc=lookColors(si,i,f.look);f.kam=lc.kam;f.shal=lc.shal;f.skin=f.look.skin;f.hair=f.look.hair;f.cap=null;f.name=side?side.players[i]:'';f.x=40;fielders.push(f);}first=true;}
  const zones=ZONES[n]||ZONES[4];
  const cf=game.field&&game.field.si===si&&game.field.homes.length===n?game.field.homes:null;
  fielders.forEach((f,i)=>{const z=zones[i];f.home=cf?clamp(cf[i]+rnd(-0.5,0.5),FMIN,FMAX):rnd(z[0],z[1]);f.target=f.home;f.spd=7;f.react=0;f.stun=0;f.tried=f.tried2=false;f.wind=0;if(first)f.x=f.home;});
}

/* ---------- physics ---------- */
// 70 g hardwood gilli: drag k = ½ρCdA/m ≈ 0.039 /m (terminal speed ≈ 16 m/s)
const GRAV=9.81,KD=0.014,E_G=0.32,MU_I=0.5,MU_S=0.9;
function stepG(c,dt,onB){
  if(c.rest||c.held)return;
  const n=Math.max(1,Math.ceil(dt*120)),h=dt/n;
  for(let i=0;i<n&&!c.rest;i++){
    if(!c.ground){
      const sp=Math.hypot(c.vx,c.vy,c.vz||0),k=KD*sp;
      c.vx-=k*c.vx*h;c.vy-=(GRAV+k*c.vy)*h;c.vz=(c.vz||0)*(1-k*h);
      c.x+=c.vx*h;c.y+=c.vy*h;c.z=(c.z||0)+c.vz*h;c.rot+=c.vr*h;c.vr*=1-0.3*h;
      if(c.y<=0){
        c.y=0;const first=!c.landed;if(first){c.landed=true;c.landX=c.x;}
        const vn=-c.vy,endOn=Math.abs(Math.sin(c.rot)),e=E_G*(0.55+0.9*endOn);   // lands on its tip: livelier bounce
        c.vy=e*vn;const hs=Math.hypot(c.vx,c.vz),nh=Math.max(0,hs-MU_I*(1+e)*vn),f=hs>0?nh/hs:0;c.vx*=f;c.vz*=f;
        c.vr=-c.vr*0.35+(hs-nh)*5*(endOn>0.5?1:-1);                                // friction at contact flips it end over end
        if(c.vy<0.45){c.vy=0;c.ground=true;}
        if(onB)onB(c,first);
      }
    }else{
      const hs=Math.hypot(c.vx,c.vz||0),d=MU_S*GRAV*h;
      if(hs<=d){c.vx=0;c.vz=0;c.rest=true;c.rot=Math.round(c.rot/Math.PI)*Math.PI;break;}
      const f=(hs-d)/hs;c.vx*=f;c.vz=(c.vz||0)*f;c.x+=c.vx*h;c.z+=c.vz*h;c.rot+=c.vx*h*4;
    }
  }
}
function predict(){const c={x:g.x,y:g.y,z:0,vx:g.vx,vy:g.vy,vz:0,rot:g.rot,vr:g.vr,ground:false,rest:false,landed:false,landX:0,held:null};let t=0;while(!c.rest&&t<20){stepG(c,1/120);t+=1/120;}return{land:c.landX,rest:c.x};}

/* ---------- effects ---------- */
function burst(x,y,n,col,sp){World.dust(x,y,(g&&g.z)||0,n,col,sp);return;for(let i=0;i<n;i++){const a=Math.random()*Math.PI;parts.push({x,y:y+0.02,vx:Math.cos(a)*rnd(0.3,1)*sp,vy:Math.sin(a)*rnd(0.3,1)*sp,life:rnd(0.4,0.9),max:0.9,col,sz:rnd(0.03,0.07)});}}
function floatText(x,y,t,col,sc=1){floats.push({x,y,t,col,life:1.6,sc});fx({f:[R3(x),R3(y),t,col,sc]});}
let bannerT=null;
function banner(t,s,c){fx({b:[t,s||'',c||'#fff']});const b=$('banner');document.body.classList.add('banner-on');clearTimeout(banner.tm);banner.tm=setTimeout(()=>document.body.classList.remove('banner-on'),1600);$('bt').textContent=t;$('bt').style.color=c||'#fff';$('bs').textContent=s||'';b.classList.remove('show');void b.offsetWidth;b.classList.add('show');}
function setPrompt(t){$('prompt').textContent=t;fx({p:t});}
let shotPicked=false;   // once a shot is chosen the buttons go away until the next ball
function shotBar(show){$('shots').classList.toggle('hide',!show||shotPicked);}
/* ---------- match setup ---------- */
const cfg={diff:(()=>{try{const s=localStorage.getItem('gd_diff');return s!==null&&+s>=0&&+s<=2?+s:1;}catch(e){return 1;}})(),mode:'cpu',size:2,target:25,scene:(()=>{try{const v=localStorage.getItem('gd_scene')||'village';return v==='hunza'?'soq':v}catch(e){return 'village'}})()};
const SKINS=['#c68a5c','#a86b43','#d39a6a','#8d5a36','#b9784f','#deaa7c','#9a6040','#c99568'];
const HAIRC=['#120b07','#1d130c','#2b1a10','#3a2516','#24170e'];
function makeLook(seed){const r=mulberry(seed),pk=a=>a[Math.floor(r()*a.length)],old=false,capT=r()<0.4?pk(['cap','cap','cap','topi']):null;
  return{seed,skin:pk(SKINS),hair:old?pk(['#8f8a83','#a8a29a','#6f6a64']):pk(HAIRC),hairStyle:pk(['short','long','curly','side','short']),capT,
    capC:capT==='topi'?pk(['#f1ece2','#e6e0d2']):pk(['#1f2a3a','#e9e6df','#7a2f2f','#2f4a3a','#3a3a3f']),
    beard:pk([null,null,null,'stubble','stubble','mustache']),build:0.88+r()*0.14,height:0.94+r()*0.1,
    vest:null,kv:(r()-0.5)*0.4,matchShal:false,shirt:pk(['tee','tee','polo','shirt']),tucked:r()<0.3,pants:pk(['#2c3e5a','#33465f','#2b2b30','#4a4f57','#8a7a5c','#3d4a36']),shoe:pk(['#e9e6df','#e9e6df','#2b2b30','#7a5a3c','#3a4f6b'])};}
function lookColors(si,i,L){L=L||{};const kam=shade(PAL[si][i%4],L.kv);return{kam,shal:L.pants||'#2c3e5a'};}
/* avatars: ready-made looks. The avatar decides the player's face, hair and cap in the match; the shirt is the team colour. */
const AVATARS=[
  {skin:'#c68a5c',hair:'#1d130c',capT:null,beard:null},{skin:'#deaa7c',hair:'#2b1a10',capT:null,beard:'stubble'},
  {skin:'#a86b43',hair:'#120b07',capT:'cap',capC:'#1f2a3a',beard:null},{skin:'#d39a6a',hair:'#24170e',capT:'cap',capC:'#7a2f2f',beard:'mustache'},
  {skin:'#8d5a36',hair:'#120b07',capT:null,beard:'stubble'},{skin:'#c99568',hair:'#3a2516',capT:'topi',capC:'#f1ece2',beard:null},
  {skin:'#b9784f',hair:'#1d130c',capT:'cap',capC:'#e9e6df',beard:'stubble'},{skin:'#deaa7c',hair:'#3a2516',capT:null,beard:'mustache'}];
function avatarSVG(ai,shirt){const a=AVATARS[ai%AVATARS.length]||AVATARS[0];
  return `<svg viewBox="0 0 64 64" class="avt"><circle cx="32" cy="32" r="32" fill="#1c4f38"/><path d="M8 64c2-16 12-20 24-20s22 4 24 20z" fill="${shirt||'#3b6e8f'}"/><rect x="27" y="38" width="10" height="9" fill="${a.skin}"/><ellipse cx="32" cy="27" rx="12.5" ry="15" fill="${a.skin}"/>`+
    (a.capT==='cap'?`<path d="M19 22c0-10 26-10 26 0z" fill="${a.capC}"/><path d="M19 21h34c2 0 2 3 0 3H19z" fill="${a.capC}"/>`:a.capT==='topi'?`<path d="M20 20c1-9 23-9 24 0z" fill="${a.capC}"/><path d="M19.5 24c0-3 25-3 25 0v-4h-25z" fill="${a.hair}"/>`:`<path d="M19 26c-2-16 28-16 26 0c-3-6-6-8-13-8s-10 2-13 8z" fill="${a.hair}"/>`)+
    `<circle cx="27" cy="28" r="1.7" fill="#1a120c"/><circle cx="37" cy="28" r="1.7" fill="#1a120c"/><path d="M28 36q4 2.5 8 0" stroke="#7a3f36" stroke-width="1.6" fill="none" stroke-linecap="round"/>`+
    (a.beard==='mustache'?`<path d="M27 33.5q5-2.5 10 0" stroke="${a.hair}" stroke-width="2.2" fill="none" stroke-linecap="round"/>`:a.beard==='stubble'?`<path d="M20.5 32c2 13 21 13 23 0c-3 6-20 6-23 0z" fill="${a.hair}" opacity=".35"/>`:'')+`</svg>`;}
function loadRoster(){let r=null;try{r=JSON.parse(localStorage.getItem('gd_roster')||'null')}catch(e){}
  const d={cpu:[[{n:'You',a:0}]],'2p':[[{n:'Player 1',a:0}],[{n:'Player 2',a:2}]],net:[[{n:'Player',a:0}]],
    team:[0,1].map(t=>[0,1,2,3].map(i=>({n:`${t?'B':'A'} Player ${i+1}`,a:(t*4+i)%8}))),caps:[0,0]};
  if(r)for(const k of ['cpu','2p','net','team'])if(Array.isArray(r[k]))r[k].forEach((sd,si)=>Array.isArray(sd)&&sd.forEach((p,pi)=>{if(d[k][si]&&d[k][si][pi]&&p){d[k][si][pi].n=String(p.n||d[k][si][pi].n).slice(0,14);d[k][si][pi].a=(+p.a||0)%8;}}));
  if(r&&Array.isArray(r.caps))d.caps=[+r.caps[0]||0,+r.caps[1]||0];return d;}
const roster=loadRoster();
roster['2p'][0][0]=roster.net[0][0]=roster.cpu[0][0];   // one profile: you are the same player in every mode
const profSet=()=>{try{return localStorage.getItem('gd_prof')==='1'}catch(e){return true}};
const saveRoster=()=>{try{localStorage.setItem('gd_roster',JSON.stringify(roster))}catch(e){}};
function avLook(p,seed){const L=makeLook(seed),a=AVATARS[p.a%AVATARS.length];return Object.assign(L,{skin:a.skin,hair:a.hair,capT:a.capT,capC:a.capC||L.capC,beard:a.beard});}
function mkSides(){
  const seed=Math.floor(Math.random()*1e6),sc=()=>({score:0,next:0});
  const side=(name,ps,si,extra)=>Object.assign({name,players:ps.map(p=>p.n),avs:ps.map(p=>p.a),looks:ps.map((p,i)=>avLook(p,seed+si*101+i*7)),alive:ps.map(()=>true),won:ps.map(()=>false),pair:{},cap:0,...sc()},extra||{});
  if(cfg.mode==='cpu'){const me=roster.cpu[0][0];return [side(me.n,[me],0,{cpu:false}),side('Computer',[{n:'Computer',a:(me.a+3)%8}],1,{cpu:true})];}
  if(cfg.mode==='net'){   // the phones in the lobby, by team; empty spots are the computer
    const me=roster.net[0][0],L=NET.lobby&&NET.lobby.length?NET.lobby:[{id:0,n:me.n,a:me.a,t:0},{id:1,n:'Player 2',a:2,t:1}];
    const used={},nm=x=>{x=String(x||'Player').slice(0,14);let k=x,c=2;while(used[k])k=x.slice(0,11)+' '+c++;used[k]=1;return k;};
    const T=[0,1].map(t=>L.filter(p=>p.t===t)),n=Math.max(1,T[0].length,T[1].length);
    return T.map((ps,t)=>{const f=ps.map(p=>({n:nm(p.n),a:(+p.a||0)%8,id:p.id}));let c=1;
      while(f.length<n){f.push({n:nm(n>1?'Computer '+c:'Computer'),a:(t*3+c+2)%8,id:'cpu'});c++;}
      const hi=f.findIndex(p=>p.id===0),cap=hi>=0?hi:Math.max(0,f.findIndex(p=>p.id!=='cpu'));
      return side(n===1?f[0].n:(t?'Team B':'Team A'),f,t,{own:f.map(p=>p.id),own0:f.map(p=>p.id),cap,cap0:cap});});
  }
  if(cfg.mode==='2p'){const a=roster['2p'][0][0],b=roster['2p'][1][0];return [side(a.n,[a],0),side(b.n===a.n?b.n+' 2':b.n,[b],1)];}
  const n=cfg.size;return [0,1].map(t=>side(t?'Team B':'Team A',roster.team[t].slice(0,n),t,{cap:Math.min(n-1,roster.caps[t]||0)}));
}
let rosterStart=false;
/* the players screen: names, avatars and (team games) the captain. Shown once; after that the saved players are used
   and the Players button on the menu edits them. */
function openRoster(startAfter){
  rosterStart=!!startAfter;const m=cfg.mode,box=$('rsl');box.innerHTML='';
  const sides=m==='team'?roster.team.map(t=>t.slice(0,cfg.size)):roster[m];
  $('rsh').textContent=m==='team'?'Teams':m==='net'?'Your player':'Players';
  sides.forEach((ps,si)=>{
    const col=document.createElement('div');col.className='rcol';
    if(m==='team'){const h=document.createElement('div');h.className='lbl';h.textContent=(si?'TEAM B':'TEAM A')+' · tap ★ for captain';col.appendChild(h);}
    ps.forEach((p,pi)=>{
      const row=document.createElement('div');row.className='rrow';
      const av=document.createElement('button');av.className='rav';const draw=()=>{av.innerHTML=avatarSVG(p.a,PAL[m==='cpu'||m==='net'?0:si][pi%4]);};draw();
      av.addEventListener('click',()=>{p.a=(p.a+1)%AVATARS.length;draw();saveRoster();SFX0.tick();});
      const inp=document.createElement('input');inp.maxLength=14;inp.value=p.n;inp.addEventListener('input',()=>{p.n=inp.value.trim().slice(0,14)||(m==='cpu'?'You':'Player');saveRoster();});
      row.appendChild(av);row.appendChild(inp);
      if(m==='team'){const c=document.createElement('button');c.className='rcap'+(roster.caps[si]===pi?' on':'');c.textContent='★';c.addEventListener('click',()=>{roster.caps[si]=pi;saveRoster();col.querySelectorAll('.rcap').forEach((x,k)=>x.classList.toggle('on',k===pi));});row.appendChild(c);}
      col.appendChild(row);});
    box.appendChild(col);});
  $('rsh').textContent=!profSet()?'Your profile':$('rsh').textContent;$('rgo').textContent=rosterStart?'START ▶':'SAVE';$('roster').classList.remove('hide');
}
const curSide=()=>game.sides[game.turn];
const throwSide=()=>game.sides[1-game.turn];
/* who plays each player: in a phone match every player belongs to a phone (host 0, others 1..7) or to the
   computer ('cpu' - an empty spot, or a phone that left). Off the network a side is either the computer or this phone. */
const ME=()=>NET.myId|0;
function ownerOf(s,i){if(!s)return 'cpu';if(s.own){const o=s.own[i];return o===undefined?'cpu':o;}return s.cpu?'cpu':ME();}
const pcpu=(s,i)=>ownerOf(s,i)==='cpu';
const capCPU=s=>!s||pcpu(s,s.cap||0);
const capOwner=s=>ownerOf(s,s?s.cap||0:0);
const batCPU=()=>!!curSide()&&pcpu(curSide(),curSide().next);
function myTeam(){if(!NET.role)return -1;for(let k=0;k<game.sides.length;k++){const o=game.sides[k].own;if(o&&o.includes(ME()))return k;}return NET.role==='guest'?1:0;}
const throwerCPU=f=>{f=f||sub.thrower||g.held;return !!throwSide()&&pcpu(throwSide(),f?f.pi:0);};
const curName=()=>{const s=curSide();return s?s.players[s.next]:'';};
const isCPU=()=>S!=='menu'&&S!=='over'&&batCPU();
function boardHTML(){return game.sides.map((s,i)=>`<div class="brow${i===game.turn?' cur':''}"><span class="bn">${s.name}${teamGame()?' · '+winners(s)+'🏆 '+aliveIdx(s).length+'👤':''}</span><span class="bar"><i style="width:${Math.min(100,s.score/game.target*100)}%"></i></span><span class="bs">${s.score}</span></div>`).join('');}
function hud(){
  updPauseBtn();
  if(!game.sides.length)return;
  $('bname').textContent=curName();
  $('bside').textContent=onDafoq(curSide())?'DAFOQ shot':'';
  $('board').innerHTML=boardHTML();$('tgt').textContent='TARGET '+game.target;
}

/* ---------- two phones (room capability) ---------- */
const NET={rx:{},myId:0,lobby:[],role:null,r:null,side:0,snap:null,applied:null,q:[],lastPres:0,lastFlush:0,started:false,gotSetup:false,phase:null,fside:-1};
let roomNS=null;
(async()=>{try{if(window.claude&&typeof window.claude.use==='function')roomNS=await window.claude.use('room');}catch(e){roomNS=null;}})();
const APP=typeof window.AndroidNet!=='undefined';
const NETL={onOpen:null,onFound:null,onError:null};
function makeLocalRoom(){
  const H={},PH=[],LH=[];let peersArr=[];
  window.__netEvent=(type,data)=>{
    if(type==='openf'||type==='msgf'||type==='closef'){   // host: every phone has a number
      const s=String(data),k=s.indexOf('|'),id=+(k<0?s:s.slice(0,k)),rest=k<0?'':s.slice(k+1);
      if(type==='closef'){delete NET.rx[id];LH.forEach(h=>h(id));return;}
      NET.rx[id]=performance.now();if(type==='openf')return;
      let o;try{o=JSON.parse(rest);}catch(e){return;}
      if(o&&typeof o.t==='string'&&o.t!=='__pres')(H[o.t]||[]).forEach(h=>h({topic:o.t,data:o.d,from:id,sameTab:false,isMe:false}));
      return;}
    if(type==='msg'||type==='open')NET.lastRx=performance.now();
    if(type==='msg'){let o;try{o=JSON.parse(data);}catch(e){return;}
      if(o&&o.t==='__pres'){peersArr=[Object.freeze({sameTab:false,isMe:false,presence:o.d||{}})];PH.forEach(h=>h({peers:peersArr,joined:[],left:[],updated:peersArr}));}
      else if(o&&typeof o.t==='string')(H[o.t]||[]).forEach(h=>h({topic:o.t,data:o.d,sameTab:false,isMe:false}));}
    else if(type==='open'){if(NETL.onOpen)NETL.onOpen();}
    else if(type==='close'){const l=peersArr.length?peersArr:[{sameTab:false}];peersArr=[];PH.forEach(h=>h({peers:[],joined:[],left:l,updated:[]}));}
    else if(type==='found'){if(NETL.onFound)NETL.onFound(data);}
    else if(type==='error'){if(NETL.onError)NETL.onError(data);}
  };
  return{emit:async(t,d)=>{AndroidNet.send(JSON.stringify({t,d}));},on:(t,h)=>{(H[t]=H[t]||[]).push(h);return()=>{};},
    presence:async(p)=>{AndroidNet.send(JSON.stringify({t:'__pres',d:p}));},peers:()=>peersArr,onPeers:h=>{PH.push(h);return()=>{};},
    emitTo:(id,t,d)=>{try{AndroidNet.sendTo(id,JSON.stringify({t,d}));}catch(e){}},onLeft:h=>{LH.push(h);},
    leave:async()=>{AndroidNet.close();},connected:()=>true};
}
function fx(o){if(NET.role==='host'&&NET.r){NET.q.push(o);if(NET.q.length>40)NET.q.shift();}}
/* the phone (or 'cpu') whose move it is now */
function actorOwner(){
  if(!game.sides.length)return -1;
  const s=curSide(),fs=throwSide();
  if(S==='toss'){const i=sub.phase==='call'?sub.caller:sub.phase==='won'?sub.winner:-1;return i>=0?capOwner(game.sides[i]):-1;}
  if(S==='aim')return sub.thrower?ownerOf(fs,sub.thrower.pi):-1;
  if(S==='field')return capOwner(fs);
  if(S==='pick')return game.pickBy===undefined?-1:game.pickBy;
  if(['turn','ready','tap','pop','jugready','juggle'].includes(S))return ownerOf(s,s.next);
  return -1;
}
function myTurn(){return !NET.role||actorOwner()===ME();}
function input(k,v){
  if(NET.role==='guest'){if(NET.r)NET.r.emit('in',{k,v}).catch(()=>{});if(k==='shot')setShot(v);return;}
  applyInput(k,v,NET.role==='host'?0:null);
}
function applyInput(k,v,from){
  if(k!=='fieldedit'&&from!==null&&NET.role&&actorOwner()!==from)return;
  if(k==='fieldedit'){if(from===null||!NET.role||fieldEditOK(from))openFieldEdit();return;}
  if(k==='pick'){if(S==='pick'&&pickCb&&pickList.includes(v)){const cb=pickCb;pickCb=null;cb(v);}return;}
  if(k==='tap')action();
  else if(k==='shot'){if(S==='ready'&&typeof v==='string'&&SHOTS[v])setShot(v);}
  else if(k==='begin')beginTurn();
  else if(k==='field')applyField(v);
  else if(k==='call'&&(v==='heads'||v==='tails'))tossCall(v);
  else if(k==='choose'&&(v==='bat'||v==='field'))tossChoose(v);
}
/* ---------- team lobby (host phone + up to 7 more) ---------- */
function lobbyBroadcast(){
  if(NET.role!=='host')return;
  if(NET.r)Promise.resolve(NET.r.emit('lobby',{l:NET.lobby,full:NET.lobby.length>=8})).catch(()=>{});
  showLobby();
}
function lobbyMove(e){const other=1-e.t;if(NET.lobby.filter(x=>x.t===other).length>=4)return;e.t=other;SFX0.tick();lobbyBroadcast();}
function showLobby(){
  if(NET.gotSetup||(NET.role==='host'&&NET.started))return;
  const L=NET.lobby||[],host=NET.role==='host',T=[0,1].map(t=>L.filter(p=>p.t===t)),n=Math.max(1,T[0].length,T[1].length);
  [['lbA',0],['lbB',1]].forEach(([id,t])=>{const box=$(id);box.innerHTML='';
    T[t].forEach(p=>{const r=document.createElement('button');r.className='lbp'+(p.id===ME()?' me':'');
      r.innerHTML=avatarSVG(p.a,PAL[t][0])+'<span></span>'+(host&&p.id!==0?'<em>⇄</em>':'');r.querySelector('span').textContent=p.n+(p.id===0?' 📡':'')+(p.id===ME()?' (you)':'');
      if(host)r.addEventListener('click',()=>lobbyMove(p));else r.disabled=true;box.appendChild(r);});
    for(let k=T[t].length;k<n;k++){const r=document.createElement('div');r.className='lbp cpu';r.innerHTML='<i>🤖</i><span>Computer</span>';box.appendChild(r);}});
  const cpu=2*n-L.length;
  $('lbt').textContent=n===1?'1 vs 1':`${n} vs ${n}`;
  $('lbs').textContent=host?(L.length<2?'Waiting for phones to join… They connect to your hotspot (or the same Wi-Fi) and tap Join.':`${L.length} phone${L.length>1?'s':''} here`+(cpu?` · the computer plays ${cpu} spot${cpu>1?'s':''}`:'')+'. Tap a player to move him.')
    :`Waiting for ${(L.find(x=>x.id===0)||{n:'the host'}).n} to start…`+(cpu?` · the computer plays ${cpu} spot${cpu>1?'s':''}`:'');
  $('lbaddr').textContent=host&&NET.addr?'Address: '+NET.addr.split(',')[0]:'';
  $('lbgo').style.display=host?'':'none';$('lbgo').disabled=L.length<2;
  $('lbswap').style.display=host?'none':'';
  $('lobby').classList.remove('hide');
}
function lobbyStart(){
  if(NET.role!=='host'||NET.started||NET.lobby.length<2)return;
  try{AndroidNet.setOpen(false);}catch(e){}
  NET.started=true;NET.inLobby=false;cfg.mode='net';$('lobby').classList.add('hide');startGame();
}
/* a phone left the match: the computer takes over its player (and the captain's job goes to someone still here) */
function phoneLeft(id){
  delete NET.rx[id];
  if(!NET.started){const k=NET.lobby.length;NET.lobby=NET.lobby.filter(x=>x.id!==id);if(NET.lobby.length!==k)lobbyBroadcast();return;}
  NET.lobby=NET.lobby.filter(x=>x.id!==id);
  const who=[];
  game.sides.forEach(s=>{if(!s.own)return;s.own.forEach((o,i)=>{if(o===id){s.own[i]='cpu';who.push(s.players[i]);}});
    if(pcpu(s,s.cap||0)){const h=s.own.findIndex(o=>o!=='cpu');if(h>=0)s.cap=h;}});
  if(!who.length||!game.sides.length)return;
  banner(`${who.join(', ').toUpperCase()} LEFT`,'The computer plays for him now','#ffb347');
  if(S==='field'&&capCPU(throwSide())&&game.field)applyField(game.field.homes);
  if(S==='pick'&&game.pickBy===id){game.pickBy='cpu';if(game.pk)game.pk[4]='cpu';renderPick();later(1.2,cpuPick);}
  if(S==='turn')fillTurn();if(S==='toss')renderToss();hud();
}
/* the same phone came back during the match: give it its player again */
function seatBack(id){
  let back=false;
  game.sides.forEach(s=>{if(!s.own0)return;s.own0.forEach((o,i)=>{if(o===id&&s.own[i]==='cpu'){s.own[i]=id;back=true;}});if(s.own0[s.cap0]===id&&s.own[s.cap0]===id)s.cap=s.cap0;});
  NET.r.emitTo(id,'welcome',{id});sendSetup(id);
  if(back){const s=game.sides.find(x=>x.own0&&x.own0.includes(id));banner('WELCOME BACK',s?s.players[s.own0.indexOf(id)]:'','#7ef29a');if(S==='turn')fillTurn();if(S==='toss')renderToss();}
}
function netStat(title,msg,kind){const b=$('nstat');b.classList.remove('hide','ok','bad');if(kind)b.classList.add(kind);$('nst1').textContent=title;$('netmsg').textContent=msg||'';}
function netCancel(){
  JOIN.on=false;clearTimeout(JOIN.tm);if(NET.r){try{Promise.resolve(NET.r.leave()).catch(()=>{});}catch(e){}NET.r=null;}
  NET.role=null;NET.started=false;NET.gotSetup=false;NET.inLobby=false;NET.myId=0;NET.lobby=[];NET.rx={};$('lobby').classList.add('hide');$('nstat').classList.add('hide');$('nlist').classList.add('hide');$('ncodebox').classList.add('hide');$('nhost').classList.remove('on');$('njoinbig').classList.remove('on');
}
/* Joining over a hotspot needs no typing: keep trying, every 2.5 s, (1) the hotspot phone itself (the Wi-Fi gateway),
   (2) any host heard announcing itself, (3) the usual hotspot addresses - until one answers. */
const JOIN={on:false,busy:false,found:[],tm:0,t0:0,ok:false};
function appGuestInit(){
  if(NET.r){try{NET.r.leave();}catch(e){}}
  NET.r=makeLocalRoom();NET.role='guest';NET.side=1;NET.gotSetup=false;NET.myId=0;NET.inLobby=false;NET.lobby=[];audioInit();
  NET.r.on('setup',m=>{JOIN.on=false;clearTimeout(JOIN.tm);$('nstat').classList.add('hide');applySetup(m.data);});
  NET.r.on('welcome',m=>{const id=m.data&&+m.data.id;if(!(id>0))return;NET.myId=id;JOIN.on=false;clearTimeout(JOIN.tm);$('nstat').classList.add('hide');
    if(!NET.gotSetup){NET.inLobby=true;showLobby();}});
  NET.r.on('lobby',m=>{const l=m.data&&m.data.l;if(!Array.isArray(l))return;NET.lobby=l;NET.lobbyFull=!!(m.data&&m.data.full);if(NET.inLobby&&!NET.gotSetup)showLobby();});
  NET.r.on('fx',m=>{const l=(m.data&&m.data.l)||[];l.forEach(playFx);});
  NET.r.on('bye',()=>{if(NET.gotSetup||NET.inLobby)netLost();});
  NET.r.onPeers(ch=>{for(const p of NET.r.peers()){if(p.presence&&p.presence.h)NET.snap=p.presence.h;}
    if(ch.left.length){if(NET.gotSetup||NET.inLobby)netLost();else if(JOIN.ok){JOIN.ok=false;JOIN.busy=false;}}});
  const hi=()=>{if(NET.gotSetup||NET.myId||NET.role!=='guest'||!JOIN.ok)return;NET.r.emit('hello',{p:roster.net[0][0]});setTimeout(hi,800);};
  NETL.onOpen=()=>{JOIN.ok=true;JOIN.busy=false;netStat('Connected!','Starting the match…','ok');hi();};
  NETL.onError=e=>{if(!String(e).startsWith('discovery')){JOIN.busy=false;if(JOIN.pick){JOIN.pick=null;JOIN.found=[];}}};
  NETL.onFound=d=>{const [ip,nm]=String(d).split('|');if(!JOIN.found.some(h=>h.ip===ip)){JOIN.found.push({ip,name:(nm||'').slice(0,20)});if(JOIN.on&&!JOIN.ok&&!JOIN.busy)joinCycle(true);}};
}
function showHosts(){
  const box=$('nlist');box.innerHTML='';box.classList.remove('hide');
  JOIN.found.forEach(h=>{const b=document.createElement('button');b.className='nh';b.textContent='▶  '+(h.name?h.name+"'s game":'Game at '+h.ip);
    b.addEventListener('click',()=>{JOIN.pick=h.ip;box.classList.add('hide');netStat('Joining '+(h.name||'the game')+'…','');JOIN.busy=false;joinCycle(true);});box.appendChild(b);});
}
function joinCycle(fromFound){
  if(!JOIN.on||NET.gotSetup)return;
  const el=(Date.now()-JOIN.t0)/1000,go=l=>{JOIN.busy=true;try{if(AndroidNet.joinAny)AndroidNet.joinAny(l.join(','));else AndroidNet.join(l[0]);}catch(e){JOIN.busy=false;}};
  if(!fromFound){try{AndroidNet.discover();}catch(e){}}
  if(!JOIN.ok&&!JOIN.busy){
    const manual=($('ncode').value||'').trim(),man=/^\d{1,3}(\.\d{1,3}){3}$/.test(manual)?manual:'';
    if(JOIN.pick)go([JOIN.pick]);
    else if(JOIN.found.length>1){netStat('Choose a game','More than one phone is hosting here. Tap the player you want to play.');showHosts();}
    else if(el>=2.2&&JOIN.found.length===1){$('nlist').classList.add('hide');netStat('Joining '+(JOIN.found[0].name||'the game')+'…','');go([JOIN.found[0].ip]);}
    else if(el>=4){   // nobody heard (some hotspots block announcements): try the hotspot phone itself and the usual addresses
      let gw='';try{gw=AndroidNet.gateway?AndroidNet.gateway():'';}catch(e){}
      go([man,gw,'192.168.43.1','192.168.49.1','192.168.1.1'].filter((v,i,a)=>v&&a.indexOf(v)===i));
      if(el<14)netStat('Looking for the other phone…','Make sure the other phone tapped Host.');
      else{netStat('Still looking…','Check: 1) the other phone tapped Host  2) this phone is connected to its hotspot (or both are on the same Wi-Fi)  3) mobile data is off on this phone.');$('ncodebox').classList.remove('hide');}
    }else netStat('Looking for the other phone…','Make sure the other phone tapped Host.');
  }
  if(fromFound)return;clearTimeout(JOIN.tm);JOIN.tm=setTimeout(joinCycle,1500);
}
function appJoin(){
  netCancel();$('njoinbig').classList.add('on');appGuestInit();
  JOIN.on=true;JOIN.busy=false;JOIN.ok=false;JOIN.found=[];JOIN.pick=null;JOIN.t0=Date.now();joinCycle();
}
async function netHost(){
  if(APP){
    if(NET.r){try{NET.r.leave();}catch(e){}}
    try{if(AndroidNet.setName)AndroidNet.setName(roster.net[0][0].n);}catch(e){}
    const ips=AndroidNet.host();
    if(!ips||ips.startsWith('ERR')){netStat('Could not start hosting','Close the game completely and open it again. ('+(ips||'error')+')','bad');return;}
    $('nhost').classList.add('on');$('njoinbig').classList.remove('on');$('ncodebox').classList.add('hide');JOIN.on=false;clearTimeout(JOIN.tm);
    NET.r=makeLocalRoom();NET.role='host';NET.side=0;NET.started=false;NET.myId=0;NET.rx={};NET.addr=ips||'';
    try{AndroidNet.setMax(7);AndroidNet.setOpen(true);}catch(e){}
    const me=roster.net[0][0];NET.lobby=[{id:0,n:me.n,a:me.a,t:0}];NET.inLobby=true;$('nstat').classList.add('hide');showLobby();
    NET.r.on('hello',m=>{const id=m.from;if(!(id>0))return;const p=(m.data&&m.data.p)||{};
      if(NET.started){seatBack(id);return;}
      let e=NET.lobby.find(x=>x.id===id);
      if(!e){if(NET.lobby.length>=8){try{AndroidNet.kick(id);}catch(er){}return;}
        const c=[0,1].map(t=>NET.lobby.filter(x=>x.t===t).length);e={id,n:String(p.n||'Player').slice(0,14),a:(+p.a||0)%8,t:c[1]<=c[0]?1:0};
        if(c[e.t]>=4)e.t=1-e.t;NET.lobby.push(e);SFX0.tick();vib(15);}
      NET.r.emitTo(id,'welcome',{id});lobbyBroadcast();});
    NET.r.on('team',m=>{if(NET.started)return;const e=NET.lobby.find(x=>x.id===m.from);if(e)lobbyMove(e);});
    NET.r.on('in',m=>{const d=m.data||{};if(typeof d.k==='string'&&m.from>0)applyInput(d.k,d.v,m.from);});
    NET.r.on('bye',m=>{if(m.from>0){try{AndroidNet.kick(m.from);}catch(e){}}});
    NET.r.onLeft(id=>phoneLeft(id));
    return;
  }
  if(!roomNS){netStat('Not available here','Two-phone play in the browser needs internet and this game opened from Claude while signed in. In the installed app it works over a hotspot.','bad');return;}
  $('nhost').classList.add('on');$('njoinbig').classList.remove('on');$('ncodebox').classList.add('hide');
  const code=String(Math.floor(1000+Math.random()*9000));
  netStat('Opening a game…','');
  try{NET.r=await roomNS.join('gully-'+code);}catch(e){netStat('Could not open a game','Check the internet and try again. ('+(e&&e.code||'error')+')','bad');return;}
  NET.role='host';NET.side=0;NET.started=false;
  netStat(`Your code: ${code}`,`On the other phone: Phones → Join → type ${code}.`);
  NET.r.on('hello',m=>{if(m.sameTab)return;if(!NET.started){NET.started=true;cfg.mode='net';const me=roster.net[0][0],p=(m.data&&m.data.p)||{};
    NET.lobby=[{id:0,n:me.n,a:me.a,t:0},{id:1,n:String(p.n||'Player 2').slice(0,14),a:(+p.a||0)%8,t:1}];startGame();}else sendSetup();});
  NET.r.on('in',m=>{if(m.sameTab)return;const d=m.data||{};if(typeof d.k==='string')applyInput(d.k,d.v,1);});
  NET.r.onPeers(ch=>{if(NET.started&&ch.left.some(p=>!p.sameTab))banner('PLAYER LEFT','The other phone disconnected','#ffb347');});
}
function sendSetup(to){
  if(!NET.r||!game.sides.length)return;
  const d={target:game.target,scene:cfg.scene,mode:game.mode,sides:game.sides.map(s=>({name:s.name,players:s.players,looks:s.looks,avs:s.avs,own:s.own,cap:s.cap||0}))};
  if(to!==undefined&&NET.r.emitTo)NET.r.emitTo(to,'setup',d);else Promise.resolve(NET.r.emit('setup',d)).catch(()=>{});
}
async function netJoin(){
  if(APP){appJoin();return;}
  const code=($('ncode').value||'').replace(/\D/g,'');
  if(code.length!==4){netStat('Type the 4-digit code','It is shown on the host phone.','bad');return;}
  if(!roomNS){netStat('Not available here','Two-phone play in the browser needs internet and this game opened from Claude while signed in.','bad');return;}
  netStat('Joining…','');
  try{NET.r=await roomNS.join('gully-'+code);}catch(e){netStat('Could not join','Check the code and the internet. ('+(e&&e.code||'error')+')','bad');return;}
  NET.role='guest';NET.side=1;NET.gotSetup=false;NET.myId=1;audioInit();
  NET.r.on('setup',m=>{if(m.sameTab)return;$('nstat').classList.add('hide');applySetup(m.data);});
  NET.r.on('fx',m=>{if(m.sameTab)return;const l=(m.data&&m.data.l)||[];l.forEach(playFx);});
  const grab=()=>{for(const p of NET.r.peers()){if(!p.sameTab&&p.presence&&p.presence.h){NET.snap=p.presence.h;}}};
  NET.r.onPeers(ch=>{grab();if(NET.gotSetup&&ch.left.some(p=>!p.sameTab))banner('HOST LEFT','The other phone disconnected','#ffb347');});
  const hi=()=>{if(NET.gotSetup)return;NET.r.emit('hello',{p:roster.net[0][0]}).catch(()=>{});netStat('Waiting for the host…',`Code ${code}. Make sure the host phone shows the same code.`);setTimeout(hi,1200);};hi();
}
function applySetup(d){
  if(!d||!Array.isArray(d.sides)||d.sides.length!==2)return;
  NET.gotSetup=true;cfg.mode='net';game.target=+d.target||25;if(typeof d.scene==='string'&&(World.scenes.includes(d.scene)||d.scene==='hunza')){cfg.scene=d.scene;}ensureScene();game.mode='net';game.won=false;
  game.mode=d.mode==='team'?'team':'net';game.duel=null;game.round=null;game.winIdx=undefined;game.pk=null;NET.pkk='';
  game.sides=d.sides.map(x=>{const players=(x.players||[]).map(n=>String(n).slice(0,30));
    return{name:String(x.name||'').slice(0,20),players,looks:x.looks||[],avs:Array.isArray(x.avs)?x.avs:players.map(()=>0),own:Array.isArray(x.own)?x.own:null,cap:+x.cap||0,
      alive:players.map(()=>true),won:players.map(()=>false),pair:{},score:0,next:0};});
  for(const id of ['menu','over','mstart','settings','howto','roster','lobby','pick'])$(id).classList.add('hide');$('nstat').classList.add('hide');$('nlist').classList.add('hide');
  audioInit();loadVoice();loadDafoq();loadHit();loadThrow();loadSlam();
  NET.lost=false;NET.lastRx=performance.now();fielders=[];NET.fkey='';hud();
}
function playFx(o){
  if(!o||typeof o!=='object')return;
  if(o.b)banner(String(o.b[0]||''),String(o.b[1]||''),String(o.b[2]||'#fff'));
  if('p'in o)setPrompt(String(o.p||''));
  if(o.f)floatText(+o.f[0],+o.f[1],String(o.f[2]),String(o.f[3]),+o.f[4]||1);
  if(o.u)burst(+o.u[0],+o.u[1],Math.min(30,+o.u[2]||0),String(o.u[3]),+o.u[4]||1);
  if(o.s&&typeof SFX[o.s[0]]==='function'&&o.s[0]!=='__proto__')SFX[o.s[0]](o.s[1]);
}
const R3=v=>typeof v==='number'?Math.round(v*1000)/1000:v;
function snapshot(){
  return{S,sh:game.shot,tn:game.turn,sc:game.sides.map(x=>x.score),nx:game.sides.map(x=>x.next),w:game.won?1:0,
    g:[g.x,g.y,g.z||0,g.vx,g.vy,g.vz||0,g.rot,g.vr].map(R3).concat([(g.ground?1:0)|(g.rest?2:0)|(g.landed?4:0),g.held?fielders.indexOf(g.held):-1]),
    b:[R3(bat.a),R3(bat.c),['play','place','aside'].indexOf(bat.mode),R3(bat.pt),R3(bat.off),bat.placed?1:0,R3(bat.swu),bat.swMiss?1:0],
    d:[DD.x,DD.z,DD.y,DD.yaw].map(R3),
    f:fielders.map(f=>[f.x,f.v,f.face,f.run,f.ph%62.83,f.catchPose,f.wind,f.stun].map(R3)),
    sb:{st:sub.step,t:R3(sub.t),z:R3(sub.zLock),sw:sub.swung?1:0,n:sub.n,en:sub.ended?1:0,dd:sub.dead?1:0,j:sub.judged?1:0,ds:R3(sub.dist),rc:R3(sub.reach),
        th:sub.thrower?fielders.indexOf(sub.thrower):-1,am:sub.aim?1:0,la:sub.launched?1:0,ph:sub.phase,ca:sub.caller,cl:sub.call,re:sub.result,wi:sub.winner},
    J:[R3(JX),R3(JY)],ch:R3(cheer),ts:R3(ts),sk:R3(shake),fl:R3(flash),fs:fieldSecret?1:0,ce:game.celeb&&game.celeb.on?fielders.indexOf(game.celeb.f):-1,
    rx:['bat','field'].map(k=>react[k]?[react[k].type,R3(react[k].left),react[k].dur,react[k].idx]:0),
    ow:game.sides.map(s=>s.own||0),cp:game.sides.map(s=>s.cap||0),wi:game.winIdx===undefined?-1:game.winIdx,pk:S==='pick'&&game.pk?game.pk:0,
    tm:teamGame()?{al:game.sides.map(s=>(s.alive||[]).map(x=>x?1:0)),wn:game.sides.map(s=>(s.won||[]).map(x=>x?1:0)),du:game.duel?[game.duel.si,game.duel.b,game.duel.f]:0}:0};
}
function applySnapshot(sn){
  const prevS=S,prevPh=sub&&sub.phase;
  S=sn.S;game.turn=sn.tn|0;game.won=!!sn.w;if(game.shot!==sn.sh&&SHOTS[sn.sh])setShot(sn.sh);
  (sn.sc||[]).forEach((v,i)=>{if(game.sides[i])game.sides[i].score=v;});(sn.nx||[]).forEach((v,i)=>{if(game.sides[i])game.sides[i].next=v;});
  (sn.ow||[]).forEach((o,i)=>{if(game.sides[i]&&Array.isArray(o))game.sides[i].own=o;});(sn.cp||[]).forEach((c,i)=>{if(game.sides[i])game.sides[i].cap=c|0;});
  game.winIdx=sn.wi>=0?sn.wi:undefined;
  if(sn.tm){(sn.tm.al||[]).forEach((a,i)=>{if(game.sides[i])game.sides[i].alive=a.map(Boolean);});(sn.tm.wn||[]).forEach((a,i)=>{if(game.sides[i])game.sides[i].won=a.map(Boolean);});
    const d=sn.tm.du;game.duel=d?{si:d[0],b:d[1],f:d[2]}:null;}
  const pkk=JSON.stringify(sn.pk||0);if(pkk!==NET.pkk){NET.pkk=pkk;game.pk=sn.pk||null;if(S==='pick'&&prevS==='pick')renderPick();}
  const fk=(1-game.turn)+':'+(game.sides.length?fieldIdx(throwSide()).join(','):'');
  if(fielders.length!==(sn.f||[]).length||NET.fkey!==fk){fielders=[];placeFielders(true);NET.fkey=fk;}
  (sn.f||[]).forEach((a,i)=>{const f=fielders[i];if(f)[f.x,f.v,f.face,f.run,f.ph,f.catchPose,f.wind,f.stun]=a;});
  const a=sn.g;[g.x,g.y,g.z,g.vx,g.vy,g.vz,g.rot,g.vr]=a;g.ground=!!(a[8]&1);g.rest=!!(a[8]&2);g.landed=!!(a[8]&4);g.held=a[9]>=0?fielders[a[9]]||null:null;
  bat.a=sn.b[0];bat.c=sn.b[1];bat.mode=['play','place','aside'][sn.b[2]]||'play';bat.pt=sn.b[3];bat.off=sn.b[4];bat.placed=!!sn.b[5];bat.swu=sn.b[6]===undefined?-1:sn.b[6];bat.swMiss=!!sn.b[7];bat.q=[];bat.cur=null;
  [DD.x,DD.z,DD.y,DD.yaw]=sn.d;
  const q=sn.sb||{};sub={step:q.st,t:q.t,zLock:q.z,swung:!!q.sw,n:q.n,ended:!!q.en,dead:!!q.dd,judged:!!q.j,dist:q.ds,reach:q.rc,thrower:q.th>=0?fielders[q.th]:null,aim:q.am?{}:null,launched:!!q.la,phase:q.ph,caller:q.ca,call:q.cl,result:q.re,winner:q.wi};
  fieldSecret=!!sn.fs;game.celeb=sn.ce>=0&&fielders[sn.ce]?{f:fielders[sn.ce],on:true,t0:game.celeb?game.celeb.t0:T}:null;['bat','field'].forEach((k,i)=>{const r=sn.rx&&sn.rx[i];react[k]=r?{type:r[0],left:r[1],dur:r[2],idx:r[3]}:null;});
  [JX,JY]=sn.J;cheer=sn.ch;ts=sn.ts;shake=Math.max(shake,sn.sk);flash=Math.max(flash,sn.fl);
  if(S!==prevS||sub.phase!==prevPh)guestScreens(prevS);
  if(S==='jugready'||S==='juggle'){$('jug').classList.remove('hide');$('jn').textContent=sub.n||0;}else $('jug').classList.add('hide');
  if(S!=='ready')shotPicked=false;shotBar(S==='ready'&&myTurn());hud();
}
function guestScreens(prevS){
  if(S==='field'){if(prevS!=='field')openField();}else $('field').classList.add('hide');
  $('toss').classList.toggle('hide',S!=='toss');if(S==='toss')renderToss();
  if(S==='turn'){fillTurn();$('turn').classList.remove('hide');}else $('turn').classList.add('hide');
  if(S==='pick')renderPick();else $('pick').classList.add('hide');
  if(S==='over'){const w=game.sides[game.winIdx]||game.sides.find(x=>x.score>=game.target)||game.sides[0];fillOver(w);$('over').classList.remove('hide');}else $('over').classList.add('hide');
}
function guestStep(dt,rdt){
  tickReact(rdt);
  if(!g.held&&['pop','flight','throw','result','settle','over'].includes(S))stepG(g,dt);
  else if(S==='juggle'&&!sub.ended){g.vy-=GRAV*dt;g.y+=g.vy*dt;g.rot+=g.vr*dt;}
  for(const f of fielders){f.x+=(f.v||0)*dt;f.ph+=Math.abs(f.v||0)*dt*2*Math.PI/1.7;}
  if(typeof sub.t==='number')sub.t+=rdt;
  for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.vy-=9.8*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.y<0){p.y=0;p.vy*=-0.3;p.vx*=0.6;}p.life-=dt;if(p.life<=0)parts.splice(i,1);}
  for(let i=floats.length-1;i>=0;i--){floats[i].life-=rdt;if(floats[i].life<=0)floats.splice(i,1);}
  shake=Math.max(0,shake-rdt*40);flash=Math.max(0,flash-rdt*2.5);cheer=Math.max(0,cheer-rdt);
  updCam(rdt);
}
function netTick(now){
  if(NET.role!=='host'||!NET.r)return;
  if(now-NET.lastPres>55){NET.lastPres=now;if(game.sides.length)NET.r.presence({h:snapshot()}).catch(()=>{});}
  if(NET.q.length&&now-NET.lastFlush>120){NET.lastFlush=now;const l=NET.q.splice(0,24);NET.r.emit('fx',{l}).catch(()=>{});}
}

/* ---------- coin toss: one side calls, the winner chooses to bat or field ---------- */
let coinDeg=0;
function startToss(){
  S='toss';sub={phase:'call',caller:cfg.mode==='cpu'?0:1,call:null,result:null,winner:null,t:0};
  shotBar(false);setPrompt('');$('turn').classList.add('hide');renderToss();$('toss').classList.remove('hide');
}
function tossCall(c){
  if(S!=='toss'||sub.phase!=='call')return;
  sub.call=c;sub.result=Math.random()<0.5?'heads':'tails';sub.phase='flip';sub.t=0;SFX.whoosh();renderToss();
  later(2.0,()=>{if(S!=='toss')return;sub.winner=sub.call===sub.result?sub.caller:1-sub.caller;sub.phase='won';sub.t=0;SFX.coin();renderToss();});
}
function tossChoose(ch){
  if(S!=='toss'||sub.phase!=='won')return;
  game.turn=ch==='bat'?sub.winner:1-sub.winner;$('toss').classList.add('hide');
  banner(`${game.sides[sub.winner].name.toUpperCase()} WON THE TOSS`,ch==='bat'?'and chose to bat first':'and chose to field first','#ffd23f');
  showTurn();
}
function renderToss(){
  if(!game.sides.length)return;
  const nm=i=>game.sides[i]?game.sides[i].name:'',cpu=i=>capCPU(game.sides[i]);
  const canAct=i=>!cpu(i)&&(!NET.role||capOwner(game.sides[i])===ME());
  const B=$('tossB');B.innerHTML='';const btn=(lab,k,v)=>{const b=document.createElement('button');b.textContent=lab;b.addEventListener('click',()=>{audioInit();input(k,v);});B.appendChild(b);};
  const coin=$('coin');
  if(sub.phase==='call'){
    $('tossT').textContent=`${nm(sub.caller)}, call it!`;
    $('tossS').textContent=cpu(sub.caller)?'The computer is calling…':canAct(sub.caller)?'Heads or tails?':`Waiting for ${nm(sub.caller)} to call…`;
    if(canAct(sub.caller)){btn('Heads','call','heads');btn('Tails','call','tails');}
  }else if(sub.phase==='flip'){
    $('tossT').textContent='…';$('tossS').textContent=`${nm(sub.caller)} called ${sub.call}`;
    coinDeg+=360*6+(((sub.result==='tails'?180:0)-coinDeg%360)+360)%360;coin.style.transform=`rotateY(${coinDeg}deg)`;
    coin.classList.remove('up');void coin.offsetWidth;coin.classList.add('up');
  }else if(sub.phase==='won'){
    $('tossT').textContent=`${nm(sub.winner)} won the toss!`;
    $('tossS').textContent=`It's ${sub.result}. `+(cpu(sub.winner)?'The computer is choosing…':canAct(sub.winner)?'Bat or field first?':`Waiting for ${nm(sub.winner)} to choose…`);
    if(canAct(sub.winner)){btn('🏏 Bat first','choose','bat');btn('🧤 Field first','choose','field');}
  }
}

/* ---------- flow ---------- */
function sceneReset(){
  Object.assign(g,{bv:0.3,bx:0.55,x:GREST.x,y:GREST.y,z:0,vx:0,vy:0,vz:0,rot:GREST.rot,vr:0,ground:true,rest:true,landed:false,held:null,noDrag:false});g.trail.length=0;
  Object.assign(bat,{mode:'play',pt:0,placed:false,jolt:0,a:A0+0.06,c:1,off:0,swu:-1,swing:null});resetDanda();bat.q=[];bat.cur=null;
}
function resetBall(){game.celeb=null;shotPicked=false;
  sceneReset();placeFielders(false);fieldSecret=!!game.fieldHide;S='ready';sub={t:0};$('jug').classList.add('hide');
  if(batCPU()){shotBar(false);setPrompt('');}
  else{setPrompt(onDafoq(curSide())?'DAFOQ · survive this shot to win':'');shotBar(myTurn());}
  if(onDafoq(curSide()))floatText(0.5,2.6,'DAFOQ!','#ffd23f',1.3);
  hud();
}
function startGame(){
  if(builtScene!==cfg.scene){ensureScene(startGame);return;}
  paused=false;$('pause').classList.add('hide');
  audioInit();loadVoice();loadDafoq();loadHit();loadThrow();loadSlam();game.target=cfg.target;game.mode=cfg.mode;game.sides=mkSides();if(cfg.mode==='net'&&game.sides[0].players.length>1)game.mode='team';game.winIdx=undefined;game.pk=null;game.turn=0;game.balls=0;game.won=false;game.longest=0;game.hLand=[];game.bestBounce=0;game.duel=null;game.round=null;game.taunt=null;$('pick').classList.add('hide');
  fielders=[];placeFielders(true);timers=[];parts=[];floats=[];
  $('menu').classList.add('hide');$('mstart').classList.add('hide');$('over').classList.add('hide');cam.x=0.5;cam.ppm=basePPM;sceneReset();hud();startToss();
  if(NET.role==='host'){$('lobby').classList.add('hide');sendSetup();}
}
function showTurn(){
  if(teamGame()&&onDafoq(curSide())&&!game.duel&&!game.won){sceneReset();fielders=[];placeFielders(true);startDafoqRound();return;}
  sceneReset();fielders=[];
  const fs=game.sides[fieldSide()];game.field=null;game.fieldHide=false;fieldSecret=false;
  if(fs&&capCPU(fs)){game.field={si:fieldSide(),homes:cpuField(fieldIdx(fs).length)};game.fieldHide=true;fieldSecret=true;}
  placeFielders(true);shotBar(false);setPrompt('');$('jug').classList.add('hide');
  if(fs&&!capCPU(fs)){const n=fielders.length,mem=game.fieldMem&&game.fieldMem[fieldSide()];
    const homes=mem&&mem.length===n?mem.slice():presetField('spread',n);game.field={si:fieldSide(),homes};
    fielders.forEach((f,i)=>{f.home=f.x=f.target=homes[i];});game.fieldHide=true;fieldSecret=true;}
  S='turn';sub={};hud();
  fillTurn();$('turn').classList.remove('hide');
}
function fillTurn(){
  const s=curSide(),need=Math.max(0,game.target-s.score),bc=batCPU(),mine=!NET.role?true:!bc&&ownerOf(s,s.next)===ME();
  $('tn').textContent=curName();
  $('ts2').textContent=(bc&&!NET.role?'The computer bats now':cfg.mode==='cpu'?'Your turn to bat':NET.role?(mine?'Your turn to bat':bc?`The computer plays for ${curName()}`:`${curName()} is batting`):'Pass the phone · your turn to bat')+(onDafoq(s)?' · DAFOQ: survive one shot to win':` · needs ${need} more, then the Dafoq`);
  $('tboard').innerHTML=boardHTML();$('tgo').textContent=bc&&!NET.role?'WATCH ▶':mine?'BAT ▶':bc?'Starting…':`Waiting for ${curName()}…`;$('tgo').disabled=!mine;
}
function beginTurn(){if(S!=='turn')return;$('turn').classList.add('hide');audioInit();setShot('loft');resetBall();}   // every turn starts on Hawai
function batsmanOut(title,why,runOut){
  if(game.won)return;game.celeb=null;
  if(teamGame()&&!game.duel){const cs=curSide();(cs.outNow=cs.outNow||[]).push(cs.next);}   // out in this turn: no Dafoq until the other team has had its turn
  const who=g.held?fielders.indexOf(g.held):(sub&&sub.thrower)?fielders.indexOf(sub.thrower):-1;
  setReact('bat',rx('sad'),2.3);setReact('field',rx('win'),2.3,who);cheer=Math.max(cheer,1.2);
  let wait=2.3;if(/^KHALI/.test(title)&&Math.random()<0.65&&slamDanda())wait=4;
  if(who>=0)floatText(fielders[who].x,2.5,pick(['SHABASH!','YESS!','OUT HAI!']),'#ffd23f',1.1);
  S='result';setPrompt('');shotBar(false);$('jug').classList.add('hide');
  banner(title,why,'#ff5a5f');setTimeout(()=>SFX.out(),120);vib([60,40,60]);shake=Math.max(shake,8);
  if(runOut&&who>=0){   // thrown out: the thrower gets his moment
    const f=fielders[who],L=4.4;game.celeb={f,t0:T,on:false};setReact('bat',rx('sad'),L);
    later(0.85,()=>{const c=game.celeb;if(!c||S!=='result')return;c.on=true;f.react=0;f.stun=0;f.wind=0;f.spd=6.5;f.target=f.x-Math.min(9,Math.max(3,f.x*0.25));
      setReact('field',rx('celeb'),L-0.85,who);cheer=Math.max(cheer,2.5);SFX.cheer();vib(30);
      floatText(f.x,2.7,pick(['UDA DIYA!','BULLSEYE!','SEEDHA NISHANA!','SHABASH!']),'#ffd23f',1.4);
      fielders.forEach((o,i)=>{if(o!==f){o.react=0;o.stun=0;o.spd=5;o.target=f.target+(o.x>f.target?1.3:-1.3)*(1+i*0.3);}});
      later(1.4,()=>{if(game.celeb===c&&S==='result'){burst(f.x,1.9,24,'#ffd23f',4);SFX.coin();}});});
    later(L,()=>{game.celeb=null;nextBatter();});return;
  }
  later(wait,nextBatter);
}
function nextBatter(){
  if(game.won)return;if(game.duel){afterDuel(false);return;}
  const s=curSide(),al=aliveIdx(s),k=al.indexOf(s.next);
  if(k<0||k>=al.length-1){s.outNow=[];game.turn=(game.turn+1)%game.sides.length;const o=curSide();o.outNow=[];o.next=aliveIdx(o)[0]||0;}else s.next=al[k+1];
  showTurn();
}
/* ---------- team Dafoq ----------
   When a team has reached the target, every living player of it takes a Dafoq, one by one. The captain picks who
   goes next; that batsman picks ONE fielder from the other team. Batsman survives -> that fielder is out of the
   match. Batsman out -> nobody is lost. After the round the other team's living players bat as usual (and may earn
   their own Dafoqs); then the Dafoqs are taken again. A team with no players left loses. */
const teamGame=()=>game.mode==='team';
const capName=s=>s.players[s.cap||0];
function startDafoqRound(){const s=curSide();game.round={si:game.turn,done:(s.outNow||[]).slice()};s.outNow=[];game.duel=null;pickBatter();}
function pickBatter(){
  const s=game.sides[game.round.si],left=aliveIdx(s).filter(i=>!game.round.done.includes(i));
  if(!left.length){endDafoqRound();return;}
  openPick(`${s.name} · DAFOQ`,`Captain ${capName(s)}: who takes the Dafoq?`,s,game.round.si,left,i=>{game.round.b=i;pickFielder();},capOwner(s));
}
function startDuel(f){
  const s=game.sides[game.round.si];s.pair[game.round.b]=f;
  game.duel={si:game.round.si,b:game.round.b,f};game.turn=game.round.si;s.next=game.round.b;$('pick').classList.add('hide');showTurn();
}
function pickFielder(){
  const s=game.sides[game.round.si],o=game.sides[1-game.round.si],b=game.round.b,keep=s.pair[b];
  // his Dafoq opponent stays the same for the whole match (unless that fielder has since left the game)
  if(keep!==undefined&&aliveIdx(o).includes(keep)){startDuel(keep);return;}
  openPick(`${s.players[b]} · DAFOQ`,`${s.players[b]}: choose ONE fielder from ${o.name}`,o,1-game.round.si,aliveIdx(o),startDuel,ownerOf(s,b));
}
function openPick(title,subt,side,si,list,cb,by){
  S='pick';sub={t:0};shotBar(false);setPrompt('');
  game.pickBy=by===undefined?ME():by;game.pk=[title,subt,si,list.slice(),game.pickBy];
  pickCb=cb;pickList=list;renderPick();hud();
  if(game.pickBy==='cpu')later(rnd(1.2,2),cpuPick);
}
function cpuPick(){if(S==='pick'&&game.pickBy==='cpu'&&pickCb&&pickList.length){const cb=pickCb;pickCb=null;cb(pick(pickList));}}
/* the pick screen (Dafoq batsman / fielder): only the phone whose choice it is gets buttons */
function renderPick(){
  const P=game.pk;if(!P)return;const [title,subt,si,list,by]=P,side=game.sides[si];if(!side)return;
  const can=by!=='cpu'&&(!NET.role||by===ME());
  $('pkh').textContent=title;$('pks').textContent=can||!NET.role?subt:by==='cpu'?'The computer is choosing…':subt.replace(/:.*/,'')+' is choosing…';
  const box=$('pkl');box.innerHTML='';
  list.forEach(i=>{const b=document.createElement('button');b.className='pk';b.disabled=!can;if(!can)b.style.opacity='.75';b.innerHTML=avatarSVG(side.avs?side.avs[i]:0,lookColors(si,i,side.looks[i]).kam);const sp=document.createElement('span');sp.textContent=side.players[i]+(i===(side.cap||0)?' ★':'');b.appendChild(sp);b.addEventListener('click',()=>{if(!can)return;SFX0.tick();input('pick',i);});box.appendChild(b);});
  $('pick').classList.remove('hide');
}
let pickCb=null,pickList=[];
function teamOver(){return !aliveIdx(game.sides[0]).length||!aliveIdx(game.sides[1]).length;}
/* the match ends when a team has nobody left to play: the team with more Dafoq winners wins
   (tie: fewer players put out, then the higher score) */
function finishTeam(){
  const [a,b]=game.sides,key=s=>winners(s)*10000+s.alive.filter(Boolean).length*100+Math.min(99,s.score/100);
  winMatch(key(a)>=key(b)?a:b);
}
function afterDuel(survived){
  const d=game.duel;if(!d)return;const s=game.sides[d.si],o=game.sides[1-d.si];
  game.duel=null;game.round.done.push(d.b);
  if(survived){o.alive[d.f]=false;s.won[d.b]=true;}   // the fielder is out; the batsman has won his Dafoq and sits out as a winner
  if(teamOver()){finishTeam();return;}
  pickBatter();
}
function endDafoqRound(){
  const si=game.round.si;game.round=null;game.duel=null;game.turn=1-si;const o=curSide();o.outNow=[];o.next=aliveIdx(o)[0]||0;showTurn();
}
/* Reaching the target is not the win. The side must then play one more shot, the DAFOQ: if the batsman
   is not out on it (no miss, no catch, the throw misses the danda) his side wins. If he is out, the other
   side bats on, and the Dafoq is tried again on the next turn. */
const onDafoq=s=>!!s&&s.score>=game.target;
function winMatch(s){
  if(game.won)return;game.won=true;game.winIdx=game.sides.indexOf(s);S='result';shotBar(false);setPrompt('');cheer=7;SFX.cheer();setReact('bat','win',7);setReact('field','sad',7);game.taunt=null;later(2.5,()=>SFX.cheer());
  banner(s.cpu&&!NET.role?'COMPUTER WINS':'JEET GAYE!',teamGame()?`${s.name} win · ${winners(s)} Dafoq winner${winners(s)===1?'':'s'} to ${winners(game.sides[1-game.sides.indexOf(s)])}`:`${s.name} survived the Dafoq`,'#ffd23f');later(6.2,()=>gameOver(s));
}
function addScore(n){
  const s=curSide(),was=onDafoq(s);s.score+=n;hud();
  if(!was&&onDafoq(s)&&!game.won){sub.hitTarget=true;cheer=2;SFX.cheer();floatText(JX,JY+1.5,'TARGET!','#ffd23f',1.5);}
  return false;
}
/* target reached and the counting is over: the batsman celebrates, a fielder storms up to him and they have a
   playful face-off, then the Dafoq is played */
function startTaunt(){
  if(game.won)return;S='result';shotBar(false);setPrompt('');$('jug').classList.add('hide');
  const f=fielders.slice().sort((a,b)=>a.x-b.x)[0];game.taunt={t:0,f:f||null,said:0};
  cheer=3;SFX.cheer();setReact('bat','win',1.5);banner('TARGET!',`${curSide().name} · the DAFOQ is next`,'#ffd23f');
}
function tickTaunt(rdt){
  if(game.won&&react.bat&&react.bat.type==='win'){bat.wt=(bat.wt||0)+rdt;bat.run=2.6*Math.sin(bat.wt*1.15);bat.runV=Math.cos(bat.wt*1.15);}else{bat.run=(bat.run||0)*Math.max(0,1-rdt*6);bat.runV=0;bat.wt=0;}
  const tn=game.taunt;if(!tn)return;tn.t+=rdt;const f=tn.f;
  if(f){const goal=1.7,d=goal-f.x;f.face=-1;if(Math.abs(d)>0.08&&tn.t<3){const v=Math.sign(d)*Math.min(7,Math.abs(d)*4+1.5);f.x+=v*rdt;f.v=v;f.run=Math.min(1,Math.abs(v)/5);f.ph+=rdt*11;}else{f.v=0;f.run=Math.max(0,f.run-rdt*5);}}
  if(tn.t>1.5&&tn.said<1){tn.said=1;setReact('bat','taunt',3.4);floatText(0.2,2.5,pick(['AB DAFOQ!','AA JA!','DEKH LE!']),'#ffd23f',1.2);SFX.dafoqCall();}
  if(tn.t>(dafoqBuf&&countOn&&!muted?4.3:2.4)&&tn.said<2){tn.said=2;if(f){setReact('field','taunt',2.4,fielders.indexOf(f));floatText(f.x+0.2,2.5,pick(['DEKH LENGE!','OUT KARUNGA!','CHAL CHAL!']),'#ffffff',1.2);}SFX.aww();}
  if(tn.t>(dafoqBuf&&countOn&&!muted?6.4:4.9)){game.taunt=null;react.bat=react.field=null;if(teamGame())startDafoqRound();else resetBall();}
}
function action(){if(paused)return;if(S==='aim'){if(!throwerCPU())aimTap();return;}if(isCPU())return;if(S==='ready')flip();else if(S==='pop')strike();else if(S==='jugready')juggleStart();else if(S==='juggle')juggleTap();}

function flip(){
  S='tap';sub={t:0,hitDone:false,launched:false};game.balls++;shotBar(false);setPrompt('');
  bat.q=[[A0+0.7,0.13,1],[A0-0.02,0.05,1]];bat.cur=null;
}
function tapImpact(){SFX.tick();vib(12);burst(TIP0[0],TIP0[1],7,'#c9a06a',1.4);shake=Math.max(shake,2);}
function launchPop(){
  S='pop';sub={swung:false};if(!batCPU())setPrompt('');
  bat.q=[[A0+0.25,0.07,1],[2.1,0.32,0]];bat.cur=null;
  Object.assign(g,{rest:false,ground:false,landed:false,vx:rnd(0.25,0.55),vy:rnd(5.0,6.6),vz:SWZ/0.95,vr:-rnd(18,30)});   // every tap is a little different
}
/* swing timing (real time): from wherever he is loaded to contact, then the follow-through, a moment held at the finish */
const vpitch=s=>{let h=0;for(const ch of String(s||''))h=(h*31+ch.charCodeAt(0))|0;return 108+Math.abs(h)%46;};   // each player keeps his own voice
const batVoice=()=>vpitch(typeof curName==='function'?curName():'bat'),fieldVoice=f=>vpitch('f'+(f&&f.i!==undefined?f.i:0)+(game.turn|0));
function swingAnim(){SFX.shoutHit(batVoice());bat.a=Math.min(bat.a,0.9);bat.c=0;bat.q=[[0.05,0.035,0],[-1.0,0.11,0],[-0.6,0.3,0]];bat.cur=null;bat.swing={from:Math.max(0,bat.swu),t:0,tc:0.075,tf:0.34};bat.swMiss=false;}
function missSwing(){SFX.gruntMiss(batVoice());bat.a=Math.min(bat.a,1.2);bat.c=0;bat.q=[[0.1,0.06,0],[-1.35,0.17,0],[-1.0,0.35,0],[-0.7,0.5,0]];bat.cur=null;bat.swing={from:Math.max(0,bat.swu),t:0,tc:0.12,tf:0.42};bat.swMiss=true;}
function tickSwing(rdt){
  const sw=bat.swing;
  if(sw){sw.t+=rdt;bat.swu=sw.t<sw.tc?lerp(sw.from,0.5,sw.t/sw.tc):Math.min(1,0.5+0.5*(sw.t-sw.tc)/sw.tf);if(sw.t>sw.tc+sw.tf+0.4){bat.swing=null;bat.swu=-1;}return;}
  // while the gilli is up, he draws the danda back and loads, ready to swing
  if(S==='pop'&&!sub.swung&&bat.mode==='play'&&!bat.q.length&&bat.c<0.05)bat.swu=Math.min(0.24,Math.max(0,bat.swu)+rdt*0.55);
  else bat.swu=-1;
}
function strike(){
  if(sub.swung)return;sub.swung=true;revealField();
  const d=Math.hypot((g.x-RING.x)*0.8,g.y-RING.y);
  if(g.y<0.1||d>0.4+lagSlack(Math.hypot(g.vx,g.vy))){
    // a full swing that whiffs: the gilli keeps falling past the danda, then the out is called
    missSwing();SFX.whoosh();vib(15);S='result';setPrompt('');sub.missed=true;
    
    later(0.6,()=>{if(S==='result'&&!game.won)batsmanOut('KHALI! OUT','Missed the shot');});return;
  }
  swingAnim();
  hit(clamp(1-d/0.4,0,1));
}
function hit(q){
  const sh=SHOTS[game.shot];const perfect=q>=0.84;const dyHit=g.y-RING.y;let label,col;
  if(perfect){label=pick(['KAMAAL!','PERFECT!','ZABARDAST!']);col='#ffd23f';}
  else if(q>=0.58){label=pick(['SHABASH!','GREAT HIT!','WAH!']);col='#7ef29a';}
  else if(q>=0.32){label=pick(['THEEK HAI','GOOD']);col='#bfe3ff';}else{label='KINARA!';col='#ff9f6b';}
  // danda swings at ~26 rad/s; speed at the contact point × (1+e) gives the gilli's exit speed
  const omega=33,rc=0.36+0.34*q,v=1.45*omega*rc+(perfect?2.5:0);
  let ang=sh.ang+clamp(dyHit*0.9,-0.3,0.3)+rnd(-0.03,0.03);   // met it high = under the gilli = more loft
  let vv=v;const edge=q<0.32;if(edge){vv*=0.6;ang=game.shot==='ground'?-0.4:rnd(1.0,1.2);}
  Object.assign(g,{vx:vv*Math.cos(ang),vy:vv*Math.sin(ang),z:SWZ,vz:0,vr:(ang>0.3?1:-1)*rnd(25,45),ground:false,rest:false,landed:false});
  sub={q,perfect,edge,ft:0};S='flight';setPrompt('');
  hitStop=perfect?0.13:0.05;shake=perfect?14:8;flash=perfect?0.5:0.25;
  SFX.crack(q);vib(perfect?[30,40,30]:25);
  banner(label,edge?'Top edge — skied it!':sh.name+' shot',col);
  burst(g.x,g.y,perfect?26:14,'#e7c58f',6);burst(g.x,g.y,8,'#ffffff',4);
  const bid=game.balls;later(0.6,()=>{if(game.balls===bid&&bat.mode==='play'&&(S==='flight'||S==='settle'||S==='fetch')){bat.mode='place';bat.pt=0;}});
  const pr=predict();
  fielders.forEach(f=>{f.tried=f.tried2=false;f.stun=0;f.wind=0;f.react=rnd(0.35,0.5);f.spd=rnd(4.8,5.8);
    if(game.shot==='ground'&&!edge)f.target=f.x<pr.rest?f.x:pr.rest;else f.target=pr.land-0.3;});
}
function tryCatch(f){
  const sp=Math.hypot(g.vx,g.vy),fsd=game.sides[fieldSide()],cb=fsd&&pcpu(fsd,f.pi)?LV().catch:0;const p=clamp(0.5-sp/120+(sub.edge?0.2:0)+cb,0.15,0.9);f.catchPose=1;
  if(Math.random()<p){g.held=f;g.vx=g.vy=0;fielders.forEach(o=>{o.target=o.x;});SFX.thud();batsmanOut('CATCH! OUT',pick(['Pakar liya!','Haath mein aa gayi!','Gaya bhai!']));}
  else{f.stun=1.0;g.vx*=0.45;g.vy=Math.abs(g.vy)*0.25+2;floatText(f.x,2.6,'DROPPED!','#ffd23f',1.2);SFX.aww();cheer=1.4;setReact('field',rx('annoyed'),1.6,fielders.indexOf(f));setReact('bat','fist',1.4);}
}
function settle(){
  S='settle';const dist=Math.max(0,g.x);game.longest=Math.max(game.longest||0,dist);if(!batCPU())(game.hLand=game.hLand||[]).push(dist);
  floatText(g.x,2.2,Math.round(dist)+' m','#ffffff',1.2);
  if(dist>=55){banner(pick(['BOHAT DOOR!','WHAT A SHOT!']),'','#ffd23f');cheer=2.6;SFX.cheer();setReact('bat',rx('shot'),2.4);setReact('field',rx('annoyed'),2.4);floatText(0,2.5,'WAAH!','#ffd23f',1.2);}
  else if(dist>=35){cheer=1.6;setReact('bat',pick(['fist','fist','clap','point']),1.8);setReact('field',pick(['hips','hips','facepalm']),1.6);floatText(0,2.4,pick(['ACHA SHOT!','WAH!']),'#7ef29a',1);}
  later(1.0,startThrow);
}
function startThrow(){
  if(S!=='settle')return;let bf=null,bd=1e9;
  fielders.forEach(f=>{const d=Math.abs(f.x-g.x);if(d<bd){bd=d;bf=f;}});
  fielders.forEach(f=>{f.target=f===bf?g.x+0.3:f.x;f.spd=f===bf?7.5:3;f.react=0;f.stun=0;});
  if(bat.mode==='play'){bat.mode='place';bat.pt=0;}
  S='fetch';sub={thrower:bf,wind:0};setPrompt('');
}
function throwBody(x0,v,zd,th=0.28){const vx=-v*Math.cos(th);return{x:x0,y:1.6,z:0,vx,vy:v*Math.sin(th),vz:zd*v*Math.cos(th)/Math.max(1,x0),rot:0.5,vr:-14,ground:false,rest:false,landed:false,held:null};}
function throwRest(x0,v){const c=throwBody(x0,v,0);let t=0;while(!c.rest&&t<12){stepG(c,1/60);t+=1/60;}return c.x;}
const MAXV=32;
function solveThrow(x0,r){let lo=2,hi=MAXV;for(let i=0;i<16;i++){const m=(lo+hi)/2;if(throwRest(x0,m)>r)lo=m;else hi=m;}return(lo+hi)/2;}
function doThrow(f,aim){SFX.shoutThrow(fieldVoice(f));
  if(!bat.placed){bat.placed=true;bat.mode='aside';bat.pt=1;bat.off=-0.6;}
  // the farther the throw, the less accurate it is
  const x0=f.x-0.3,dist=Math.max(0,x0),k=Math.max(0.3,dist/20);
  let r,zd;
  const kk=Math.max(0.15,dist/15);   // hand error grows with distance
  // a good throw is aimed to carry through the danda with pace (aim point beyond it); too little power stops short
  // power tap = where you aim the gilli to skid to: right of the green zone stops short, the green zone carries through the danda
  if(aim){const pr=aim.r>0.13?aim.r:-1-(0.13-aim.r)*2.5;r=pr+gauss()*0.12*Math.min(kk,2.5);zd=aim.z+gauss()*0.04*Math.min(kk,2.5);Object.assign(g,throwBody(x0,solveThrow(x0,r),zd),{held:null});}
  else{const tk=LV().throwK;r=-1.8+gauss()*(0.3+dist*0.03)*tk;zd=gauss()*(0.08+dist*0.012)*tk;Object.assign(g,throwBody(x0,solveThrow(x0,r),zd),{held:null});}
  g.trail.length=0;S='throw';sub={t0:T,thrower:f,judged:false,px:x0,pz:0,ghost:[]};f.wind=-1;SFX.whoosh();
  setPrompt('');
}
/* the fielding side throws: two taps — AIM (side to side), then POWER (how far along the line) */
const AIMP=()=>clamp(2.9-sub.dist*0.035,1.4,2.9);   // rings move a bit faster on long throws
const aimZ=()=>Math.sin(Math.max(0,sub.t)*2*Math.PI/AIMP())*0.9;
const aimX=()=>0.6+Math.sin(Math.max(0,sub.t)*2*Math.PI/(AIMP()*1.15))*1.8;   // sweeps -1.2 … 2.4 m around the danda
function enterAim(f){
  if(!bat.placed){bat.placed=true;bat.mode='aside';bat.pt=1;bat.off=-0.6;}
  const x0=Math.max(0,f.x-0.3);
  S='aim';sub={thrower:f,step:0,t:-0.8,dist:x0,zLock:0,reach:throwRest(x0,MAXV)};f.wind=0.6;
  setPrompt(`Throw from ${Math.round(x0)} m`);
}
function aimTap(){
  if(sub.t<0)return;
  if(sub.step===0){sub.zLock=aimZ();sub.step=1;sub.t=0;SFX.tick();vib(10);setPrompt(sub.reach>0.13?`Out of range · a full throw stops ${sub.reach.toFixed(1)} m short`:'');}
  else{const f=sub.thrower,aim={r:aimX(),z:sub.zLock};SFX.tick();vib(10);setPrompt('');S='fetch';sub={thrower:f,wind:0.8,w0:0.8,aim};cam.x=f.x-f.face*1.2;cam.ppm=basePPM*0.85;}
}
function dandaHit(t){
  sub.judged=true;
  // impulse between a 70 g gilli and a 0.35 kg danda (e = 0.4). The contact point's offset from the danda's
  // centre turns part of the impulse into spin: 1/m_eff = 1/m + r²/I, with I = mL²/12.
  const mg=0.07,e=0.4,r=(t-0.5)*DD.L,I=DD.m*DD.L*DD.L/12;
  const nx=Math.cos(DD.yaw),nz=-Math.sin(DD.yaw);                    // normal to the danda in the ground plane
  let vn=g.vx*nx+g.vz*nz;const sgn=vn<0?-1:1;vn=Math.abs(vn);
  const J=(1+e)*vn/(1/mg+1/DD.m+r*r/I);
  DD.vx+=sgn*J*nx/DD.m;DD.vz+=sgn*J*nz/DD.m;DD.w+=sgn*r*J/I;   /* torque about the vertical axis = r x F: the end that is struck moves away with the gilli, the far end swings back */DD.vy=Math.min(1.4,0.12*Math.hypot(g.vx,g.vz)+0.3*Math.max(0,-g.vy));
  g.vx-=sgn*J*nx/mg;g.vz-=sgn*J*nz/mg;g.ground=false;g.rest=false;g.vy=Math.max(0.6,Math.abs(g.vy)*0.4+0.5);g.vr=-g.vr*0.5+rnd(-20,20);
  bat.jolt=0;tone(820,0.08,'triangle',0.3,500);noise(0.08,'bandpass',1500,1.5,0.4);burst(0,0.05,12,'#c9a06a',2.5);
  batsmanOut('OUT!','The gilli hit the danda',S==='throw');
}
function throwSafe(){
  sub.judged=true;S='result';setPrompt('');setReact('bat',pick(['fist','clap','beat']),1.5);setReact('field',rx('annoyed'),1.5,fielders.indexOf(sub.thrower));
  if(game.duel){const o=game.sides[1-game.duel.si],nm=o.players[game.duel.f];banner('DAFOQ!',`${curName()} wins his Dafoq · ${nm} is out`,'#ffd23f');SFX.cheer();cheer=2.5;later(2.6,()=>{if(!game.won)afterDuel(true);});return;}
  if(onDafoq(curSide())){winMatch(curSide());return;}
  banner('BACH GAYE!','','#7ef29a');SFX.coin();
  later(1.6,()=>{if(S==='result'&&!game.won)startJuggle();});
}
/* ---------- scoring: bounce the gilli on the danda, one point per bounce ---------- */
let JX=0.23,JY=1.11;
function startJuggle(){
  Object.assign(bat,{mode:'play',placed:false,off:0,c:0,a:0,pt:0,swu:-1,swing:null});bat.q=[];bat.cur=null;
  const P=batPose();JX=BX+P.grip[0]+0.42;JY=P.grip[1]+0.035;
  S='jugready';sub={n:0,dead:false,ended:false,drift:0,cpuAt:undefined,t:0};
  Object.assign(g,{x:JX,y:JY,z:SWZ,vx:0,vy:0,vz:0,vr:0,rot:0,ground:false,rest:false,landed:false,held:null,noDrag:true,bv:0.3,bx:0.55,fric:10});
  g.trail.length=0;fielders.forEach(f=>{f.target=f.home;f.spd=3;});
  $('jn').textContent='0';$('jug').classList.remove('hide');
  setPrompt(batCPU()?'':'TAP to start bouncing');
}
function juggleStart(){
  if(S!=='jugready')return;S='juggle';g.vy=3.8;g.vr=12;bat.q=[[0.3,0.05,0],[0,0.13,0]];bat.cur=null;SFX.tick();
  sub.n=1;$('jn').textContent=1;SFX.count(1);tone(700,0.06,'triangle',0.22);floatText(JX+0.3,JY+0.4,'+1','#ffd23f',0.8);addScore(1);
  setPrompt('');
}
/* On a slow phone the picture moves in jumps, so the moment to tap can fall between two frames. The game forgives
   by the distance the gilli travels in one frame beyond a smooth 60 fps (fast phones: no change at all). */
let FT=1/60;
const lagSlack=v=>Math.min(0.09,Math.max(0,FT-1/60)*Math.abs(v)*0.6);
const jugWin=()=>Math.max(0.08,0.45-Math.max(0,sub.n-2)*0.04);   // easy for 2 bounces, then tighter every bounce
function juggleTap(){
  if(S!=='juggle'||sub.ended||sub.dead)return;
  bat.q=[[0.3,0.05,0],[0,0.13,0]];bat.cur=null;
  const h=g.y-JY;
  const sl=lagSlack(g.vy);
  if(g.vy<0&&h>=-0.12-sl&&h<=jugWin()+sl*0.5){
    sub.n++;$('jn').textContent=sub.n;SFX.count(sub.n);
    const sp=Math.min(1,Math.max(0,sub.n-2)*0.08);g.y=JY+0.01;g.vy=rnd(3.7-sp*0.9,3.9+sp*1.3);g.vr=rnd(10,16+sp*20)*(Math.random()<.5?-1:1);sub.drift=rnd(-0.02-sp*0.12,0.02+sp*0.12);sub.cpuAt=undefined;
    tone(700+Math.min(sub.n,20)*25,0.06,'triangle',0.22);noise(0.03,'bandpass',2200,2,0.15);
    floatText(JX+0.3,JY+0.4,'+1','#ffd23f',0.8);burst(JX,JY,4,'#e7c58f',1.2);
    $('jug').classList.remove('pulse');void $('jug').offsetWidth;$('jug').classList.add('pulse');
    addScore(1);
  }else{sub.dead=true;SFX.whoosh();}
}
/* frustration: he lifts the danda over his head and throws it into the dirt; it bounces and skids */
function slamDanda(){
  if(bat.mode!=='play'||bat.placed)return false;setReact('bat','slam',3.4);const said=!!slamBuf&&!muted;SFX.slamVoice();
  later(0.95,()=>{if(!react.bat||react.bat.type!=='slam'||bat.placed)return;
    Object.assign(bat,{mode:'aside',placed:true,pt:1,swu:-1,swing:null});bat.q=[];bat.cur=null;
    Object.assign(DD,{x:BX+0.5,z:BZ+0.3,y:0.45,vy:-2.4,vx:rnd(1.1,1.6),vz:rnd(-0.25,0.25),w:rnd(4,7)*(Math.random()<.5?-1:1),yaw:rnd(0.6,1.2)});
    if(!said)SFX.shoutSlam(batVoice());SFX.thud();noise(0.12,'bandpass',600,1,0.5);burst(BX+0.7,0.05,14,'#c9a06a',2);shake=Math.max(shake,4);vib(40);});
  return true;
}
function endJuggle(){
  sub.ended=true;Object.assign(g,{noDrag:false,landed:false,ground:false,rest:false});
  const n=sub.n;game.bestBounce=Math.max(game.bestBounce||0,n);banner(n>0?`${n} BOUNCE${n>1?'S':''}!`:'NO BOUNCES',`+${n} for ${curSide().name}`,n>=8?'#ffd23f':'#7ef29a');
  if(n>=8){cheer=2;SFX.cheer();setReact('bat',rx('shot'),1.8);}
  const slam=n<=1&&!sub.hitTarget&&!game.won&&slamDanda();   // not a single bounce after the flick: down goes the danda
  const hit=sub.hitTarget;
  later(slam?3.6:1.8,()=>{if(game.won)return;$('jug').classList.add('hide');if(hit&&onDafoq(curSide()))startTaunt();else resetBall();});
}
function gameOver(s){
  S='over';shotBar(false);setPrompt('');$('jug').classList.add('hide');
  fillOver(s);$('over').classList.remove('hide');hud();
}
function fillOver(s){
  $('ostats').innerHTML=`<div><b>${Math.round(game.longest||0)} m</b><small>LONGEST HIT</small></div><div><b>${game.bestBounce||0}</b><small>BEST BOUNCES</small></div><div><b>${game.balls||0}</b><small>BALLS</small></div>`;
  $('win').textContent=cfg.mode==='cpu'?(s.cpu?'Computer wins':`${s.name==='You'?'You win':s.name+' wins'}! 🎉`):NET.role?(game.sides.indexOf(s)===myTeam()?(teamGame()?'Your team wins! 🎉':'You win! 🎉'):`${s.name} win${teamGame()?'':'s'}`):`${s.name==='You'?'You win':s.name+(teamGame()?' win':' wins')}! 🎉`;
  $('fboard').innerHTML=boardHTML();
  $('again').disabled=NET.role==='guest';$('again').textContent=NET.role==='guest'?'Waiting for the host…':'REMATCH ▶';
}

/* ---------- update ---------- */
function cpuThink(rdt){
  if(S==='aim'&&NET.role&&throwerCPU()){const f=sub.thrower;S='fetch';sub={thrower:f,wind:0.7,w0:0.7};return;}   // the thrower's phone left: the computer throws
  if(!isCPU())return;
  if(S==='turn'){if(NET.role){sub.t=(sub.t||0)+rdt;if(sub.t>2.2)beginTurn();}return;}
  if(S==='ready'){sub.t=(sub.t||0)+rdt;if(sub.cw===undefined)sub.cw=rnd(1.6,3.2);if(sub.t>(fieldEditOK('any')?Math.max(2.4,sub.cw):sub.cw)){const r=Math.random();setShot(r<0.5?'line':r<0.8?'loft':'ground');flip();}}
  else if(S==='pop'&&!sub.swung){if(sub.cpuY===undefined)sub.cpuY=RING.y+gauss()*LV().strike+(Math.random()<LV().whiff?0.9:0);if(g.vy<0&&g.y<=sub.cpuY)strike();}
  else if(S==='jugready'){sub.t+=rdt;if(sub.t>0.9)juggleStart();}
  else if(S==='juggle'&&!sub.ended&&!sub.dead&&g.vy<0){if(sub.cpuAt===undefined){const lv=LV(),mid=(-0.12+jugWin())/2;sub.cpuAt=JY+Math.max(mid,Math.min(0.16,mid+lv.bias))+gauss()*lv.jug*(1+sub.n*lv.jugGrow);}if(g.y<=sub.cpuAt)juggleTap();}
}
const STEP=1/120;let subLast=true;
function update(dt,rdt){
  cpuThink(rdt);tickReact(rdt);tickTaunt(rdt);tickSwing(rdt);
  if(S==='toss'){sub.t+=rdt;const cp=i=>capCPU(game.sides[i]);if(sub.phase==='call'&&cp(sub.caller)&&sub.t>0.9)tossCall(Math.random()<0.5?'heads':'tails');if(sub.phase==='won'&&cp(sub.winner)&&sub.t>1.2)tossChoose('bat');}
  if(bat.q.length){if(!bat.cur)bat.cur={from:bat.a,fc:bat.c,t:0};const[tg,du,tc]=bat.q[0];bat.cur.t+=(S==='tap'||S==='ready')?dt:rdt;const k=Math.min(1,bat.cur.t/du),e=1-Math.pow(1-k,3);bat.a=lerp(bat.cur.from,tg,e);if(tc!==undefined)bat.c=lerp(bat.cur.fc,tc,e);if(k>=1){bat.q.shift();bat.cur=null;}}
  const bounceFx=(c,first)=>{SFX.bounce();burst(c.x,0.02,first?10:4,'#c9a06a',2.5);if(first)shake=Math.max(shake,3);};
  if(bat.mode==='place'){bat.pt+=rdt/0.9;if(bat.pt>=0.5&&!bat.placed){bat.placed=true;SFX.bounce();}if(bat.pt>=0.5)bat.off=lerp(0,-0.6,clamp((bat.pt-0.5)*2,0,1));if(bat.pt>=1){bat.pt=1;bat.mode='aside';}}
  else if(bat.mode==='play')bat.off+=(0-bat.off)*Math.min(1,rdt*8);
  bat.jolt=Math.max(0,bat.jolt-rdt*3);if(bat.placed)stepDanda(dt);
  if(S==='tap'){
    sub.t+=dt;
    if(!sub.hitDone&&sub.t>=0.18){sub.hitDone=true;tapImpact();}
    if(sub.hitDone){const k=clamp((sub.t-0.18)/0.045,0,1);g.rot=lerp(GREST.rot,-0.15,k);g.y=GREST.y+k*0.04;}
    if(sub.t>=0.225){sub.launched=true;launchPop();}
  }else if(S==='pop'){
    stepG(g,dt,()=>SFX.bounce());
    if(S==='pop'&&!sub.swung&&g.vy<0&&g.y<0.3)strike();            // too late: he still swings (and misses)
    if(g.landed&&S==='pop'&&!sub.swung)batsmanOut('KHALI! OUT','Missed the shot');
  }else if(S==='flight'){
    stepG(g,dt,bounceFx);sub.ft+=dt;
    for(const f of fielders){
      if(S!=='flight')break;if(f.stun>0)continue;const dx=g.x-f.x;
      if(!g.landed){if(!f.tried&&g.y<2.3&&Math.abs(dx)<0.85){f.tried=true;tryCatch(f);}}
      else if(!g.rest&&!f.tried2&&g.y<0.7&&Math.abs(dx)<0.7){
        f.tried2=true;
        if(Math.random()<0.82){g.x=f.x-0.3;g.vx=0;g.vy=0;g.y=0;g.ground=true;g.rest=true;SFX.thud();}
        else{g.vx*=0.5;f.stun=0.7;}
      }
    }
    if(S==='flight'&&(g.rest||sub.ft>14)){g.rest=true;settle();}
  }else if(S==='fetch'){
    const f=sub.thrower;
    if(!g.held&&Math.abs(f.x-(g.x+0.3))<0.2){g.held=f;sub.wind=0.7;sub.w0=0.7;f.target=f.x;}
    if(g.held&&!sub.aim&&!throwerCPU()){enterAim(f);}
    else if(g.held){sub.wind-=dt;f.wind=clamp(1-sub.wind/(sub.w0||0.5),0,1);if(sub.wind<=0)doThrow(f,sub.aim);}
  }else if(S==='aim'){
    if(sub.t<0&&sub.t+rdt>=0)setPrompt('');
    sub.t+=rdt;
  }else if(S==='jugready'){
    g.x=JX;g.y=JY;g.rot=0;
  }else if(S==='throw'){
    stepG(g,dt,bounceFx);
    if(!sub.judged){
      const ends=dandaEnds();let hitT=-1,hs=0;
      if(g.y<0.08)for(let k=0;k<=4;k++){const px=lerp(sub.px,g.x,k/4),pz=lerp(sub.pz,g.z,k/4),[dd,t]=distSeg(px,pz,ends[0],ends[1]);if(dd<0.07){hitT=t;g.x=px;g.z=pz;break;}}
      if(hitT>=0)dandaHit(hitT);
      else if(g.rest)throwSafe();
    }
    sub.px=g.x;sub.pz=g.z;if(sub.ghost&&(sub.ghost.length===0||Math.hypot(g.x-sub.ghost[sub.ghost.length-1][0],g.y-sub.ghost[sub.ghost.length-1][1])>0.6))sub.ghost.push([g.x,g.y]);
  }else if(S==='juggle'){
    if(!sub.ended){
      g.vy-=GRAV*dt;g.y+=g.vy*dt;g.rot+=g.vr*dt;g.x+=sub.drift*dt+(JX-g.x)*Math.min(1,dt*1.5);
      if(g.vy<0&&g.y<JY-0.14-lagSlack(g.vy))endJuggle();
    }else stepG(g,dt,bounceFx);
  }else if(S==='result'||S==='settle'||S==='over'){
    if(!g.held)stepG(g,dt,bounceFx);
  }
  for(const f of fielders){
    f.catchPose=Math.max(0,f.catchPose-dt*1.2);
    if(f.wind<0)f.wind=Math.min(0,f.wind+dt*3);
    if(f.stun>0){f.stun-=dt;f.v*=0.9;f.x+=f.v*dt;f.run*=0.85;continue;}
    if(f.react>0){f.react-=dt;f.v*=0.9;f.run*=0.85;continue;}
    // accelerate (≈6 m/s²) toward the target and brake to stop on it
    const d=f.target-f.x,ACC=6,want=Math.sign(d)*Math.min(f.spd,Math.sqrt(2*ACC*Math.abs(d)));
    f.v+=clamp(want-f.v,-ACC*dt,ACC*dt);if(Math.abs(d)<0.03&&Math.abs(f.v)<0.3){f.v=0;}
    f.x+=f.v*dt;const sp=Math.abs(f.v);
    f.run=clamp(sp/5,0,1);f.ph+=sp*dt*2*Math.PI/1.7;   // ~1.7 m per stride cycle
    f.face=sp>0.6?Math.sign(f.v):-1;
    if(S==='flight'&&!g.landed&&g.vy<0&&Math.abs(g.x-f.x)<4)f.catchPose=Math.min(1,f.catchPose+dt*5);
  }
  if(!g.held&&(S==='flight'||S==='throw'||S==='result'||S==='settle')&&!g.rest&&subLast){g.trail.push([g.x,g.y,g.z||0]);if(g.trail.length>14)g.trail.shift();}
  else if(g.trail.length)g.trail.shift();
  for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.vy-=9.8*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.y<0){p.y=0;p.vy*=-0.3;p.vx*=0.6;}p.life-=dt;if(p.life<=0)parts.splice(i,1);}
  for(let i=floats.length-1;i>=0;i--){floats[i].life-=rdt;if(floats[i].life<=0)floats.splice(i,1);}
  shake=Math.max(0,shake-rdt*40);flash=Math.max(0,flash-rdt*2.5);cheer=Math.max(0,cheer-rdt);
  updCam(rdt);
}
function updCam(rdt){
  let tx=0.5,tp=basePPM,k=4.5;
  if(S==='menu'||S==='turn'||S==='ready'||S==='tap'){tx=0.5;tp=basePPM*(S==='menu'||S==='turn'?1:1.06);}
  else if(react.bat&&react.bat.type==='slam'&&(S==='result'||S==='juggle')){tx=BX+0.8;tp=basePPM*1.2;k=5;}
  else if(S==='pop'){tx=0.5;tp=basePPM*(ts<0.6?1.12:1);}
  else if(S==='juggle'||S==='jugready'){tx=0.2;tp=basePPM*1.18;}
  else if(game.taunt){tx=0.9;tp=basePPM*0.95;}
  else if(game.celeb&&game.celeb.on&&S==='result'){const f=game.celeb.f;tx=f.x+f.v*0.25-0.8;tp=basePPM*0.8;k=T-game.celeb.t0<1.1?14:6;}
  else if(game.won&&S==='result'){tx=0.5;tp=basePPM*0.62;}
  else if(S==='aim'){tx=0.6;tp=basePPM*1.05;k=9;}
  else if(S==='field'){tx=22;tp=basePPM*0.28;}
  else if(S==='over'){tx=cam.x;tp=cam.ppm;}
  else{
    let fx=g.x,fy=g.y;if(g.held){fx=g.held.x;fy=1.4;}
    if(S==='fetch'&&sub.thrower)fx=sub.thrower.x;
    const wind=S==='fetch'&&g.held&&sub.thrower,hold=S==='throw'&&sub.thrower&&T-(sub.t0||0)<0.45;
    const fast=S==='flight';
    tx=fx+(fast?g.vx*0.12:0);
    const need=H*0.62/(fy+2.6);tp=Math.min(basePPM*(fast?0.55:0.75),need);
    if(fast)k=9;
    if(S==='throw'){k=7;if(g.x<7){tx=Math.max(0.5,g.x*0.6);tp=Math.min(basePPM*(g.x<3?1.05:0.85),need);}}
    if(wind||hold){const f=sub.thrower;tx=f.x-f.face*1.2;tp=basePPM*0.85;k=wind?9:12;}
    if(S==='result'&&!g.held&&Math.abs(g.x)<4){tx=0.5;tp=basePPM;}
  }
  cam.x+=(tx-cam.x)*(1-Math.exp(-rdt*k));cam.ppm+=(tp-cam.ppm)*(1-Math.exp(-rdt*3));
}
function computeTs(){
  tsTarget=1;
  if(S==='pop'&&!sub.swung&&g.vy<1&&g.y>0.2)tsTarget=0.7;
  if(S==='throw'&&!sub.judged&&g.x<4.5&&g.x>-1)tsTarget=0.4;
  if(S==='juggle'&&!sub.ended&&g.vy<0&&g.y<JY+0.6)tsTarget=0.45;
}

/* ---------- poses (2D side/front skeletons; world.js lifts them into 3D) ---------- */
function ik(a,b,l1,l2,score){
  const dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy),dd=clamp(d,Math.abs(l1-l2)+1e-3,l1+l2-1e-3);
  const ba=Math.atan2(dy,dx),off=Math.acos(clamp((l1*l1+dd*dd-l2*l2)/(2*l1*dd),-1,1));
  const j1=[a[0]+Math.cos(ba+off)*l1,a[1]+Math.sin(ba+off)*l1],j2=[a[0]+Math.cos(ba-off)*l1,a[1]+Math.sin(ba-off)*l1];
  const j=score(j1)<score(j2)?j1:j2;const ex=b[0]-j[0],ey=b[1]-j[1],el=Math.hypot(ex,ey)||1;
  return[j,[j[0]+ex/el*l2,j[1]+ey/el*l2]];
}

function torsoAt(P){const ln=P.lean,ax=[Math.sin(ln),Math.cos(ln)],pp=[Math.cos(ln),-Math.sin(ln)];return(u,v)=>[P.hip[0]+pp[0]*u+ax[0]*v,P.hip[1]+pp[1]*u+ax[1]*v];}

function batPose(){
  const m=bat.mode,c=bat.c,a=bat.a;
  let bend=c,ph2=false;
  if(m==='place'){ph2=bat.pt>=0.5;bend=ph2?2-bat.pt*2:bat.pt*2;}else if(m==='aside')bend=0;
  const shift=(m==='play'&&bend<0.5)?clamp(0.03-a*0.035,-0.05,0.08):0,hy=lerp(0.95,0.8,bend)-Math.abs(shift)*0.3,hx=shift,tilt=lerp(0,-0.05,bend),tLen=0.5*lerp(1,0.4,bend);  // bent toward the camera: torso foreshortens
  const SC=[hx-Math.sin(tilt)*tLen,hy+Math.cos(tilt)*tLen];
  const rot=v=>[SC[0]+v[0]*Math.cos(tilt)-v[1]*Math.sin(tilt),SC[1]+v[0]*Math.sin(tilt)+v[1]*Math.cos(tilt)];
  const SL=rot([-0.19+0.02*bend,-0.03+0.03*bend]),SR=rot([0.19-0.02*bend,-0.03+0.03*bend]);
  const fL=[lerp(-0.16,-0.2,bend),0],fR=[lerp(0.16,0.2,bend),0];
  const knee=[fR[0]+0.03,0.52],hangR=[SL[0]-0.03,SL[1]-0.56],hangL=[SR[0]+0.03,SR[1]-0.56];
  const hipR=[hx-0.2,hy+0.04],hipL=[hx+0.2,hy+0.04];
  let hR,hL,dir=null,grip=null,elR,elL;
  if(m==='play'){
    dir=[Math.cos(a),Math.sin(a)];
    const tl=[TIP0[0]-BX+ZX,TIP0[1]-ZY],gs=[tl[0]-LD*Math.cos(A0),tl[1]-LD*Math.sin(A0)+Math.max(0,a-A0)*0.1];
    const an=a>=0?-0.75+a*1.25:-0.75+a*0.35,gw=[SL[0]+0.5*Math.cos(an),SL[1]+0.5*Math.sin(an)];
    grip=[lerp(gw[0],gs[0],c),lerp(gw[1],gs[1],c)];hR=grip;
    const wind=clamp(a/2.1,0,1),follow=clamp(-a,0,1);
    let fr=[SR[0]+lerp(0.1,0.42,wind),SR[1]+lerp(-0.45,0.12,wind)];
    fr=[lerp(fr[0],SR[0]-0.05,follow*0.7),lerp(fr[1],SR[1]-0.32,follow*0.7)];
    hL=[lerp(fr[0],knee[0],c),lerp(fr[1],knee[1]+0.04,c)];
    elR=j=>(1-c)*(j[1]+0.25*j[0])+c*(j[0]);elL=j=>j[1]-0.25*j[0];
  }else{
    const gp=[-(BX+bat.off)+ZX,0.08-ZY],p=bend;
    if(m==='place'&&!ph2){hR=[lerp(hangR[0],gp[0],p),lerp(hangR[1],gp[1],p)];hL=[lerp(hangL[0],knee[0],p),lerp(hangL[1],knee[1]+0.04,p)];dir=[0.25,-0.97];grip=hR;}
    else{hR=[lerp(hipR[0],gp[0],p),lerp(hipR[1],gp[1],p)];hL=[lerp(hipL[0],knee[0],p),lerp(hipL[1],knee[1]+0.04,p)];}
    elR=j=>j[1]*(1-bend)*0+j[0]*(1-bend)+j[1]*bend;elL=j=>-j[0]*(1-bend)+j[1]*bend;
  }
  return{bend,hy,hx,tilt,SC,SL,SR,fL,fR,hR,hL,dir,grip,elR,elL,rot};
}

function fielderPose(f){
  const r=f.run,ph=f.ph,A=0.2+0.16*r;
  // ready crouch when still; running gait blends in with speed
  let lean=lerp(0.42,0.2+0.12*r,r),hip=[0,lerp(0.8,0.86-0.05*r+0.045*Math.abs(Math.sin(ph))*r,r)];
  const step=(p)=>[Math.sin(p)*A,Math.max(0,Math.cos(p))*(0.1+0.22*r)+Math.max(0,-Math.sin(p))*Math.max(0,Math.cos(p))*0.15*r];
  const fb=[lerp(-0.2,step(ph+Math.PI)[0],r),lerp(0,step(ph+Math.PI)[1],r)];
  const ff=[lerp(0.2,step(ph)[0],r),lerp(0,step(ph)[1],r)];
  const cp=f.catchPose;lean=lerp(lean,0.04,cp);hip[1]=lerp(hip[1],0.9,cp);
  if(f.stun>0)lean=-0.08;
  const at=torsoAt({hip,lean}),S=at(0,0.48);
  // hands on knees when waiting; pumping arms with bent elbows when running
  let hb=[lerp(0.06,S[0]+Math.sin(ph)*0.26-0.02,r),lerp(0.48,S[1]-0.3+0.1*Math.max(0,Math.sin(ph)),r)];
  let hf=[lerp(0.16,S[0]-Math.sin(ph)*0.26+0.04,r),lerp(0.5,S[1]-0.3+0.1*Math.max(0,-Math.sin(ph)),r)];
  hb=[lerp(hb[0],S[0]+0.16,cp),lerp(hb[1],S[1]+0.46,cp)];hf=[lerp(hf[0],S[0]+0.24,cp),lerp(hf[1],S[1]+0.42,cp)];
  if(f.wind>0)hf=[lerp(hf[0],S[0]-0.42,f.wind),lerp(hf[1],S[1]+0.22,f.wind)];
  else if(f.wind<0)hf=[lerp(hf[0],S[0]+0.5,-f.wind),lerp(hf[1],S[1]-0.12,-f.wind)];
  if(f.stun>0){hf=[S[0]+0.1,S[1]+0.26];hb=[S[0]+0.02,S[1]+0.3];}
  return{hip,lean,feet:[fb,ff],hands:[hb,hf],tilt:cp*0.4+(1-r)*0.25*(1-cp)};
}

function specPose(p,i){
  const hip=[0,0.92],lean=0.05,S=torsoAt({hip,lean})(0,0.48);
  if(cheer>0){const os=Math.sin(T*14+i)*0.08;return{hip,lean,feet:[[-0.1,0],[0.13,0]],hands:[[S[0]+0.06,S[1]+0.48+os],[S[0]+0.14,S[1]+0.46-os]],tilt:0.25};}
  return{hip,lean,feet:[[-0.1,0],[0.13,0]],hands:p.fold?[[S[0]+0.14,S[1]-0.28],[S[0]+0.16,S[1]-0.3]]:[[S[0]+0.02,S[1]-0.56],[S[0]+0.05,S[1]-0.55]]};
}

/* run a slow job (rebuilding the 3D world) only after the tapped button has been drawn as selected */
function later2(el,fn){el.classList.add('busy');requestAnimationFrame(()=>setTimeout(()=>{try{fn();}finally{el.classList.remove('busy');loop.dirty=8;}},16));}
window.addEventListener('resize',()=>{loop.dirty=8;});
/* ---------- pause / quit ---------- */
let paused=false,quitArm=0;
const inMatch=()=>S!=='menu'&&game.sides.length>0;
function pauseGame(){
  if(!inMatch()||paused)return;paused=true;quitArm=0;
  if(AC&&AC.state==='running'&&!NET.role)AC.suspend().catch(()=>{});
  $('pboard').innerHTML=boardHTML();$('pnote').textContent=NET.role?'Online match: the game keeps running on the other phone.':`${curName()} batting · target ${game.target}`;
  $('prestart').style.display=NET.role?'none':'';$('pquit').textContent='Quit to menu';
  $('psnd').textContent=muted?'🔇 Sound: off':'🔊 Sound: on';$('pvib').textContent=vibOn?'📳 Vibration: on':'📴 Vibration: off';
  document.querySelectorAll('#pgfx button').forEach(b=>b.classList.toggle('on',b.dataset.v===World.quality().mode));
  $('pause').classList.remove('hide');updPauseBtn();
}
function resumeGame(){if(!paused)return;paused=false;$('pause').classList.add('hide');audioInit();updPauseBtn();}
function sayBye(){if(NET.r&&NET.role){try{Promise.resolve(NET.r.emit('bye',{})).catch(()=>{});}catch(e){}}}
/* the other phone quit, closed the app or went out of range: say so and offer the way back */
function netLost(){
  if(NET.lost||!NET.role)return;NET.lost=true;
  const hn=(NET.lobby.find(x=>x.id===0)||{}).n;const other=NET.role==='host'?((game.sides[1]&&game.sides[1].name)||'The other player'):(hn||(game.sides[0]&&game.sides[0].name)||'The host');
  $('nltitle').textContent=other+' left the game';$('netlost').classList.remove('hide');paused=true;SFX0.tick();vib([30,60,30]);
}
function quitToMenu(){
  $('netlost').classList.add('hide');NET.lost=false;sayBye();
  if(NET.r){try{Promise.resolve(NET.r.leave()).catch(()=>{});}catch(e){}NET.r=null;}
  NET.role=null;NET.gotSetup=false;NET.started=false;netCancel();
  paused=false;timers=[];react={bat:null,field:null};fieldSecret=false;game.sides=[];game.won=false;game.field=null;
  for(const id of ['pause','toss','turn','over','field','jug','pick','roster'])$(id).classList.add('hide');game.duel=null;game.round=null;
  shotBar(false);setPrompt('');ts=tsTarget=1;S='menu';sub={};fielders=[];placeFielders(true);sceneReset();
  $('menu').classList.remove('hide');$('menu').classList.add('home');updPauseBtn();audioInit();
}
function updPauseBtn(){const on=inMatch()&&S!=='over';$('pz').style.display=on?'':'none';$('cambtn').style.display=on?'':'none';}
/* Android back button: closes the pause menu, opens it during a match, or leaves the app from the main menu */
window.__back=()=>{if(!$('lobby').classList.contains('hide')){quitToMenu();return true;}const sh=sheetOpen();if(sh){closeSheet(sh);return true;}if(S==='menu'&&!$('menu').classList.contains('hide')&&!$('menu').classList.contains('home')&&!NET.role){$('menu').classList.add('home');return true;}if(paused){resumeGame();return true;}if(S==='over'){quitToMenu();return true;}if(inMatch()){pauseGame();return true;}return false;};
window.__appPause=()=>{if(inMatch()&&S!=='over'&&!NET.role)pauseGame();};
document.addEventListener('visibilitychange',()=>{if(document.hidden)window.__appPause();});

/* ---------- loop ---------- */
let last=performance.now();
function loop(now){
  if(paused&&!NET.role){last=now;if(!loop.pz&&builtScene){World.render(0,true);loop.pz=1;}requestAnimationFrame(loop);return;}
  loop.pz=0;
  const rdt=Math.min(0.1,Math.max(0,(now-last)/1000));last=now;T+=rdt;
  if(rdt>0)FT+=(rdt-FT)*0.1;
  if(fpsOn&&S!=='menu')tickFps(rdt);   // smoothed frame time: how slow this phone is right now   // real time down to 10 fps (below that the game slows instead of skipping)
  if(NET.role!=='guest')for(let i=timers.length-1;i>=0;i--){timers[i].t-=rdt;if(timers[i].t<=0){const fn=timers[i].fn;timers.splice(i,1);fn();}}
  computeTs();ts+=(tsTarget-ts)*Math.min(1,rdt*12);
  let dt=rdt*ts*(isCPU()?1.35:1);if(hitStop>0){hitStop-=rdt;dt=0;}
  if(NET.role&&(NET.started||NET.gotSetup||NET.inLobby)&&NET.r&&!NET.lost){const nw=performance.now();
    if(!NET.hb||nw-NET.hb>1000){NET.hb=nw;try{Promise.resolve(NET.r.emit('hb',{})).catch(()=>{});}catch(e){}}
    if(APP&&NET.role==='guest'&&NET.lastRx&&nw-NET.lastRx>10000)netLost();
    if(APP&&NET.role==='host')for(const id in NET.rx)if(nw-NET.rx[id]>10000){delete NET.rx[id];try{AndroidNet.kick(+id);}catch(e){}}}
  if(NET.role==='guest'){if(NET.snap&&NET.snap!==NET.applied&&NET.gotSetup){try{applySnapshot(NET.snap);}catch(e){}NET.applied=NET.snap;}if(NET.gotSetup)guestStep(rdt*ts,rdt);else updCam(rdt);}
  else{
    // fixed small physics steps: the gilli flies, bounces and hits exactly the same on a slow phone as on a fast one
    const n=dt>0?Math.max(1,Math.ceil(dt/STEP)):1;
    for(let i=0;i<n;i++){subLast=i===n-1;update(dt/n,rdt/n);}
    netTick(now);
  }
  // the waiting taps of the danda on the ground: a soft knock each time it lands (in front of the gilli, then behind)
  if(S==='ready'&&bat.mode==='play'&&!paused){const p=((T/1.8)%1+1)%1,pp=loop.tp===undefined?p:loop.tp;
    if((pp>p)||(pp<0.5&&p>=0.5))noise(0.035,'bandpass',rnd(700,900),3,0.09);loop.tp=p;}else loop.tp=undefined;
  if(loop.ls!==S){loop.ls=S;document.body.classList.toggle('inmenu',S==='menu');}
  {const ok=fieldEditOK();if(loop.fb!==ok){loop.fb=ok;$('fieldbtn').classList.toggle('hide',!ok);
    if(ok){let seen=false;try{seen=localStorage.getItem('gd_fieldtip')==='1';}catch(e){}
      if(!seen){try{localStorage.setItem('gd_fieldtip','1');}catch(e){}$('fieldbtn').classList.add('pulse');setTimeout(()=>$('fieldbtn').classList.remove('pulse'),4000);
        const t=$('camtoast');t.textContent='🧢  Tap Field (top left) to move your fielders before any ball';t.classList.remove('show','long');void t.offsetWidth;t.classList.add('long');}}}}
  const calm=(S==='menu'||S==='over'||S==='turn'||S==='field'||S==='pick')&&!NET.role;   // an overlay covers the field: no need for 60 fps behind it
  loop.f=(loop.f||0)+1;loop.acc=(loop.acc||0)+rdt;
  const still=S==='menu'&&!NET.role;if(loop.wasStill!==still){loop.wasStill=still;loop.dirty=8;}
  const menuUp=S==='menu'&&!$('menu').classList.contains('hide'),no3d=menuUp||!builtScene;
  if(loop.no3d!==no3d){loop.no3d=no3d;document.body.classList.toggle('no3d',no3d);if(!no3d)loop.dirty=8;}
  if(builtScene&&!menuUp&&(still?(loop.dirty>0||loop.f%80===0):(!calm||loop.f%4===0))){if(loop.dirty>0)loop.dirty--;if(loop.okFrames!==undefined&&++loop.okFrames===90){try{localStorage.removeItem('gd_3dboot');}catch(e){}}World.render(calm?loop.acc:rdt,calm);loop.acc=0;}
  requestAnimationFrame(loop);
}

/* ---------- input ---------- */
/* the 3D (graphics chip) starts only when the first match begins. If the app died while starting it last time,
   the next start uses safe mode: lowest graphics and a small drawing surface */
try{if(localStorage.getItem('gd_3dboot')){localStorage.setItem('gd_safe3d','1');localStorage.setItem('gd_gfx','low');}localStorage.removeItem('gd_3dboot');}catch(e){}
function start3D(){if(World.ready())return;try{localStorage.setItem('gd_3dboot','1');}catch(e){}World.init();loop.okFrames=0;}
/* target: presets or any number the players agree on (5 to 999), remembered for next time */
function setTarget(v,custom){v=Math.round(clamp(+v||25,5,999));cfg.target=v;if(custom){$('tcin').value=v;$('tcbtn').textContent='✏️ '+v;}else $('tcbtn').textContent='✏️ Custom';
  try{localStorage.setItem('gd_target',v+(custom?'c':''));}catch(e){}}
$('tcin').addEventListener('input',()=>{const v=+$('tcin').value;if(v>=5&&v<=999){cfg.target=Math.round(v);$('tcbtn').textContent='✏️ '+cfg.target;try{localStorage.setItem('gd_target',cfg.target+'c');}catch(e){}}});
$('tcin').addEventListener('change',()=>setTarget($('tcin').value,true));
$('tcin').addEventListener('keydown',e=>{if(e.key==='Enter'){$('tcin').blur();setTarget($('tcin').value,true);}});
for(const [id,d] of [['tcm',-5],['tcp',5]])$(id).addEventListener('click',()=>{setTarget((+$('tcin').value||25)+d,true);SFX0.tick();});
(()=>{let s='';try{s=localStorage.getItem('gd_target')||'';}catch(e){}const c=/c$/.test(s),v=parseInt(s);if(!v)return;
  const btn=c?$('tcbtn'):document.querySelector(`#target button[data-v="${v}"]`);if(!btn)return;
  document.querySelectorAll('#target button').forEach(o=>o.classList.toggle('on',o===btn));if(c){$('tcust').classList.remove('hide');}setTarget(v,c);})();
/* the 3D field is built only when a match starts (the menu has a still background), so the menu stays light on every phone */
let builtScene=null;
const TIPS=['Tap again as the gilli drops through the ring','Every bounce on the danda is 1 point','Reach the target, then survive the Dafoq','Fielding? Aim at the danda lying on the ground','Long shots are harder for the fielder to throw back'];
function ensureScene(fn){
  if(builtScene===cfg.scene){fn&&fn();return;}
  const b=document.querySelector?document.querySelector(`#scene button[data-v="${cfg.scene}"] span`):null,name=b?b.textContent:'the field';
  $('gltxt').textContent='Loading '+name+'…';$('gltip').textContent=pick(TIPS);$('gload').classList.remove('hide');
  if(ensureScene.busy){ensureScene.q=fn;return;}ensureScene.busy=true;ensureScene.q=fn;
  /* the work is split into steps with a pause between them, so the card can say which step a slow device is on;
     after 8 s it also names the graphics chip, which tells us why a device is slow */
  const t0=Date.now();let step='Starting 3D';
  if(World.safe)$('gltip').textContent='Safe graphics mode (simpler 3D for this device)';
  const show=()=>{const s=Math.round((Date.now()-t0)/1000);$('gltxt').textContent=step+'…'+(s>=3?' '+s+'s':'');
    if(s>=8){const gi=World.gpu?World.gpu():'';$('gltip').textContent='This device is slow to start the 3D. '+(gi?'Graphics: '+gi:'');}};
  const iv=setInterval(show,1000);
  const fail=e=>{clearInterval(iv);console.error(e);if(window.__bootErr)window.__bootErr((e&&e.message)||e);$('gload').classList.add('hide');ensureScene.busy=false;};
  const run=(label,work,next)=>{step=label;show();setTimeout(()=>{try{work();}catch(e){fail(e);return;}next();},50);};
  run('Starting 3D',()=>start3D(),()=>
    run('Building '+name,()=>{World.setScene(cfg.scene);builtScene=cfg.scene;},()=>
      run('Preparing graphics',()=>World.render(0,true),()=>{
        clearInterval(iv);ensureScene.busy=false;$('gload').classList.add('hide');const f=ensureScene.q;ensureScene.q=null;if(builtScene!==cfg.scene)ensureScene(f);else f&&f();})));
}
$('fpre').addEventListener('click',e=>{const b=e.target.closest('button');if(!b||!game.field)return;game.field.homes=presetField(b.dataset.p,fielders.length);renderFieldUI();});
$('fdone').addEventListener('click',()=>{audioInit();fieldDone();});cv=document.getElementById('c');
document.querySelectorAll('#scene button').forEach(b=>b.classList.toggle('on',b.dataset.v===cfg.scene));
document.querySelectorAll('#gfx button').forEach(b=>b.classList.toggle('on',b.dataset.v===World.quality().mode));
/* camera views: Settings, Pause, and the 🎥 button during play (cycles through them) */
const CAM_NAMES={side:'Side',high:'High',low:'Low',behind:'Behind'},CAM_ICON={side:'🎥',high:'🦅',low:'🎬',behind:'🏏'};
function updCamBtns(){const m=World.camMode();document.querySelectorAll('#camv button,#pcamv button').forEach(b=>b.classList.toggle('on',b.dataset.v===m));$('cambtn').textContent='🎥';loop.dirty=8;}
function setCamView(m,announce){World.setCam(m);updCamBtns();if(announce){const t=$('camtoast');const L=World.cams,i=L.indexOf(World.camMode());t.textContent='🎥  '+CAM_NAMES[World.camMode()]+' view   '+L.map((_,k)=>k===i?'●':'○').join(' ');t.classList.remove('show');void t.offsetWidth;t.classList.add('show');}}
for(const id of ['camv','pcamv'])$(id).addEventListener('click',e=>{const b=e.target.closest('button');if(b){setCamView(b.dataset.v,false);SFX0.tick();}});
$('cambtn').addEventListener('pointerdown',e=>{e.stopPropagation();e.preventDefault();const L=World.cams;setCamView(L[(L.indexOf(World.camMode())+1)%L.length],true);SFX0.tick();});
updCamBtns();
cv.addEventListener('pointerdown',e=>{e.preventDefault();audioInit();input('tap');});
function setShot(s){game.shot=s;document.querySelectorAll('#shots button').forEach(o=>o.classList.toggle('on',o.dataset.s===s));}
document.querySelectorAll('#shots button').forEach(b=>b.addEventListener('pointerdown',e=>{e.stopPropagation();e.preventDefault();audioInit();if(isCPU())return;input('shot',b.dataset.s);SFX0.tick();}));
document.querySelectorAll('.seg').forEach(seg=>seg.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||seg.id==='fpre'||seg.id==='pgfx'||seg.id==='camv'||seg.id==='pcamv')return;if(seg.id==='gfx'){seg.querySelectorAll('button').forEach(o=>o.classList.toggle('on',o===b));later2(seg,()=>World.setQuality(b.dataset.v));return;}
  seg.querySelectorAll('button').forEach(o=>o.classList.toggle('on',o===b));
  if(seg.id==='mode')cfg.mode=b.dataset.v;else if(seg.id==='scene'){cfg.scene=b.dataset.v;try{localStorage.setItem('gd_scene',cfg.scene)}catch(e){}}else if(seg.id==='target'){if(b.dataset.v==='c'){$('tcust').classList.remove('hide');setTarget($('tcin').value,true);setTimeout(()=>{try{$('tcin').focus();$('tcin').select();}catch(e){}},50);}else{$('tcust').classList.add('hide');setTarget(b.dataset.v,false);}}
  else cfg[seg.id]=+b.dataset.v;
  $('tsz').style.display=cfg.mode==='team'?'':'none';$('netbox').style.display=cfg.mode==='net'?'':'none';$('play').style.display=cfg.mode==='net'?'none':'';}));
window.addEventListener('keydown',e=>{
  if(e.repeat)return;
  if(e.target&&e.target.tagName==='INPUT')return;
  if((e.key==='c'||e.key==='C')&&inMatch()&&!paused){const L=World.cams;setCamView(L[(L.indexOf(World.camMode())+1)%L.length],true);return;}
  if(e.code==='Escape'&&sheetOpen()){closeSheet(sheetOpen());return;}
  if(e.code==='Escape'||e.key==='p'||e.key==='P'){if(paused)resumeGame();else pauseGame();return;}
  if(paused)return;
  if(e.code==='Space'||e.code==='Enter'){e.preventDefault();if((S==='menu'||S==='over')&&!NET.role&&cfg.mode!=='net')startGame();else if(S==='turn')input('begin');else{audioInit();input('tap');}}
  else if(S==='ready'&&!isCPU()&&(e.key==='1'||e.key==='2'||e.key==='3'))input('shot',['ground','line','loft'][+e.key-1]);
});
const seenKey=()=>'gd_seen_'+cfg.mode+(cfg.mode==='team'?cfg.size:'');
const rosterSeen=()=>{try{return profSet()&&(cfg.mode==='cpu'||localStorage.getItem(seenKey())==='1')}catch(e){return true}};
$('play').addEventListener('click',()=>{audioInit();if(rosterSeen())startGame();else openRoster(true);});
$('rgo').addEventListener('click',()=>{$('roster').classList.add('hide');try{localStorage.setItem('gd_prof','1');localStorage.setItem(seenKey(),'1')}catch(e){}saveRoster();if(rosterStart&&cfg.mode!=='net')startGame();});
$('mpl').addEventListener('click',()=>{audioInit();openRoster(false);});
$('rx').addEventListener('click',()=>$('roster').classList.add('hide'));
$('nme').addEventListener('click',()=>{cfg.mode='net';openRoster(false);});
$('tgo').addEventListener('click',()=>input('begin'));
$('nhost').addEventListener('click',netHost);$('njoin').addEventListener('click',netJoin);
$('ncancel').addEventListener('click',netCancel);
$('njoinbig').addEventListener('click',()=>{audioInit();if(APP)appJoin();else{netCancel();$('njoinbig').classList.add('on');$('ncodebox').classList.remove('hide');$('ncode').focus();}});
if(APP){
  $('njs').textContent='Finds the host by itself';$('nhelp').textContent='No internet needed: one phone hosts (turn on its hotspot), up to 7 more phones connect to it and tap Join.';
  const ci=$('ncode');ci.maxLength=15;ci.placeholder='host address (optional)';ci.setAttribute('inputmode','decimal');ci.style.width='190px';$('njoin').textContent='Try this address';
}
$('nlback').addEventListener('click',()=>quitToMenu());
$('lbgo').addEventListener('click',()=>{audioInit();lobbyStart();});
$('lbswap').addEventListener('click',()=>{SFX0.tick();if(NET.r)Promise.resolve(NET.r.emit('team',{})).catch(()=>{});});
$('lbleave').addEventListener('click',()=>quitToMenu());
document.querySelectorAll('#diff button').forEach(b=>{b.classList.toggle('on',+b.dataset.v===cfg.diff);b.addEventListener('click',()=>{try{localStorage.setItem('gd_diff',b.dataset.v);}catch(e){}});});
$('fieldbtn').addEventListener('pointerdown',e=>{e.stopPropagation();e.preventDefault();SFX0.tick();input('fieldedit',1);});
$('again').addEventListener('click',()=>{if(NET.role==='guest')return;startGame();});
$('setup').addEventListener('click',()=>{sayBye();if(NET.r){try{Promise.resolve(NET.r.leave()).catch(()=>{});}catch(e){}NET.r=null;}NET.role=null;NET.gotSetup=false;NET.started=false;netCancel();$('over').classList.add('hide');$('menu').classList.remove('hide');S='menu';});
function updToggles(){for(const id of ['psnd','msnd'])$(id).textContent=muted?'🔇 Sound: off':'🔊 Sound: on';for(const id of ['pvib','mvib'])$(id).textContent=vibOn?'📳 Vibration: on':'📴 Vibration: off';$('snd').textContent=muted?'🔇':'🔊';}
/* 'Show speed': frames per second, how many things the phone draws each frame, graphics level and sharpness - to see what a slow phone is doing */
let fpsOn=false;try{fpsOn=localStorage.getItem('gd_fps')==='1';}catch(e){}
function voiceInfo(){if(voiceBuf.length)return ' (Javed)';try{if(window.ApooshTTS){const s=String(ApooshTTS.status());if(s.startsWith('ok:'))return s.split(':')[1]==='ur'?' (Urdu)':' (Hindi)';return s==='starting'?'':' (no voice)';}}catch(e){}return '';}
function updCount(){$('mcnt').textContent=(countOn?'🗣️ Counting voice: on':'🗣️ Counting voice: off')+(countOn?voiceInfo():'');
  const no=countOn&&voiceInfo()===' (no voice)';$('cnthelp').classList.toggle('hide',!no);}
$('mcnt').addEventListener('click',()=>{countOn=!countOn;try{localStorage.setItem('gd_count',countOn?'1':'0');}catch(e){}updCount();if(countOn)sayNum(1);});updCount();
function updFps(){$('mfps').textContent=fpsOn?'📈 Show speed: on':'📈 Show speed: off';$('fpsbox').classList.toggle('hide',!fpsOn);}
$('mfps').addEventListener('click',()=>{fpsOn=!fpsOn;try{localStorage.setItem('gd_fps',fpsOn?'1':'0');}catch(e){}updFps();});updFps();
const fpsM={n:0,t:0};
function tickFps(rdt){if(!fpsOn||!World.ready())return;fpsM.n++;fpsM.t+=rdt;if(fpsM.t<0.5)return;
  const s=World.stats(),f=Math.round(fpsM.n/fpsM.t);fpsM.n=0;fpsM.t=0;$('fpsbox').textContent=`${f} fps · ${s.calls} draws · ${s.q} · ${s.pr.toFixed(2)}x`;$('fpsbox').style.color=f>=50?'#7ef29a':f>=35?'#ffd23f':'#ff6b6b';}
const setMuted=m=>{muted=m;try{localStorage.setItem('gd_snd',m?'0':'1')}catch(e){}updToggles();};
const toggleVib=()=>{vibOn=!vibOn;try{localStorage.setItem('gd_vib',vibOn?'1':'0')}catch(e){}updToggles();vib(30);};
/* settings and how-to sheets */
const openSheet=id=>{$(id).classList.remove('hide');SFX0.tick();};
const closeSheet=id=>$(id).classList.add('hide');
const sheetOpen=()=>['settings','howto','mstart'].find(id=>!$(id).classList.contains('hide'));
$('mplay').addEventListener('click',()=>{audioInit();SFX0.tick();$('menu').classList.remove('home');});
$('mback').addEventListener('click',()=>{SFX0.tick();$('menu').classList.add('home');});
$('mhow').addEventListener('click',()=>{audioInit();openSheet('howto');});
$('mset').addEventListener('click',()=>updCount());
$('mset').addEventListener('click',()=>{audioInit();updToggles();openSheet('settings');});
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>closeSheet(b.dataset.close)));
for(const id of ['settings','howto','mstart'])$(id).addEventListener('click',e=>{if(e.target===$(id))closeSheet(id);});
/* home: tapping a mode card opens the start sheet with only what is left to choose */
$('mode').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;audioInit();const n=b.querySelector('b');$('msttl').textContent=(b.querySelector('i')?b.querySelector('i').textContent+'  ':'')+(n?n.textContent:'');$('mscn').style.display='';$('mdiff').style.display=b.dataset.v==='cpu'?'':'none';openSheet('mstart');});
$('msnd').addEventListener('click',()=>{setMuted(!muted);audioInit();SFX0.tick();});
$('mvib').addEventListener('click',toggleVib);
setMuted(muted);
$('snd').addEventListener('pointerdown',e=>{e.stopPropagation();e.preventDefault();setMuted(!muted);audioInit();});
$('pz').addEventListener('pointerdown',e=>{e.stopPropagation();e.preventDefault();pauseGame();});
$('presume').addEventListener('click',resumeGame);
$('prestart').addEventListener('click',()=>{paused=false;$('pause').classList.add('hide');startGame();});
$('pquit').addEventListener('click',()=>{if(!quitArm){quitArm=1;$('pquit').textContent='Tap again to quit';setTimeout(()=>{quitArm=0;if(paused)$('pquit').textContent='Quit to menu';},2500);return;}quitToMenu();});
$('psnd').addEventListener('click',()=>setMuted(!muted));
$('pset').addEventListener('click',()=>{updToggles();updCount();openSheet('settings');});
$('pvib').addEventListener('click',toggleVib);
$('pgfx').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;document.querySelectorAll('#pgfx button,#gfx button').forEach(o=>o.classList.toggle('on',o.dataset.v===b.dataset.v));later2($('pgfx'),()=>{World.setQuality(b.dataset.v);loop.pz=0;});});

fielders=[];placeFielders(true);sceneReset();
window.__gd={prebuild:()=>{start3D();World.setScene(cfg.scene);builtScene=cfg.scene;},cam:()=>cam,bat:()=>bat,fielders:()=>fielders,pick:k=>{if(S==='pick'&&pickCb)pickCb(pickList[k%pickList.length]);},roster,pauseGame,resumeGame,quitToMenu,paused:()=>paused,fieldDone,fieldersHidden,react:()=>react,NET,tossCall,tossChoose,input,aimZ:()=>S==='aim'?aimZ():0,aimX:()=>S==='aim'?aimX():0,throwerCPU,action,startGame,beginTurn,state:()=>S,game,g,cfg,sub:()=>sub,J:()=>[JX,JY]};
requestAnimationFrame(loop);
