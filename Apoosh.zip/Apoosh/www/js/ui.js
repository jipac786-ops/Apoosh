/* Apoosh by Javed — ui.js
   A transparent 2D canvas on top of the 3D view for things that should stay flat and readable:
   the field mini-map, floating "+1" texts, the DANDA tag, aiming labels, slow-motion vignette and impact flash. */
'use strict';
const UI = (() => {
  function tag(x, y, txt, col) {
    const c = World.ctx; c.font = "800 13px 'Baloo 2',sans-serif"; const w = c.measureText(txt).width + 16;
    c.fillStyle = 'rgba(20,15,30,0.75)'; c.beginPath(); if (c.roundRect) c.roundRect(x - w / 2, y - 30, w, 22, 8); else c.rect(x - w / 2, y - 30, w, 22); c.fill();
    c.fillStyle = col; c.beginPath(); c.moveTo(x - 6, y - 8); c.lineTo(x + 6, y - 8); c.lineTo(x, y); c.closePath(); c.fill();
    c.fillStyle = '#fff'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(txt, x, y - 19);
  }
  function label(x, y, z, txt, col, size) {
    const [sx, sy, vis] = World.proj(x, y, z); if (!vis) return; const c = World.ctx;
    c.font = `800 ${size || 14}px 'Baloo 2',sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.lineWidth = 4; c.strokeStyle = 'rgba(20,12,24,0.65)'; c.strokeText(txt, sx, sy); c.fillStyle = col || '#fff'; c.fillText(txt, sx, sy);
  }
  function miniMap() {
    const c = World.ctx, narrow = W < 700, w = narrow ? W - 28 : Math.min(400, W - 580), x0 = (W - w) / 2, y0 = narrow ? 108 : 64, h = 14;
    let mx = 50; if (!fieldersHidden()) for (const f of fielders) mx = Math.max(mx, f.home + 10); if (S !== 'menu' && S !== 'turn') mx = Math.max(mx, g.x + 10);
    const X = v => x0 + 10 + clamp(v, -2, mx) / mx * (w - 20);
    c.fillStyle = 'rgba(24,18,44,0.45)'; c.beginPath(); if (c.roundRect) c.roundRect(x0, y0, w, h, 7); else c.rect(x0, y0, w, h); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.25)'; c.lineWidth = 1; c.beginPath(); for (let m = 10; m < mx; m += 10) { c.moveTo(X(m), y0 + 4); c.lineTo(X(m), y0 + h - 4); } c.stroke();
    c.fillStyle = '#fff'; c.beginPath(); c.arc(X(0), y0 + h / 2, 3, 0, 6.283); c.fill();
    if (fieldersHidden()) { c.font = "800 11px 'Baloo 2',sans-serif"; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#ffd23f'; c.fillText('?  ?  ?', x0 + w / 2, y0 + h / 2 + 1); }
    else for (const f of fielders) { c.fillStyle = f.kam; c.beginPath(); c.arc(X(f.x), y0 + h / 2, 4.2, 0, 6.283); c.fill(); }
    if (S !== 'menu' && S !== 'turn') { const gx = g.held ? g.held.x : g.x; c.fillStyle = '#ffd23f'; c.fillRect(X(gx) - 3, y0 + h / 2 - 1.5, 6, 3); }
  }
  const P = (x, y, z) => World.proj(x, y, z);
  function seg(c, x1, x2, z, col, w) { const a = P(x1, 0.02, z), b = P(x2, 0.02, z); c.strokeStyle = col; c.lineWidth = w; c.lineCap = 'butt'; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); return [a, b]; }
  function txt(c, s, x, y, col, size, al) { c.font = `800 ${size}px 'Baloo 2',sans-serif`; c.textAlign = al || 'center'; c.textBaseline = 'middle'; c.lineWidth = 4; c.strokeStyle = 'rgba(20,12,24,0.7)'; c.strokeText(s, x, y); c.fillStyle = col; c.fillText(s, x, y); }
  /* the two-tap throw, drawn flat on screen so it is always readable: 1) left/right  2) how hard (moving marker on the coloured line) */
  function aimOverlay(c) {
    const xNow = aimX(), zNow = aimZ(), on1 = Math.abs(zNow) < 0.32, on2 = xNow <= 0.13 && xNow >= -1.0;
    // keep the danda itself clear: the guide line stops short of it on both sides, and the marker is a hollow ring
    // with an arrow floating above it (no pin standing through the danda)
    if (sub.step === 0) {
      const gap = 0.5;
      c.setLineDash([8, 6]); c.strokeStyle = 'rgba(255,255,255,0.6)'; c.lineWidth = 3;
      for (const [z0, z1] of [[-1.0, -gap], [gap, 1.0]]) { const A = P(0, 0.02, z0), B = P(0, 0.02, z1); c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke(); }
      c.setLineDash([]);
    }
    const m = sub.step === 0 ? P(0, 0.02, zNow) : P(xNow, 0.02, sub.zLock), col = (sub.step === 0 ? on1 : on2) ? '#7ef29a' : '#ff5a5a';
    c.lineWidth = 3; c.strokeStyle = col; c.beginPath(); c.ellipse(m[0], m[1], 24, 10, 0, 0, 6.283); c.stroke();
    c.fillStyle = col; c.beginPath(); c.moveTo(m[0] - 11, m[1] - 64); c.lineTo(m[0] + 11, m[1] - 64); c.lineTo(m[0], m[1] - 48); c.closePath(); c.fill();
    txt(c, sub.step === 0 ? '1/2  AIM' : '2/2  POWER', m[0], m[1] - 78, '#fff', 15);
    // plus a fixed gauge at the bottom of the screen showing the same moving value
    const gw = Math.min(320, W * 0.6), gx = (W - gw) / 2, gy = H - 54;
    c.fillStyle = 'rgba(20,15,30,0.65)'; c.beginPath(); if (c.roundRect) c.roundRect(gx - 10, gy - 16, gw + 20, 34, 12); else c.rect(gx - 10, gy - 16, gw + 20, 34); c.fill();
    if (sub.step === 0) {
      c.fillStyle = 'rgba(255,90,90,0.8)'; c.fillRect(gx, gy - 5, gw, 10); const k = 0.32 / 1.0; c.fillStyle = '#7ef29a'; c.fillRect(gx + gw * (0.5 - k / 2), gy - 5, gw * k, 10);
      const px = gx + gw * clamp((zNow + 1) / 2, 0, 1); c.fillStyle = '#fff'; c.fillRect(px - 3, gy - 12, 6, 24);
    } else {
      const X = v => gx + gw * clamp((2.4 - v) / 3.6, 0, 1); // left = soft, right = hard
      c.fillStyle = 'rgba(255,90,90,0.8)'; c.fillRect(X(2.4), gy - 5, X(0.13) - X(2.4), 10); c.fillStyle = '#7ef29a'; c.fillRect(X(0.13), gy - 5, X(-1.0) - X(0.13), 10); c.fillStyle = '#ffaa3c'; c.fillRect(X(-1.0), gy - 5, X(-1.2) - X(-1.0), 10);
      const px = X(xNow); c.fillStyle = '#fff'; c.fillRect(px - 3, gy - 12, 6, 24); txt(c, 'soft', gx - 2, gy - 24, '#ddd', 11, 'left'); txt(c, 'hard', gx + gw + 2, gy - 24, '#ddd', 11, 'right');
    }
  }
  /* where the gilli lies once it is on the ground (it can be far away and tiny) */
  function gilliMarker(c) {
    if (g.held || !(g.ground || g.rest) || !(S === 'flight' || S === 'settle' || S === 'fetch' || S === 'result')) return;
    const [x, y, vis] = P(g.x, 0.02, g.z || 0); if (!vis) return; const b = Math.sin(T * 6) * 4;
    c.strokeStyle = '#ffd23f'; c.lineWidth = 3; c.beginPath(); c.ellipse(x, y, 16, 7, 0, 0, 6.283); c.stroke();
    c.fillStyle = '#ffd23f'; c.beginPath(); c.moveTo(x - 9, y - 30 + b); c.lineTo(x + 9, y - 30 + b); c.lineTo(x, y - 16 + b); c.closePath(); c.fill();
  }
  function draw() {
    const c = World.ctx; c.clearRect(0, 0, W, H);
    // floating texts (+1, Roka!, DROPPED…)
    for (const f of floats) { c.globalAlpha = clamp(f.life / 0.5, 0, 1); label(f.x, f.y + (1.6 - f.life) * 0.8, 0, f.t, f.col, Math.round(clamp(cam.ppm * 0.5, 18, 30) * f.sc)); }
    c.globalAlpha = 1;
    // throw: tag the danda while the gilli is on its way
    if (S === 'aim' && sub.t >= 0 && !throwerCPU()) aimOverlay(c);
    gilliMarker(c);
    // every player's name above his head, with an arrow pointing at him (the batsman's is gold)
    if (!['pick', 'field', 'turn', 'over'].includes(S)) for (const t of World.tags) {
      if (!t.n) continue; const [x, y, vis] = World.proj(t.p.x, t.p.y + 0.24, t.p.z); if (!vis || x < -40 || x > W + 40) continue;
      c.font = "800 12px 'Baloo 2',sans-serif"; const w = c.measureText(t.n).width + 14, col = t.me ? '#ffd23f' : '#ffffff';
      c.fillStyle = 'rgba(14,10,30,0.72)'; c.beginPath(); if (c.roundRect) c.roundRect(x - w / 2, y - 27, w, 18, 9); else c.rect(x - w / 2, y - 27, w, 18); c.fill();
      c.fillStyle = col; c.beginPath(); c.moveTo(x - 5, y - 8); c.lineTo(x + 5, y - 8); c.lineTo(x, y - 1); c.closePath(); c.fill();
      c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(t.n, x, y - 17.5);
    }
    miniMap();
    // slow-motion vignette and the impact flash
    const slow = 1 - ts; if (slow > 0.05) { const vg = c.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.4, W / 2, H / 2, Math.max(W, H) * 0.75); vg.addColorStop(0, 'rgba(15,25,15,0)'); vg.addColorStop(1, `rgba(15,25,15,${slow * 0.45})`); c.fillStyle = vg; c.fillRect(0, 0, W, H); }
    if (flash > 0) { c.fillStyle = `rgba(255,250,230,${flash})`; c.fillRect(0, 0, W, H); }
  }
  return { draw };
})();
