# Apoosh

Created by **Javed**.

Village gilli-danda in real 3D (Three.js / WebGL), built into an Android app.

## Build the APK with Codemagic
1. Upload `GullyDanda3D.zip` and `codemagic.yaml` to the root of a GitHub repo.
2. In Codemagic, add the repo and start the **Apoosh APK** workflow.
3. Download `app-debug.apk` from the build's artifacts.

Codemagic unzips the project, downloads Three.js 0.158.0 into `www/lib` (so the game works offline), then runs Gradle.
The app id is `com.k2.gullydanda3d`, so it installs next to the old 2D Gully Danda app instead of replacing it.

## Structure
See `app.yaml` for what each file does. Edit the game in `www/`. The Android project reads its assets straight from there.


## Updates install over the old version
The app is always signed with the same key, `android/app/apoosh.jks`, and its version number goes up with every
Codemagic build, so each new APK installs as an update. **Keep `apoosh.jks` safe** (and keep this repo private):
if the key is lost or changed, phones must uninstall the old app once before installing.
