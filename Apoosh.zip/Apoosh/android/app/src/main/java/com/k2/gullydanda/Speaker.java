package com.k2.gullydanda;

import android.content.Context;
import android.content.pm.PackageManager;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import java.util.Locale;

/** Says the bounce count out loud ("aik, do, teen...") with the phone's own offline voice.
 *  Tries Google's speech engine first (it has Urdu and Hindi), then the phone's default engine;
 *  Urdu if available, otherwise Hindi (the numbers sound the same). Silent if neither exists. */
public class Speaker {
    private static final String GOOGLE = "com.google.android.tts";
    private final Context ctx;
    private TextToSpeech tts;
    private volatile boolean ready = false;
    private volatile String lang = "", engine = "", status = "starting";
    private boolean triedDefault = false;

    Speaker(Context c) {
        ctx = c.getApplicationContext();
        boolean hasGoogle;
        try { ctx.getPackageManager().getPackageInfo(GOOGLE, 0); hasGoogle = true; } catch (PackageManager.NameNotFoundException e) { hasGoogle = false; }
        start(hasGoogle ? GOOGLE : null);
    }

    private void start(final String pkg) {
        engine = pkg == null ? "default" : "google";
        try {
            final TextToSpeech[] box = new TextToSpeech[1];
            TextToSpeech.OnInitListener l = status0 -> onInit(box[0], status0, pkg);
            box[0] = pkg == null ? new TextToSpeech(ctx, l) : new TextToSpeech(ctx, l, pkg);
            tts = box[0];
        } catch (Exception e) { status = "no speech engine"; fallback(pkg); }
    }

    private void fallback(String pkg) {
        if (pkg != null && !triedDefault) { triedDefault = true; try { if (tts != null) tts.shutdown(); } catch (Exception ignored) { } start(null); }
    }

    private void onInit(TextToSpeech t, int st, String pkg) {
        if (st != TextToSpeech.SUCCESS || t == null) { status = "speech engine failed"; fallback(pkg); return; }
        Locale[] tries = { new Locale("ur", "PK"), new Locale("ur"), new Locale("hi", "IN"), new Locale("hi") };
        for (Locale l : tries) {
            int a;
            try { a = t.isLanguageAvailable(l); } catch (Exception e) { a = TextToSpeech.LANG_NOT_SUPPORTED; }
            if (a < TextToSpeech.LANG_AVAILABLE) continue;            // not supported or voice data missing
            int r;
            try { r = t.setLanguage(l); } catch (Exception e) { r = TextToSpeech.LANG_NOT_SUPPORTED; }
            if (r >= TextToSpeech.LANG_AVAILABLE) { lang = l.getLanguage(); ready = true; break; }
        }
        if (ready) { try { t.setSpeechRate(1.3f); t.setPitch(1.05f); } catch (Exception ignored) { } status = "ok"; }
        else { status = "no Urdu or Hindi voice"; fallback(pkg); }
    }

    /** "ur", "hi" or "" when no suitable voice is installed */
    @JavascriptInterface public String lang() { return ready ? lang : ""; }
    /** for the Settings screen: what the voice is doing */
    @JavascriptInterface public String status() { return ready ? ("ok:" + lang + ":" + engine) : status; }

    @JavascriptInterface public void say(String text) {
        if (!ready || tts == null || text == null) return;
        try { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "n" + text); } catch (Exception ignored) { }
    }

    void shutdown() { try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception ignored) { } }
}
