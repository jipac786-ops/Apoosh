package com.k2.gullydanda;

import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Two phones on the same hotspot / Wi-Fi, no internet: the host opens a TCP server (port 47771) and
 * announces itself by UDP broadcast (port 47772); the other phone finds it and connects. Messages are
 * one JSON object per line. Everything received is handed to the page as window.__netEvent(type, data).
 */
public class NetBridge {
    static final int PORT = 47771;
    static final int DISCOVERY_PORT = 47772;
    static final String BEACON = "GULLYDANDA1";

    private final Activity activity;
    private final WebView web;
    private final ExecutorService workers = Executors.newCachedThreadPool();
    private final ExecutorService writer = Executors.newSingleThreadExecutor();

    private volatile ServerSocket server;
    private volatile Socket socket;
    private volatile BufferedWriter out;
    private volatile boolean beaconing = false;
    private volatile String hostName = "";

    NetBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
    }

    // ---------------- called from the page ----------------

    /** Start hosting. Returns this phone's IPv4 addresses (comma separated) or "ERR:...". */
    @JavascriptInterface
    public String host() {
        close();
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(PORT));
            server = ss;
        } catch (Exception e) {
            return "ERR:" + e.getMessage();
        }
        workers.execute(() -> {
            try {
                while (server != null && !server.isClosed()) {
                    Socket s = server.accept();
                    Socket cur = socket;
                    // one opponent at a time: while a match is on, only the same phone may reconnect; anyone else is refused
                    if (cur != null && !cur.isClosed() && !s.getInetAddress().equals(cur.getInetAddress())) {
                        try { s.close(); } catch (Exception ignored) { }
                        continue;
                    }
                    attach(s);
                }
            } catch (Exception ignored) {
            }
        });
        startBeacon();
        return String.join(", ", localIps());
    }

    /** The host's player name, sent with the announcement so the joining phone can show "Javed's game". */
    @JavascriptInterface
    public void setName(String name) {
        String n = name == null ? "" : name.replace('|', ' ').replace('\n', ' ').trim();
        hostName = n.length() > 20 ? n.substring(0, 20) : n;
    }

    /** Connect to a host at this IPv4 address. */
    @JavascriptInterface
    public void join(final String ip) {
        close();
        workers.execute(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip, PORT), 6000);
                attach(s);
            } catch (Exception e) {
                emit("error", String.valueOf(e.getMessage()));
            }
        });
    }

    /** The Wi-Fi gateway's address. On a phone hotspot the gateway IS the hosting phone, so joining it needs no search. */
    @JavascriptInterface
    public String gateway() {
        try {
            WifiManager wm = (WifiManager) activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null || wm.getDhcpInfo() == null) return "";
            int g = wm.getDhcpInfo().gateway;
            if (g == 0) return "";
            return (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff);
        } catch (Exception e) {
            return "";
        }
    }

    /** Try several addresses quickly, one after another, and stay connected to the first that answers. */
    @JavascriptInterface
    public void joinAny(final String csv) {
        close();
        workers.execute(() -> {
            for (String ip : String.valueOf(csv).split(",")) {
                ip = ip.trim();
                if (ip.isEmpty()) continue;
                try {
                    Socket s = new Socket();
                    s.connect(new InetSocketAddress(ip, PORT), 1500);
                    attach(s);
                    return;
                } catch (Exception ignored) {
                }
            }
            emit("error", "none");
        });
    }

    /** Send one message (a JSON string) to the other phone. */
    @JavascriptInterface
    public void send(final String line) {
        final BufferedWriter w = out;
        if (w == null || line == null) return;
        writer.execute(() -> {
            try {
                w.write(line.replace('\n', ' '));
                w.write('\n');
                w.flush();
            } catch (Exception ignored) {
            }
        });
    }

    /** Listen ~4 s for a host's broadcast; each host found is reported as ("found", ip). */
    @JavascriptInterface
    public void discover() {
        workers.execute(() -> {
            WifiManager.MulticastLock lock = null;
            DatagramSocket ds = null;
            Set<String> seen = new HashSet<>();
            try {
                WifiManager wm = (WifiManager) activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    lock = wm.createMulticastLock("gullydanda");
                    lock.setReferenceCounted(false);
                    lock.acquire();
                }
                ds = new DatagramSocket(null);
                ds.setReuseAddress(true);
                ds.setBroadcast(true);
                ds.bind(new InetSocketAddress(DISCOVERY_PORT));
                ds.setSoTimeout(500);
                long end = System.currentTimeMillis() + 4500;
                byte[] buf = new byte[160];
                while (System.currentTimeMillis() < end) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    try {
                        ds.receive(p);
                    } catch (SocketTimeoutException t) {
                        continue;
                    }
                    String msg = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                    String ip = p.getAddress().getHostAddress();
                    if (msg.startsWith(BEACON) && seen.add(ip)) emit("found", ip + msg.substring(BEACON.length()));
                }
            } catch (Exception e) {
                emit("error", "discovery: " + e.getMessage());
            } finally {
                if (ds != null) ds.close();
                if (lock != null && lock.isHeld()) lock.release();
            }
        });
    }

    /** Stop hosting / disconnect. */
    @JavascriptInterface
    public void close() {
        beaconing = false;
        try { if (socket != null) socket.close(); } catch (Exception ignored) { }
        try { if (server != null) server.close(); } catch (Exception ignored) { }
        socket = null;
        server = null;
        out = null;
    }

    // ---------------- internals ----------------

    private void attach(final Socket s) {
        try {
            Socket old = socket;
            if (old != null && old != s) old.close();
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            socket = s;
            out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8));
            emit("open", "");
            workers.execute(() -> {
                try {
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                    String line;
                    while ((line = in.readLine()) != null) emit("msg", line);
                } catch (Exception ignored) {
                }
                if (socket == s) {
                    socket = null;
                    out = null;
                }
                emit("close", "");
            });
        } catch (Exception e) {
            emit("error", String.valueOf(e.getMessage()));
        }
    }

    /** Announce "a game is hosted here" once a second on every network (hotspot or Wi-Fi). */
    private void startBeacon() {
        beaconing = true;
        workers.execute(() -> {
            DatagramSocket ds = null;
            try {
                ds = new DatagramSocket();
                ds.setBroadcast(true);
                while (beaconing && server != null) {
                    byte[] msg = (BEACON + "|" + hostName).getBytes(StandardCharsets.UTF_8);
                    Socket cur = socket;
                    if (cur != null && !cur.isClosed()) { Thread.sleep(1000); continue; } // already playing: don't show up in other phones' lists
                    for (InetAddress b : broadcastAddresses()) {
                        try { ds.send(new DatagramPacket(msg, msg.length, b, DISCOVERY_PORT)); } catch (Exception ignored) { }
                    }
                    Thread.sleep(1000);
                }
            } catch (Exception ignored) {
            } finally {
                if (ds != null) ds.close();
            }
        });
    }

    private static List<InetAddress> broadcastAddresses() {
        List<InetAddress> list = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null) list.add(b);
                }
            }
            list.add(InetAddress.getByName("255.255.255.255"));
        } catch (Exception ignored) {
        }
        return list;
    }

    private static List<String> localIps() {
        List<String> ips = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address) ips.add(a.getHostAddress());
                }
            }
        } catch (Exception ignored) {
        }
        // hotspot / Wi-Fi addresses (192.168.x.x, 172.x, 10.x) first
        ips.sort((x, y) -> Boolean.compare(!x.startsWith("192.168."), !y.startsWith("192.168.")));
        return ips;
    }

    private void emit(final String type, final String data) {
        final String js = "window.__netEvent&&window.__netEvent(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")";
        activity.runOnUiThread(() -> web.evaluateJavascript(js, null));
    }
}
