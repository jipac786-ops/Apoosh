package com.k2.gullydanda;

import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Phones on the same hotspot / Wi-Fi, no internet: the host opens a TCP server (port 47771) and announces
 * itself by UDP broadcast (port 47772); other phones (up to 7) find it and connect. Messages are one JSON
 * object per line. Everything received is handed to the page as window.__netEvent(type, data).
 * On the host every phone has a number: events are "openf"/"msgf"/"closef" with data "id|...".
 * On a joining phone (one connection to the host) events are "open"/"msg"/"close".
 */
public class NetBridge {
    static final int PORT = 47771;
    static final int DISCOVERY_PORT = 47772;
    static final String BEACON = "GULLYDANDA1";

    private final Activity activity;
    private final WebView web;
    private final ExecutorService workers = Executors.newCachedThreadPool();
    private final ExecutorService writer = Executors.newSingleThreadExecutor();

    private volatile ServerSocket server;
    private volatile Socket socket;
    private volatile BufferedWriter out;
    private volatile boolean beaconing = false;
    /** host side: every connected phone */
    private static class Client { final int id; final Socket s; final BufferedWriter w; final String ip;
        Client(int id, Socket s, BufferedWriter w, String ip) { this.id = id; this.s = s; this.w = w; this.ip = ip; } }
    private final Map<Integer, Client> clients = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);
    private volatile int maxClients = 7;
    private volatile boolean acceptOpen = true;
    private volatile String hostName = "";

    NetBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
    }

    // ---------------- called from the page ----------------

    /** Start hosting. Returns this phone's IPv4 addresses (comma separated) or "ERR:...". */
    @JavascriptInterface
    public String host() {
        close();
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(PORT));
            server = ss;
        } catch (Exception e) {
            return "ERR:" + e.getMessage();
        }
        workers.execute(() -> {
            try {
                while (server != null && !server.isClosed()) {
                    Socket s = server.accept();
                    String ip = s.getInetAddress().getHostAddress();
                    Client same = null;
                    for (Client c : clients.values()) if (c.ip.equals(ip)) same = c;
                    // a phone that was already in (and dropped) may always come back; new phones only while the lobby is open and not full
                    if (same == null && (!acceptOpen || clients.size() >= maxClients)) {
                        try { s.close(); } catch (Exception ignored) { }
                        continue;
                    }
                    if (same != null) { dropClient(same, false); }
                    attachClient(s, same != null ? same.id : nextId.getAndIncrement());
                }
            } catch (Exception ignored) {
            }
        });
        startBeacon();
        return String.join(", ", localIps());
    }

    /** The host's player name, sent with the announcement so the joining phone can show "Javed's game". */
    @JavascriptInterface
    public void setName(String name) {
        String n = name == null ? "" : name.replace('|', ' ').replace('\n', ' ').trim();
        hostName = n.length() > 20 ? n.substring(0, 20) : n;
    }

    /** Connect to a host at this IPv4 address. */
    @JavascriptInterface
    public void join(final String ip) {
        close();
        workers.execute(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip, PORT), 6000);
                attach(s);
            } catch (Exception e) {
                emit("error", String.valueOf(e.getMessage()));
            }
        });
    }

    /** The Wi-Fi gateway's address. On a phone hotspot the gateway IS the hosting phone, so joining it needs no search. */
    @JavascriptInterface
    public String gateway() {
        try {
            WifiManager wm = (WifiManager) activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null || wm.getDhcpInfo() == null) return "";
            int g = wm.getDhcpInfo().gateway;
            if (g == 0) return "";
            return (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff);
        } catch (Exception e) {
            return "";
        }
    }

    /** Try several addresses quickly, one after another, and stay connected to the first that answers. */
    @JavascriptInterface
    public void joinAny(final String csv) {
        close();
        workers.execute(() -> {
            for (String ip : String.valueOf(csv).split(",")) {
                ip = ip.trim();
                if (ip.isEmpty()) continue;
                try {
                    Socket s = new Socket();
                    s.connect(new InetSocketAddress(ip, PORT), 1500);
                    attach(s);
                    return;
                } catch (Exception ignored) {
                }
            }
            emit("error", "none");
        });
    }

    /** Host: let new phones join (lobby) or not (match running). */
    @JavascriptInterface
    public void setOpen(boolean open) { acceptOpen = open; }

    /** Host: how many phones may join (1 for a two-phone match, 7 for teams). */
    @JavascriptInterface
    public void setMax(int n) { maxClients = Math.max(1, Math.min(7, n)); }

    /** Host: send to one phone only. */
    @JavascriptInterface
    public void sendTo(final int id, final String line) {
        final Client c = clients.get(id);
        if (c == null || line == null) return;
        writer.execute(() -> writeLine(c.w, line));
    }

    /** Host: disconnect one phone. */
    @JavascriptInterface
    public void kick(final int id) { Client c = clients.get(id); if (c != null) dropClient(c, true); }

    /** Send one message (a JSON string): from the host to every phone, from a joining phone to the host. */
    @JavascriptInterface
    public void send(final String line) {
        if (server != null) {
            if (line == null) return;
            for (final Client c : clients.values()) writer.execute(() -> writeLine(c.w, line));
            return;
        }
        final BufferedWriter w = out;
        if (w == null || line == null) return;
        writer.execute(() -> {
            try {
                w.write(line.replace('\n', ' '));
                w.write('\n');
                w.flush();
            } catch (Exception ignored) {
            }
        });
    }

    /** Listen ~4 s for a host's broadcast; each host found is reported as ("found", ip). */
    @JavascriptInterface
    public void discover() {
        workers.execute(() -> {
            WifiManager.MulticastLock lock = null;
            DatagramSocket ds = null;
            Set<String> seen = new HashSet<>();
            try {
                WifiManager wm = (WifiManager) activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    lock = wm.createMulticastLock("gullydanda");
                    lock.setReferenceCounted(false);
                    lock.acquire();
                }
                ds = new DatagramSocket(null);
                ds.setReuseAddress(true);
                ds.setBroadcast(true);
                ds.bind(new InetSocketAddress(DISCOVERY_PORT));
                ds.setSoTimeout(500);
                long end = System.currentTimeMillis() + 4500;
                byte[] buf = new byte[160];
                while (System.currentTimeMillis() < end) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    try {
                        ds.receive(p);
                    } catch (SocketTimeoutException t) {
                        continue;
                    }
                    String msg = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                    String ip = p.getAddress().getHostAddress();
                    if (msg.startsWith(BEACON) && seen.add(ip)) emit("found", ip + msg.substring(BEACON.length()));
                }
            } catch (Exception e) {
                emit("error", "discovery: " + e.getMessage());
            } finally {
                if (ds != null) ds.close();
                if (lock != null && lock.isHeld()) lock.release();
            }
        });
    }

    /** Stop hosting / disconnect. */
    @JavascriptInterface
    public void close() {
        beaconing = false;
        for (Client c : clients.values()) { try { c.s.close(); } catch (Exception ignored) { } }
        clients.clear();
        acceptOpen = true;
        try { if (socket != null) socket.close(); } catch (Exception ignored) { }
        try { if (server != null) server.close(); } catch (Exception ignored) { }
        socket = null;
        server = null;
        out = null;
    }

    // ---------------- internals ----------------

    private static void writeLine(BufferedWriter w, String line) {
        try { w.write(line.replace('\n', ' ')); w.write('\n'); w.flush(); } catch (Exception ignored) { }
    }

    private void attachClient(final Socket s, final int id) {
        try {
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            final Client c = new Client(id, s, new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8)), s.getInetAddress().getHostAddress());
            clients.put(id, c);
            emit("openf", id + "|" + c.ip);
            workers.execute(() -> {
                try {
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                    String line;
                    while ((line = in.readLine()) != null) emit("msgf", id + "|" + line);
                } catch (Exception ignored) {
                }
                if (clients.get(id) == c) { clients.remove(id); emit("closef", String.valueOf(id)); }
            });
        } catch (Exception e) {
            emit("error", String.valueOf(e.getMessage()));
        }
    }

    private void dropClient(Client c, boolean tell) {
        clients.remove(c.id);
        try { c.s.close(); } catch (Exception ignored) { }
        if (tell) emit("closef", String.valueOf(c.id));
    }

    private void attach(final Socket s) {
        try {
            Socket old = socket;
            if (old != null && old != s) old.close();
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            socket = s;
            out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8));
            emit("open", "");
            workers.execute(() -> {
                try {
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                    String line;
                    while ((line = in.readLine()) != null) emit("msg", line);
                } catch (Exception ignored) {
                }
                if (socket == s) {
                    socket = null;
                    out = null;
                }
                emit("close", "");
            });
        } catch (Exception e) {
            emit("error", String.valueOf(e.getMessage()));
        }
    }

    /** Announce "a game is hosted here" once a second on every network (hotspot or Wi-Fi). */
    private void startBeacon() {
        beaconing = true;
        workers.execute(() -> {
            DatagramSocket ds = null;
            try {
                ds = new DatagramSocket();
                ds.setBroadcast(true);
                while (beaconing && server != null) {
                    byte[] msg = (BEACON + "|" + hostName).getBytes(StandardCharsets.UTF_8);
                    if (!acceptOpen || clients.size() >= maxClients) { Thread.sleep(1000); continue; } // match running or full: don't show up in other phones' lists
                    for (InetAddress b : broadcastAddresses()) {
                        try { ds.send(new DatagramPacket(msg, msg.length, b, DISCOVERY_PORT)); } catch (Exception ignored) { }
                    }
                    Thread.sleep(1000);
                }
            } catch (Exception ignored) {
            } finally {
                if (ds != null) ds.close();
            }
        });
    }

    private static List<InetAddress> broadcastAddresses() {
        List<InetAddress> list = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null) list.add(b);
                }
            }
            list.add(InetAddress.getByName("255.255.255.255"));
        } catch (Exception ignored) {
        }
        return list;
    }

    private static List<String> localIps() {
        List<String> ips = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address) ips.add(a.getHostAddress());
                }
            }
        } catch (Exception ignored) {
        }
        // hotspot / Wi-Fi addresses (192.168.x.x, 172.x, 10.x) first
        ips.sort((x, y) -> Boolean.compare(!x.startsWith("192.168."), !y.startsWith("192.168.")));
        return ips;
    }

    private void emit(final String type, final String data) {
        final String js = "window.__netEvent&&window.__netEvent(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")";
        activity.runOnUiThread(() -> web.evaluateJavascript(js, null));
    }
}
